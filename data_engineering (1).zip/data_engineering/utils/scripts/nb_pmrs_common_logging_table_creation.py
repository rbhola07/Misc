# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 6 Sept 2024        |    Gokul Prasanth S  |    Created logging Table. |
# MAGIC
# MAGIC ## Purpose
# MAGIC The Purpose of this notebook is to create logging tables.
# MAGIC

# COMMAND ----------

# MAGIC %md  
# MAGIC #### importing necessary functions

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.types import IntegerType, StringType

# COMMAND ----------

# MAGIC %md
# MAGIC #### getting the values from the widgets

# COMMAND ----------

# Remove all widgets
dbutils.widgets.removeAll()

# Create widgets for external location, UC catalog name, and object owner SPN
external_location = dbutils.jobs.taskValues.get(taskKey="adls_path_setup", key="external_location")
uc_catalog_name = dbutils.jobs.taskValues.get(taskKey="adls_path_setup", key="uc_catalog_name")

dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)

# Describe the external location and get the absolute path
df = spark.sql(f"DESCRIBE EXTERNAL LOCATION `{external_location.strip()}`")
absolute_path = df.select(col('url')).filter(col('name') == external_location.strip()).head()[0]

# Print the variables
print(f"absolute_path     : {absolute_path}")
print(f"external_location : {external_location}")
print(f"uc_catalog_name   : {uc_catalog_name}")

# Display the DataFrame
display(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### creating the database 

# COMMAND ----------

# List of database names
db_names = ["logging","config_details","bronze_master_data", "silver_master_data", "gold_master_data", "bronze_finance", "silver_finance", "gold_finance", "bronze_finance", "bronze_market", "silver_market", "gold_market"]

# Function to check and create database if not exists
def check_and_create_database(uc_catalog_name, db_name):
    try:
        # Check if database exists
        databases = spark.sql(f"SHOW DATABASES in `{uc_catalog_name}`").collect()
        db_list = [db.databaseName for db in databases]
        if db_name in db_list:
            print(f"Database {db_name} exists in unity catalog {uc_catalog_name}.")
        else:
            #Create database if it does not exist
            spark.sql(f"CREATE DATABASE IF NOT EXISTS {uc_catalog_name}.{db_name}")
            print(f"Database {db_name} created in catalog {uc_catalog_name}.")
    except Exception as e:
        print(f"Error checking or creating database {db_name} in unity catalog {uc_catalog_name}: {e}")

# Check and create databases
for db_name in db_names:
    check_and_create_database(uc_catalog_name, db_name)


# COMMAND ----------

# MAGIC %md
# MAGIC ####Table and View Creation

# COMMAND ----------

# Creating the job table if it does not exist

try:
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {uc_catalog_name}.logging.job (
            job_id BIGINT,
            run_id BIGINT,
            username STRING,
            job_desc STRING,
            job_start_date TIMESTAMP,
            job_end_date TIMESTAMP,
            job_status_id BIGINT,
            feed_type_id INT,
            feed_id INT,
            module_id INT,
            row_count INT,
            error_code STRING,
            error_desc STRING
        )
        USING delta
        PARTITIONED BY (feed_type_id, feed_id, module_id, run_id)
        LOCATION '{absolute_path}/data_engineering/logs/job'
    """)
    print("Job table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the job view if it does not exist

try:
    spark.sql(f"""
        CREATE OR REPLACE VIEW {uc_catalog_name}.logging.vw_job AS (
            SELECT
                `job_id` AS `Job ID`,
                `username` AS `Username`,
                `job_desc` AS `Job Description`,
                `job_start_date` AS `Job Start Date`,
                `job_end_date` AS `Job End Date`,
                `job_status_id` AS `Job Status ID`,
                `feed_type_id` AS `Feed Type ID`,
                `feed_id` AS `Feed ID`,
                `module_id` AS `Module ID`,
                `row_count` AS `Row Count`,
                `error_code` AS `Error Code`,
                `error_desc` AS `Error Description`
             FROM
                  {uc_catalog_name}.logging.job
            )""")
    print("Job view created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the job_log table if it does not exist

try:
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {uc_catalog_name}.logging.job_log (
            job_log_id BIGINT,
            job_id BIGINT,
            run_id BIGINT,
            username STRING,
            job_log_desc STRING,
            job_log_start_date TIMESTAMP,
            job_log_end_date TIMESTAMP,
            job_log_status_id BIGINT,
            feed_type_id STRING,
            feed_id STRING,
            module_id STRING,
            row_count INT,
            error_code STRING,
            error_desc STRING
        )
        USING delta
        PARTITIONED BY (feed_type_id, feed_id, module_id, run_id)
        LOCATION '{absolute_path}data_engineering/logs/job_log'
    """)
    print("Job log table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the job_log view if it does not exist

try:
    spark.sql(f"""
       CREATE OR REPLACE VIEW {uc_catalog_name}.logging.vw_job_log AS (
           SELECT
            `job_log_id` AS `Job Log ID`,
            `job_id` AS `Job ID`,
            `username` AS `Username`,
            `job_log_desc` AS `Job Log Description`,
            `job_log_start_date` AS `Job Log Start Date`,
            `job_log_end_date` AS `Job Log End Date`,
            `job_log_status_id` AS `Job Log Status ID`,
            `feed_type_id` AS `Feed Type ID`,
            `feed_id` AS `Feed ID`,
            `module_id` AS `Module ID`,
            `row_count` AS `Row Count`,
            `error_code` AS `Error Code`,
            `error_desc` AS `Error Description`
            FROM
            {uc_catalog_name}.logging.job_log
        )""")
    print("Job log view created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the job_detail_log table if it does not exist

try:
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {uc_catalog_name}.logging.job_detail_log(
            job_detail_log_id BIGINT,
            job_log_id BIGINT,
            run_id BIGINT,
            username STRING,
            job_detail_desc STRING,
            job_detail_log_date TIMESTAMP,
            job_detail_log_status_id BIGINT,
            feed_type_id INT,
            feed_id INT,
            module_id INT,
            row_count INT,
            error_code STRING,
            error_desc STRING
        )
        USING delta
        PARTITIONED BY (feed_type_id, feed_id, module_id, job_log_id)
        LOCATION '{absolute_path}data_engineering/logs/job_detail_log'
    """)
    print("Job detail log table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the job_detail_log view if it does not exist

try:
    spark.sql(f"""
        CREATE OR REPLACE VIEW {uc_catalog_name}.logging.vw_job_detail_log AS (
           SELECT
                `job_detail_log_id` AS `Job Detail Log ID`,
                `job_log_id` AS `Job Log ID`,
                `username` AS `Username`,
                `job_detail_desc` AS `Job Detail Description`,
                `job_detail_log_date` AS `Job Detail Log Date`,
                `job_detail_log_status_id` AS `Job Detail Log Status ID`,
                `feed_type_id` AS `Feed Type ID`,
                `feed_id` AS `Feed ID`,
                `module_id` AS `Module ID`,
                `row_count` AS `Row Count`,
                `error_code` AS `Error Code`,
                `error_desc` AS `Error Description`
                FROM
                {uc_catalog_name}.logging.job_detail_log
        )""")
    print("Job detail log view created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

try:
    spark.sql(f"""
        CREATE OR REPLACE VIEW {uc_catalog_name}.logging.vw_webapp_logs AS (
           SELECT
                j.job_id AS `Job ID`,
                st.`desc` AS `Status`,
                j.username AS `User Name`,
                j.job_desc AS `ETL Name`,
                j.job_start_date AS `Start Time & Date (IST)`
                FROM
                {uc_catalog_name}.logging.job j
                JOIN {uc_catalog_name}.logging.status st
                ON j.job_status_id = st.id
        )""")
    print("Webapp log view created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the feed table if it does not exist

try:
    df_feed = spark.read.format("csv")\
                        .option("header", "true")\
                        .load(f"{absolute_path}data_engineering/configs_volume/audit_log_feed.csv")\
                        .withColumn("id", col("id").cast("int"))\
                        .withColumn("parent_id", col("parent_id").cast("int"))

    df_feed.write.format("delta").mode("overwrite")\
                 .option("path", f"{absolute_path}data_engineering/logs/feed")\
                 .saveAsTable(f"{uc_catalog_name}.logging.feed")

    print("Feed table created successfully.")
    
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the feed type table if it does not exist

try:
    df_feed_type = spark.read.format("csv").option("header", "true")\
                            .load(f"{absolute_path}data_engineering/configs_volume/audit_log_feed_type.csv")\
                            .withColumn("id", col("id").cast("int"))

    df_feed_type.write.format("delta").mode("overwrite")\
                      .option("path", f"{absolute_path}data_engineering/logs/feed_type")\
                      .saveAsTable(f"{uc_catalog_name}.logging.feed_type")

    print("Feed type table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the status table if it does not exist

try:
    df_status = (spark.read.format("csv").option("header", "true")\
                            .load(f"{absolute_path}data_engineering/configs_volume/audit_log_status.csv")\
                            .withColumn("id", col("id").cast("int"))\
                            .withColumn("parent_id", col("parent_id").cast("int")))

    df_status.write.format("delta").mode("overwrite")\
                   .option("path", f"{absolute_path}data_engineering/logs/status")\
                   .saveAsTable(f"{uc_catalog_name}.logging.status")

    print("Status table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating the module table if it does not exist

try:
    df_module = (spark.read.format("csv").option("header", "true")\
                            .load(f"{absolute_path}data_engineering/configs_volume/audit_log_module.csv")\
                            .withColumn("module_id", col("module_id").cast("int"))\
                            .withColumn("parent_id", col("parent_id").cast("int")))

    df_module.write.format("delta").mode("overwrite")\
                   .option("path", f"{absolute_path}data_engineering/logs/module")\
                   .saveAsTable(f"{uc_catalog_name}.logging.module")

    print("Module table created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Volumes creation

# COMMAND ----------

# Creating configuration volumnes if it does not exist

try:
    # Creating configuration volumes if it does not exist
    spark.sql(f"""
                    CREATE EXTERNAL VOLUME IF NOT EXISTS {uc_catalog_name}.config_details.pmrs_volume_configs
                    LOCATION "{absolute_path}data_engineering/configs_volume/";
             """)
    print("config_details.pmrs_volume_config volume created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# Creating technical_jars volumes volumes if it does not exist

try:
    # Creating technical_jars volumes if it does not exist
    spark.sql(f"""
                    CREATE EXTERNAL VOLUME IF NOT EXISTS {uc_catalog_name}.config_details.pmrs_volume_technical_jars
                    LOCATION "{absolute_path}data_engineering/technical_jars_volume/";
            """)
    print("config_details.pmrs_volume_technical_jars volume created successfully.")
except Exception as e:
    print(f"An error occurred: {e}")

