# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 6 Sept 2024        |    Prasanth              |    Created gold Table.        |
# MAGIC
# MAGIC ## Purpose
# MAGIC The Purpose of this notebook is to create gold tables for PBI views.
# MAGIC

# COMMAND ----------

# MAGIC %md  
# MAGIC #### importing necessary functions

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, DoubleType

# COMMAND ----------

# MAGIC %md
# MAGIC #### getting the values from the widgets

# COMMAND ----------

# Remove all widgets
dbutils.widgets.removeAll()

# Create widgets for external location, UC catalog name

external_location   =   dbutils.widgets.text("external_location","")
uc_catalog_name     =   dbutils.widgets.text("uc_catalog_name","")

external_location = dbutils.jobs.taskValues.get(taskKey="adls_path_setup", key="external_location")
uc_catalog_name = dbutils.jobs.taskValues.get(taskKey="adls_path_setup", key="uc_catalog_name")

dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)

# Describe the external location and get the absolute path
df                  = spark.sql(f"DESCRIBE EXTERNAL LOCATION `{external_location.strip()}`")
absolute_path       = df.select(col('url')).filter(col('name') == external_location.strip()).head()[0]

# Print the variables
print(f"absolute_path       : {absolute_path}")
print(f"external_location   : {external_location}")
print(f"uc_catalog_name     : {uc_catalog_name}")

# Display the DataFrame
display(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### catalog details

# COMMAND ----------

# Using the specified catalog
spark.sql(f"USE CATALOG {uc_catalog_name}")

# Creating the schema if it does not exist
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `gold_finance`;")

# Creating the schema if it does not exist
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `gold_market`;")

# COMMAND ----------

# MAGIC %md
# MAGIC #### DB,Table creation for Bronze, Silver, Gold

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_finance.fact_customer (
  bu_sk INT,
  product_sk INT,
  customer_sk INT,
  month_sk STRING,
  measure_sk INT,
  cont_disc_ops_sk INT,
  currency_sk INT,
  version_sk INT,
  company_sk INT,
  flow_sk INT,
  value STRING,
  log_id BIGINT,
  created_date TIMESTAMP)
USING delta
LOCATION '{absolute_path}data_engineering/gold/finance/fact_customer'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_finance.fact_brand (
  bu_sk INT,
  product_sk INT,
  brand_sk INT,
  month_sk STRING,
  measure_sk INT,
  cont_disc_ops_sk INT,
  currency_sk INT,
  version_sk INT,
  company_sk INT,
  flow_sk INT,
  value STRING,
  log_id BIGINT,
  created_date TIMESTAMP)
USING delta
LOCATION '{absolute_path}data_engineering/gold/finance/fact_brand'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_finance.fact_brand_position (
  bu_sk INT,
  product_sk INT,
  brand_position_sk INT,
  month_sk STRING,
  measure_sk INT,
  cont_disc_ops_sk INT,
  currency_sk INT,
  version_sk INT,
  company_sk INT,
  flow_sk INT,
  value STRING,
  log_id BIGINT,
  created_date TIMESTAMP)
USING delta
LOCATION '{absolute_path}data_engineering/gold/finance/fact_brand_position'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_market.fact_gmims (
  product_sk INT,
  flow_sk INT,
  measure_sk INT,
  geography_sk INT,
  manufacturer_sk INT,
  month_sk STRING,
  country_code STRING,
  value DOUBLE,
  log_id BIGINT,
  created_date TIMESTAMP)
  USING delta
  LOCATION '{absolute_path}data_engineering/gold/market/fact_gmims'
  TBLPROPERTIES (
    'delta.enableDeletionVectors' = 'true',
    'delta.feature.deletionVectors' = 'supported',
    'delta.minReaderVersion' = '3',
    'delta.minWriterVersion' = '7'
  )
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_market.fact_gmi_validation_view (
    geography_node_name STRING,
    geography_id STRING,
    category_node_name STRING,
    category_id STRING,
    category_level INT,
    business_group STRING,
    category_name STRING,
    global_manufacturer_name STRING,
    global_manufacturer_id STRING,
    brand_position_type STRING,
    brand_position_name STRING,
    brand_position_id STRING,
    local_brand_name STRING,
    local_brand_id STRING,
    latest_available_date STRING,
    measure STRING,
    currency_or_unit_of_measure STRING,
    4w_1 DOUBLE,
    4w_10 DOUBLE,
    4w_11 DOUBLE,
    4w_12 DOUBLE,
    4w_13 DOUBLE,
    4w_14 DOUBLE,
    4w_15 DOUBLE,
    4w_16 DOUBLE,
    4w_17 DOUBLE,
    4w_18 DOUBLE,
    4w_19 DOUBLE,
    4w_2 DOUBLE,
    4w_20 DOUBLE,
    4w_21 DOUBLE,
    4w_22 DOUBLE,
    4w_23 DOUBLE,
    4w_24 DOUBLE,
    4w_25 DOUBLE,
    4w_26 DOUBLE,
    4w_27 DOUBLE,
    4w_28 DOUBLE,
    4w_29 DOUBLE,
    4w_3 DOUBLE,
    4w_30 DOUBLE,
    4w_31 DOUBLE,
    4w_32 DOUBLE,
    4w_33 DOUBLE,
    4w_34 DOUBLE,
    4w_35 DOUBLE,
    4w_36 DOUBLE,
    4w_37 DOUBLE,
    4w_38 DOUBLE,
    4w_39 DOUBLE,
    4w_4 DOUBLE,
    4w_5 DOUBLE,
    4w_6 DOUBLE,
    4w_7 DOUBLE,
    4w_8 DOUBLE,
    4w_9 DOUBLE,
    fy_1 DOUBLE,
    fy_2 DOUBLE,
    fy_3 DOUBLE,
    l12w DOUBLE,
    l12w_1 DOUBLE,
    l12w_2 DOUBLE,
    l4w DOUBLE,
    l4w_1 DOUBLE,
    l4w_2 DOUBLE,
    mat DOUBLE,
    mat_1 DOUBLE,
    mat_2 DOUBLE,
    mth_1 DOUBLE,
    mth_10 DOUBLE,
    mth_11 DOUBLE,
    mth_12 DOUBLE,
    mth_13 DOUBLE,
    mth_14 DOUBLE,
    mth_15 DOUBLE,
    mth_16 DOUBLE,
    mth_17 DOUBLE,
    mth_18 DOUBLE,
    mth_19 DOUBLE,
    mth_2 DOUBLE,
    mth_20 DOUBLE,
    mth_21 DOUBLE,
    mth_22 DOUBLE,
    mth_23 DOUBLE,
    mth_24 DOUBLE,
    mth_25 DOUBLE,
    mth_26 DOUBLE,
    mth_27 DOUBLE,
    mth_28 DOUBLE,
    mth_29 DOUBLE,
    mth_3 DOUBLE,
    mth_30 DOUBLE,
    mth_31 DOUBLE,
    mth_32 DOUBLE,
    mth_33 DOUBLE,
    mth_34 DOUBLE,
    mth_35 DOUBLE,
    mth_36 DOUBLE,
    mth_4 DOUBLE,
    mth_5 DOUBLE,
    mth_6 DOUBLE,
    mth_7 DOUBLE,
    mth_8 DOUBLE,
    mth_9 DOUBLE,
    qtr_1 DOUBLE,
    qtr_10 DOUBLE,
    qtr_11 DOUBLE,
    qtr_12 DOUBLE,
    qtr_2 DOUBLE,
    qtr_3 DOUBLE,
    qtr_4 DOUBLE,
    qtr_5 DOUBLE,
    qtr_6 DOUBLE,
    qtr_7 DOUBLE,
    qtr_8 DOUBLE,
    qtr_9 DOUBLE,
    ytd DOUBLE,
    ytd_1 DOUBLE,
    ytd_2 DOUBLE,
    pc_4w_1 DOUBLE,
    pc_4w_2 DOUBLE,
    pc_4w_3 DOUBLE,
    pc_4w_4 DOUBLE,
    pc_4w_5 DOUBLE,
    pc_4w_6 DOUBLE,
    pc_4w_7 DOUBLE,
    pc_fy_2 DOUBLE,
    pc_mth_1 DOUBLE,
    pc_mth_2 DOUBLE,
    pc_mth_3 DOUBLE,
    pc_mth_4 DOUBLE,
    pc_mth_5 DOUBLE,
    pc_mth_6 DOUBLE,
    pc_qtr_1 DOUBLE,
    pc_qtr_2 DOUBLE,
    reported_key STRING,
    cell_focus INT,
    geography_level INT,
    log_id INT,
    created_date TIMESTAMP
)
USING delta
LOCATION '{absolute_path}data_engineering/gold/market/fact_gmi_validation_view'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_market.gmi_latest_available (
    geography_sk INT,
    country_code STRING,
    country_name STRING,
    product_sk INT,
    product_form_code STRING,
    product_form_name STRING,
    month_sk STRING,
    latest_available_date STRING,
    month_name STRING,
    job_id INT,
    created_date TIMESTAMP
)
USING delta
LOCATION '{absolute_path}data_engineering/gold/market/gmi_latest_available'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_market.country_bu_map (
    geography_sk INT,
    country_code STRING,
    country_name STRING,
    bu_description STRING,
    bu_code STRING
)
USING delta
LOCATION '{absolute_path}data_engineering/gold/market/country_bu_map'
TBLPROPERTIES (
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.deletionVectors' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7'
)
"""
 
spark.sql(sql_query)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fact **Views**

# COMMAND ----------

sql_query = f"""
CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.vw_fact_brand AS SELECT
  CAST(f.bu_sk AS int) AS `BU SK`,
  CAST(f.product_sk AS int) AS `Product SK`,
  CAST(f.brand_sk AS int) AS `Brand SK`,
  CAST(f.month_sk AS int) AS `Month SK`,
  CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
  CAST(f.currency_sk AS int) AS `Currency SK`,
  CAST(f.version_sk AS int) AS `Version SK`,
  CAST(f.flow_sk AS int) AS `Flow SK`,
  CAST(f.measure_sk AS int) AS `Measure SK`,
  CAST(f.value AS DOUBLE) AS `Value`
FROM
  {uc_catalog_name}.gold_finance.fact_brand f
  where f.bu_sk !=-1 and f.product_sk!=-1
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.vw_fact_brand_position AS SELECT
  CAST(f.bu_sk AS int) AS `BU SK`,
  CAST(f.product_sk AS int) AS `Product SK`,
  CAST(f.brand_position_sk AS int) AS `Brand Position SK`,
  CAST(f.month_sk AS int) AS `Month SK`,
  CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
  CAST(f.currency_sk AS int) AS `Currency SK`,
  CAST(f.version_sk AS int) AS `Version SK`,
  CAST(f.flow_sk AS int) AS `Flow SK`,
  CAST(f.measure_sk AS int) AS `Measure SK`,
  CAST(f.value AS DOUBLE) AS `Value`
FROM
  {uc_catalog_name}.gold_finance.fact_brand_position f
  where f.bu_sk !=-1 and f.product_sk!=-1
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.vw_fact_customer AS SELECT
  CAST(f.bu_sk AS int) AS `BU SK`,
  CAST(f.product_sk AS int) AS `Product SK`,
  CAST(f.customer_sk AS int) AS `Customer SK`,
  CAST(f.month_sk AS int) AS `Month SK`,
  CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
  CAST(f.currency_sk AS int) AS `Currency SK`,
  CAST(f.version_sk AS int) AS `Version SK`,
  CAST(f.flow_sk AS int) AS `Flow SK`,
  CAST(f.measure_sk AS int) AS `Measure SK`,
  CAST(f.value AS DOUBLE) AS `Value`
FROM
  {uc_catalog_name}.gold_finance.fact_customer f
  where f.bu_sk !=-1 and f.product_sk!=-1
"""

spark.sql(sql_query)

# COMMAND ----------

sql_query = f"""
CREATE OR REPLACE VIEW {uc_catalog_name}.gold_market.vw_fact_gmi AS SELECT
  bu.bu_sk as `BU SK`,
  F.product_sk as `Product SK`,
  F.flow_sk as `Flow SK`,
  F.month_sk as `Month SK`,
  F.measure_sk as `Measure SK`,
  F.geography_sk as `Geography SK`,
  F.manufacturer_sk as `Manufacturer SK`,
  F.value as `Value`
from
  {uc_catalog_name}.gold_market.fact_gmims as F
    inner join {uc_catalog_name}.gold_market.country_bu_map cbm
      on F.geography_sk = cbm.geography_sk
    inner join {uc_catalog_name}.gold_master_data.business_unit bu
      on cbm.bu_code = bu.bu_code
where
  (
    bu.is_active is null
    or bu.is_active is true
  )
  and bu.bu_description is not null
"""

spark.sql(sql_query)
