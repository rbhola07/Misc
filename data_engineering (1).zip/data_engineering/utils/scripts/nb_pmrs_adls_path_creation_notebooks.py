# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 6 Sept 2024        |    Gokul Prasanth S  |    Creating ADLS location. |
# MAGIC
# MAGIC ## Purpose
# MAGIC The Purpose of this notebook is to create logging tables.
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC ####importing necessary functions

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col

# COMMAND ----------

# MAGIC %md
# MAGIC ####reading the data from the widgets

# COMMAND ----------

# Create widgets for external location, UC catalog name, and object owner SPN
dbutils.widgets.text("external_location", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("deletion_flag", "False")

external_location = dbutils.widgets.get("external_location")
uc_catalog_name   = dbutils.widgets.get("uc_catalog_name")
deletion_flag     = dbutils.widgets.get("deletion_flag")

dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("deletion_flag", deletion_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ####reading the catalog data for absolute path

# COMMAND ----------

# Describe the external location and get the absolute path
df = spark.sql(f"DESCRIBE EXTERNAL LOCATION `{external_location.strip()}`")
absolute_path = df.select(col('url')).filter(col('name') == external_location.strip()).head()[0]
print("UC Catalog Name    : ", uc_catalog_name)
print("Deletion flag      : ", deletion_flag)
print("Absolute path      : ", absolute_path)
print("external_location  : ", external_location)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### deleting the unnecassary tables

# COMMAND ----------

def delete_files_and_tables_from_csv(csv_path, deletion_flag=False):
    if deletion_flag == "True":
        df_csv = spark.read.csv(csv_path, header=True)
        df_csv.display()  
 
        for row in df_csv.collect():
            file_location, table_name, view_name, sql_query = row['file_location'], row['table_name'], row['view_name'], row['sql_query']
 
            if file_location:
                dbutils.fs.rm(file_location, True)
                print(f"Successfully deleted file at {file_location}")
 
            if table_name:
                spark.sql(f"DROP TABLE IF EXISTS {table_name}")
                print(f"Successfully dropped table {table_name}")
 
            if view_name:
                spark.sql(f"DROP VIEW IF EXISTS {view_name}")
                print(f"Successfully dropped view {view_name}")
           
            if sql_query:
                formatted_query = f"""{sql_query}"""
                spark.sql(formatted_query)
                print(f"Successfully executed SQL query: {formatted_query}")
    else:
        print("Delete function flag is set to False. Skipping deletion.")
        return
 
csv_path = f"/Volumes/{uc_catalog_name}/config_details/pmrs_volume_configs/delete_table.csv"
delete_files_and_tables_from_csv(csv_path, deletion_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ####folder creation script

# COMMAND ----------

# List of ADLS locations to create using f-strings for absolute_path
adls_locations = [
    f"{absolute_path}/data_engineering/bronze/raw/finance/transaction_data/excel/",
    f"{absolute_path}/data_engineering/bronze/raw/finance/transaction_data/csv/",
    f"{absolute_path}/data_engineering/bronze/raw/master_data/excel",
    f"{absolute_path}/data_engineering/bronze/raw/master_data/csv",
    f"{absolute_path}/data_engineering/bronze/staging/master_data/",
    f"{absolute_path}/data_engineering/bronze/staging/finance/",
    f"{absolute_path}/data_engineering/silver/finance/",
    f"{absolute_path}/data_engineering/silver/master_data/",
    f"{absolute_path}/data_engineering/gold/finance/",
    f"{absolute_path}/data_engineering/gold/master_data/",
    f"{absolute_path}/data_engineering/configs_volume/web_app_configs",
    f"{absolute_path}/data_engineering/technical_jars_volume/",
    f"{absolute_path}/data_engineering/logs/"
]

def create_adls_folders(adls_locations):
    for location in adls_locations:
        try:
            dbutils.fs.mkdirs(location)
            print(f"Created folder: {location}")
        except Exception as e:
            print(f"Error creating folder {location}: {str(e)}")

# Call the function
create_adls_folders(adls_locations)
