# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 23 Sept 2024        |    Vinod/Gokul           |    Reject. |
# MAGIC
# MAGIC ## Purpose
# MAGIC The purpose of the notebook is to move to reject folder if pipeline is failed.

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intialize ADF Parameters

# COMMAND ----------

# Remove all existing widgets
dbutils.widgets.removeAll()

# Retrieve task values from the previous task "Raw_to_Bronze_staging_ingestion"
debug_flag           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
external_location    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
uc_catalog_name      = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
processing_file_path = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="processing_file_path") 
username             = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
log_id               = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id") 


# Set task values for the current task
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("processing_file_path", processing_file_path)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("log_id", log_id)

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = log_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Main Orchestration Move to Reject

# COMMAND ----------

try:
    # Split the processing file path to get the directory components
    reject_path      = processing_file_path.split('/')

    # Extract the file name from the last element of the path
    reject_file_name = reject_path[-1]

    # Create the new file name with log_id
    new_file_name    = str(log_id) + '_' + reject_file_name

    # Determine the archive file path based on data_feed
    if data_feed.startswith('finance'):
        reject_file_path = reject_path[:11] + ['reject'] + [new_file_name]
    elif data_feed.startswith('master_data'):
        reject_file_path = reject_path[:9] + ['reject'] + [new_file_name]
    else:
        print("data_feed doesn't matched with function")

    # Convert the list back into a string to form the new file path
    reject_file_path = '/'.join(reject_file_path)

    # Copy the file to the reject location
    dbutils.fs.mv(processing_file_path, reject_file_path)

    # Print debug information if debug_flag is set
    if debug_flag == "1":
        print(f"File moved to reject path: {reject_file_path}\n")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1  
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Moved to reject after completing delta write", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job(job_id,run_id, module_id, feed_type_id, feed_id, status_success_id,uc_catalog_name)
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "file moved to reject folder", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
