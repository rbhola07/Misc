# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks config Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 10 Sept 2024        |    Gokul         |    config utils |
# MAGIC | 11 Nov 2024         |   Vinod          |    Additional Functionalities added |
# MAGIC
# MAGIC ## Purpose
# MAGIC The purpose of the document is to have all the utility function that will be used by all the notebooks
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark.sql
from pyspark.sql import functions as F, Row, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import ( _parse_datatype_string, IntegerType, StringType, TimestampType, 
    FloatType, DoubleType, BooleanType, IntegralType, DateType, StructType, StructField,LongType)
from pyspark.sql.functions import ( col, lit, current_timestamp, desc, row_number, size, replace, to_date, month, 
                year, last, coalesce, trim, concat, regexp_replace, concat_ws, when, monotonically_increasing_id,split, expr)
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC #### Functions

# COMMAND ----------

def get_param_data(catalog_name):
    """
    Reads the ingestion configuration sheet from the specified catalog and returns it as a DataFrame.

    Parameters:
    catalog_name (str): The name of the catalog to read the configuration from.

    Returns:
    DataFrame: A Spark DataFrame containing the configuration data.
    """
    # Read the CSV file into a DataFrame with header option set to true
    param = spark.read.format("csv") \
                      .option("header", "true") \
                      .load(f"/Volumes/{catalog_name}/config_details/pmrs_volume_configs/ingestion_configuration_sheet.csv")
                      
    return param

# COMMAND ----------

def get_config_data(data_feed, catalog_name, stream):
    """
    Retrieves and processes the configuration data for the given data feed.

    Parameters:
    data_feed (str): The specific data feed to retrieve configuration for.
    catalog_name (str): The name of the catalog where the configuration files are stored.
    stream (str): The stream type (e.g., "master", "finance", "market") to determine the configuration file path.

    Returns:
    dict: The configuration data for the specified data feed.

    Raises:
    ValueError: If the stream type is invalid.
    """
    # Determine the configuration file path based on the stream type
    if "master" in stream:
        config_file_path = f"/Volumes/{catalog_name}/config_details/pmrs_volume_configs/master_table_metadata_file.json"
    elif "finance" in stream:
        config_file_path = f"/Volumes/{catalog_name}/config_details/pmrs_volume_configs/finance_fact_metadata_file.json"
    elif "market" in stream:
        config_file_path = f"/Volumes/{catalog_name}/config_details/pmrs_volume_configs/market_fact_metadata_file.json"
    elif "supply_chain" in stream:
        config_file_path = f"/Volumes/{catalog_name}/config_details/pmrs_volume_configs/supply_chain_fact_metadata_file.json"
    else:
        raise ValueError("Invalid data feed: {}".format(stream))

    with open(config_file_path, "r") as file:
        config_data = json.load(file).get(data_feed, {})
    
    return config_data

# COMMAND ----------

def fetch_config(param, datafeed):
    """
    Function to return configuration data for the specified data feeds.

    Parameters:
    param (DataFrame): The DataFrame containing the configuration data.
    datafeed (str): A comma-separated string of data feeds to filter the configuration data.

    Returns:
    DataFrame: A Spark DataFrame containing the filtered configuration data.
    """
    # Split the datafeed string into a list of data feeds
    datafeed_list = datafeed.split(",")
    
    # Filter the DataFrame to include only the specified data feeds
    df = param.filter(col("data_feed").isin(datafeed_list))
    
    return df

# COMMAND ----------

def read_excel_to_df(path_final, sheet_name, cell, header, schema='', maxByteArraySize='200000000'):
    """
    Function to read an Excel file into a Spark DataFrame.

    Parameters:
    path_final (str): The path to the Excel file.
    sheet_name (str): The name of the sheet to read from.
    cell (str): The cell range to read from.
    header (bool): Whether the Excel file has a header row.
    schema (str, optional): The schema to apply to the DataFrame. Defaults to an empty string.
    maxByteArraySize (str, optional): The maximum byte array size. Defaults to '200000000'.

    Returns:
    DataFrame: A Spark DataFrame containing the data from the Excel file.

    Raises:
    Exception: If the file does not end with '.xlsx'.
    """
    # Check if a schema is provided
    if schema != '':
        df = spark.read.format("com.crealytics.spark.excel") \
                       .schema(schema) \
                       .option("dataAddress", f"'{sheet_name}'!{cell}") \
                       .option("header", header) \
                       .option("inferSchema", "false") \
                       .option("maxByteArraySize", maxByteArraySize) \
                       .load(path_final)
    else:
        df = spark.read.format("com.crealytics.spark.excel") \
                       .option("dataAddress", f"'{sheet_name}'!{cell}") \
                       .option("header", header) \
                       .option("inferSchema", "true") \
                       .option("maxByteArraySize", maxByteArraySize) \
                       .load(path_final)

    # Check if the file has the correct extension
    if not path_final.endswith('.xlsx'):
        raise Exception("file_name needs to end in .xlsx")

    return df

# COMMAND ----------

def read_csv_to_df(path_final, header, schema='', delimiter=','):
    """
    Function to read a CSV file into a Spark DataFrame.

    Parameters:
    path_final (str): The path to the CSV file.
    header (bool): Whether the CSV file has a header row.
    schema (str, optional): The schema to apply to the DataFrame. Defaults to an empty string.
    delimiter (str, optional): The delimiter used in the CSV file. Defaults to ','.

    Returns:
    DataFrame: A Spark DataFrame containing the data from the CSV file.

    Raises:
    Exception: If the file does not end with '.csv'.
    """
    # Check if a schema is provided
    if schema:
        df = spark.read.format("csv") \
                        .option("header", header) \
                        .schema(schema) \
                        .option("inferSchema", "false") \
                        .option("delimiter", delimiter) \
                        .load(path_final)
    else:
        df = spark.read.format("csv") \
                       .option("header", header) \
                       .option("inferSchema", "true") \
                       .option("delimiter", delimiter) \
                       .load(path_final)
                       
    # Check if the file has the correct extension
    if not path_final.endswith('.csv'):
        raise Exception("file_name needs to end in .csv")

    return df

# COMMAND ----------

def return_absolute_path(external_location):
    """
    Retrieves the absolute path of the specified external location.

    Args:
    external_location (str): The name of the external location.

    Returns:
    str: The absolute path of the external location.
    """
    # Describe the external location to get its details
    df = spark.sql(f"DESCRIBE EXTERNAL LOCATION `{external_location.strip()}`")
    
    # Select the 'url' column and filter by the external location name
    absolute_path = ( df.select(col('url'))
                        .filter(col('name') == external_location.strip())
                        .head()[0] ) # Get the first row and extract the 'url' value

    return absolute_path

# COMMAND ----------

import re
 
def clean_column_names(columns):

    """
    Function to read the dataframe columns and clean the column names.

    Parameters:
    columns (list): A list of column names to be cleaned.
 
    Returns:
    dict: A dictionary with old column names as keys and new cleaned column names as values.
    """

    cleaned_columns_dict = {}

    for col in columns:

        cleaned_col = col

        # Replace '%' with 'percent'
        cleaned_col = re.sub(r'%', 'percent', cleaned_col)

        # Replace periods followed by a lowercase letter with an underscore and the letter
        cleaned_col = re.sub(r'\.(?=[a-z])', '_', cleaned_col)

        # Remove specific characters like quotes and dots
        cleaned_col = re.sub(r"[',.]", '', cleaned_col)

        # Replace all non-alphanumeric characters (spaces, slashes, backslashes, dashes, etc.) with underscores
        cleaned_col = re.sub(r'[\\\/ ,;{}()\n\t&=–/-]', '_', cleaned_col)

        # Convert camelCase or PascalCase to snake_case
        cleaned_col = re.sub(r'([a-z])([A-Z])', r'\1_\2', cleaned_col)

        # Lowercase everything
        cleaned_col = cleaned_col.lower()

        # Replace multiple underscores with a single underscore
        cleaned_col = re.sub(r'__+', '_', cleaned_col)

        # Remove leading/trailing underscores
        cleaned_col = cleaned_col.strip('_')
        cleaned_columns_dict[col] = cleaned_col

    return cleaned_columns_dict

# COMMAND ----------

def column_sequence_check(df_source, datafeed):
    """
    Function to check if the sequence and count of the columns are correct for the source file.

    Parameters:
    df_source (DataFrame): The source DataFrame to check.
    datafeed (str): The data feed identifier to fetch the expected column configuration.

    Raises:
    Exception: If the number of columns or their sequence does not match the expected configuration.
    """
    # Get the columns from the source DataFrame
    df_source_columns = df_source.columns
    col_source_count  = len(df_source_columns)
    
    # Fetch the expected columns and their count from the configuration data
    expected_columns   = config_data[datafeed]["column_list"]
    col_expected_count = config_data[datafeed]["column_count"]

    # Check if the number of columns matches the expected count
    if col_source_count != col_expected_count:
        raise Exception("Incorrect number of columns. Expected number of columns: " + str(col_expected_count))
    
    # Check if the sequence of columns matches the expected sequence
    elif df_source_columns != expected_columns:
        raise Exception("Incorrect sequence of columns. Expected column sequence: " + str(expected_columns))

# COMMAND ----------

def processing_file_check_func(processing_file_path):
    """
    This function checks if a specific file exists in a given directory path.
    
    Parameters:
    processing_file_path (str): The full path of the file to check.
    
    Returns:
    tuple: A tuple containing the file path and file name if the file exists, otherwise (None, None).
    """
    try:
        # Split the path to get the directory and file name
        path_parts = processing_file_path.split('/')
        source_dir_path = '/'.join(path_parts[:-1])
        processing_file_name = path_parts[-1]
        
        # List all files in the source directory
        files_list = dbutils.fs.ls(source_dir_path)
        if not files_list:
            raise FileNotFoundError("No files found in the specified directory.")

        # Filter the files that match the processing file name
        matching_files = [file for file in files_list if file.isFile() and file.path.split("/")[-1] == processing_file_name]

        if matching_files:
            matching_file = matching_files[0]
            print("File exists in the storage location")
            return matching_file.path, matching_file.name
        else:
            raise FileNotFoundError("No matching file found.")
    except Exception as e:
        print(f"Error: {e}")
        return None, None

# COMMAND ----------

def move_to_archive(processing_file_path, log_id, debug_flag, data_feed):
    """
    Function to move the file to the Archive folder.

    Parameters:
    processing_file_path (str): The full path of the file to be moved.
    log_id (int): The log ID to be appended to the archived file name.
    debug_flag (str): Flag to print debug information.
    data_feed (str): The type of data feed to determine the archive path.

    Returns:
    None
    """
    # Split the processing file path to get the directory components
    archive_path = processing_file_path.split('/')
    
    # Extract the file name from the last element of the path
    file_name = archive_path[-1]
    
    # Create the new file name with log_id
    new_file_name = str(log_id) + '_' + file_name
    
    # Determine the archive path based on data_feed
    if data_feed.startswith('finance'):
        archive_file_path = archive_path[:11] + ['archive'] + [new_file_name]
    elif data_feed.startswith('market'):
        archive_file_path = archive_path[:11] + ['archive'] + [new_file_name]
    elif data_feed.startswith('master_data'):
        archive_file_path = archive_path[:9] + ['archive'] + [new_file_name]
    else:
        print("data_feed doesn't matched with function")
    
    # Convert the list back into a string
    archive_file_path = '/'.join(archive_file_path)
    
    # Move the file to the archive location
    dbutils.fs.mv(processing_file_path, archive_file_path)

    return archive_file_path

# COMMAND ----------

def delta_table_exists(spark, path):
    """
    Function to check whether the Delta table exists or not.

    Parameters:
    spark (SparkSession): The Spark session.
    path (str): The path to the Delta table.

    Returns:
    bool: True if the Delta table exists, False otherwise.
    """
    # Check if the path is valid
    if not path:
        print("Invalid Delta table path: Path cannot be empty.")
        return False
    try:
        # Try to access the Delta table at the given path
        DeltaTable.forPath(spark, path)
        return True
    except Exception as e:
        # Return False if an exception occurs
        return False

# COMMAND ----------

def create_silver_calendar(start_date, end_date,log_id):
    """
    Create a silver calendar dimension table with a range of dates from start_date to end_date.

    Parameters:
    start_date (str): The start date in 'YYYY-MM-DD' format.
    end_date (str): The end date in 'YYYY-MM-DD' format.

    Returns:
    DataFrame: A DataFrame containing the month dimension table.
    """
    
    from datetime import datetime
    from pyspark.sql.functions import col, concat, date_format, lit, lpad, month, year, trunc, quarter, when, current_timestamp, to_date, sequence, explode
    from pyspark.sql.types import LongType

    # Generate a DataFrame with a range of dates
    df = spark.range(1).selectExpr(f"explode(sequence(to_date('{start_date}'), to_date('{end_date}'), interval 1 month)) as date")

    # Create the month dimension table with columns ordered directly
    month_dim_df = df.select(
        concat(year(col("date")), lpad(month(col("date")), 2, '0')).alias("month_sk"),  # Create a surrogate key for the month
        date_format(trunc(col("date"), "month"), "MMMM d, yyyy").alias("date"),  # Format the date to 'MMMM d, yyyy'
        month(col("date")).alias("month_code"),  # Extract the month code
        concat(date_format(col("date"), "MMM"), lit(" "), year(col("date"))).alias("month_short_description"),  # Create a short description for the month
        concat(date_format(col("date"), "MMMM"), lit(" "), year(col("date"))).alias("month_long_description"),  # Create a long description for the month
        concat(lit("Q"), quarter(col("date"))).alias("quarter"),  # Determine the quarter of the year
        when(quarter(col("date")) <= 2, "H1").otherwise("H2").alias("half_year"),  # Determine the half of the year
        year(col("date")).alias("year"),  # Extract the year
        lit(True).alias("is_active"),  # Flag to indicate if the record is active
        lit(False).alias("has_data"),  # Flag to indicate if the record has data
        lit(log_id).cast(LongType()).alias('log_id'), # Log ID for tracking
        current_timestamp().alias("created_date"),  # Timestamp for when the record was created
        current_timestamp().alias("updated_date")  # Timestamp for when the record was last updated
    )
    
    return month_dim_df

# COMMAND ----------

def create_gold_calendar(start_date, end_date,log_id):
    """
    Create a gold calendar dimension table with a range of dates from start_date to end_date.

    Parameters:
    start_date (str): The start date in 'YYYY-MM-DD' format.
    end_date (str): The end date in 'YYYY-MM-DD' format.
    debug_flag (str): A flag to indicate whether to display the DataFrame for debugging.

    Returns:
    DataFrame: A DataFrame containing the month dimension table.
    """
    
    from datetime import datetime
    from pyspark.sql.functions import col, concat, date_format, lit, lpad, month, year, quarter, when, current_timestamp, trunc
    from pyspark.sql.types import LongType

    # Generate a DataFrame with a range of dates
    date_df = spark.range(1).selectExpr(f"explode(sequence(to_date('{start_date}'), to_date('{end_date}'), interval 1 month)) as date")

    # Create the month dimension table with columns ordered directly
    month_dim_df = date_df.select(
        concat(year(col("date")), lpad(month(col("date")), 2, "0")).alias("month_sk"),  # Create a surrogate key for the month
        date_format(trunc(col("date"), "month"), "MMMM d, yyyy").alias("date"),  # Format the date to 'MMMM d, yyyy'
        month(col("date")).alias("month_code"),  # Extract the month code
        concat(date_format(col("date"), "MMM"), lit(" "), year(col("date"))).alias("month_short_description"),  # Create a short description for the month
        concat(date_format(col("date"), "MMMM"), lit(" "), year(col("date"))).alias("month_long_description"),  # Create a long description for the month
        concat(lit("Q"), quarter(col("date"))).alias("quarter"),  # Determine the quarter of the year
        when(quarter(col("date")) <= 2, "H1").otherwise("H2").alias("half_year"),  # Determine the half of the year
        year(col("date")).alias("year"),  # Extract the year
        ((month(col("date")) == month(current_timestamp())) & (year(col("date")) == year(current_timestamp()))).alias("current_month_flag"),  # Flag for current month
        ((quarter(col("date")) == quarter(current_timestamp())) & (year(col("date")) == year(current_timestamp()))).alias("current_quarter_flag"),  # Flag for current quarter
        (year(col("date")) == year(current_timestamp())).alias("current_year_flag"),  # Flag for current year
        lit(True).alias("is_active"),  # Flag to indicate if the record is active
        lit(False).alias("has_data"),  # Flag to indicate if the record has data
        lit(log_id).cast(LongType()).alias('log_id'),  # Log ID for tracking
        current_timestamp().alias("created_date"),  # Timestamp for when the record was created
        current_timestamp().alias("updated_date"),  # Timestamp for when the record was last updated
    )

    return month_dim_df

# COMMAND ----------

def concurrent_external_table_delta_write(df_final, delta_path, delta_db_name, delta_table_name, partition_columns=None, catalog_name="default", object_owner_spn=None, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full"):
    """
    Function to write data to a Delta table with support for schema merging and retries.

    Parameters:
    df_final (DataFrame): The DataFrame to write to the Delta table.
    delta_path (str): The path to the Delta table.
    delta_db_name (str): The name of the Delta database.
    delta_table_name (str): The name of the Delta table.
    partition_columns (list, optional): List of columns to partition by. Defaults to None.
    catalog_name (str, optional): The catalog name. Defaults to "default".
    object_owner_spn (str, optional): The object owner SPN. Defaults to None.
    retry_count (int, optional): The current retry count. Defaults to 0.
    max_retries (int, optional): The maximum number of retries. Defaults to 10.
    mergeSchema_flag (bool, optional): Flag to enable schema merging. Defaults to False.
    delta_overwrite_mode (str, optional): The overwrite mode ("full" or "append"). Defaults to "full".

    Returns:
    None

    Raises:
    ValueError: If there is a schema mismatch.
    Exception: If writing to Delta fails after retries.
    """
    write_mode     = "overwrite" if delta_overwrite_mode.lower() == "full" else "append"
    partition_mode = "dynamic" if write_mode == "overwrite" else "static"
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", partition_mode)

    print(f"Write_mode : {write_mode}, Partition_mode : {partition_mode}, MergeSchema_flag : {mergeSchema_flag}")

    # Ensure database exists and set ownership
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog_name}.{delta_db_name}")

    try:
        table_exists = spark.catalog.tableExists(f"{catalog_name}.{delta_db_name}.{delta_table_name}")

        if table_exists:
            print("delta table exists")
            existing_table  = DeltaTable.forPath(spark, delta_path)
            existing_schema = {field.name: field.dataType for field in existing_table.toDF().schema.fields}
            df_schema       = {field.name: field.dataType for field in df_final.schema.fields}

            # Validate schema compatibility
            if not mergeSchema_flag:
                schema_mismatch = False
                for col_name, col_type in df_schema.items():
                    if col_name not in existing_schema:
                        schema_mismatch = True
                        print(f"Column {col_name} is missing in the existing schema.")
                    elif existing_schema[col_name] != col_type:
                        schema_mismatch = True
                        print(f"Data type mismatch for column {col_name}. Existing: {existing_schema[col_name]}, Incoming: {col_type}")

                if schema_mismatch:
                    raise ValueError(f"Schema mismatch. Existing: {existing_schema}, Incoming: {df_schema}")
                else:
                    print("Schema is compatible")
            else:
                print("MergeSchema is true")
        else:
            print("Delta table does not exist")

            columns = ', '.join([f"`{col_name}` {col_type.upper()}" for col_name, col_type in df_final.dtypes])
            partition_query = ""
            print("Partition_columns :", partition_columns)
            if partition_columns:
                partition_columns_str = ','.join(partition_columns)
                partition_query = f"PARTITIONED BY ({partition_columns_str})"

            create_table_sql = f"""
                CREATE EXTERNAL TABLE IF NOT EXISTS {catalog_name}.{delta_db_name}.{delta_table_name} (
                                {columns}  )
                                USING DELTA
                                {partition_query}
                                LOCATION '{delta_path}'
            """

            # print(create_table_sql)
            spark.sql(create_table_sql)

            print(f"Table creation successful {catalog_name}.{delta_db_name}.{delta_table_name}")

        writer = df_final.write.format("delta").mode(write_mode)
        if mergeSchema_flag:
            writer = writer.option("mergeSchema", mergeSchema_flag)
        if partition_columns and all(col for col in partition_columns if col in df_final.columns):
            writer = writer.partitionBy(*partition_columns)

        writer.save(delta_path)

        print(f"Write operation completed successfully for table: {delta_table_name}")

    except Exception as e:
        if 'ConcurrentAppendException' in e.__class__.__name__ and retry_count < max_retries:
            print(f"{e.__class__.__name__} Retry {retry_count + 1}/{max_retries}: after 30s")
            time.sleep(30)
            concurrent_external_table_delta_write(df_final, delta_path, delta_db_name, delta_table_name, partition_columns, catalog_name, object_owner_spn, retry_count + 1, max_retries, mergeSchema_flag, delta_overwrite_mode)
        else:
            print(f"Failed to perform Delta table operation: {str(e)}")
            raise e

# COMMAND ----------

def descentant_table_delta_write(df_final, descendant_path, descendant_db, descendant_table, partition_columns, catalog_name, object_owner_spn, retry_count=0, overwriteSchema_flag="true", delta_overwrite_mode="full"):
    """
    Function to write data to a Delta table, with support for schema overwriting and retries.

    Parameters:
    df_final (DataFrame): The DataFrame to write to the Delta table.
    descendant_path (str): The path to the Delta table.
    descendant_db (str): The name of the Delta database.
    descendant_table (str): The name of the Delta table.
    partition_columns (list): List of columns to partition by.
    catalog_name (str): The catalog name.
    object_owner_spn (str): The object owner SPN.
    retry_count (int, optional): The current retry count. Defaults to 0.
    overwriteSchema_flag (str, optional): Flag to enable schema overwriting. Defaults to "true".
    delta_overwrite_mode (str, optional): The overwrite mode ("full" or "append"). Defaults to "full".

    Returns:
    None

    Raises:
    Exception: If writing to Delta fails after retries.
    """
    try:
        # Determine write mode based on overwrite flag
        write_mode = "overwrite" if delta_overwrite_mode.lower() == "full" else "append"

        # Construct fully qualified table name
        table_name  = f"{catalog_name}.{descendant_db}.{descendant_table}"

        # Check if Delta table exists
        table_exists = False
        try:
            table_exists = DeltaTable.isDeltaTable(spark, descendant_path)
        except:
            table_exists = False

        if table_exists:
            # Load the existing Delta table
            delta_table = DeltaTable.forPath(spark, descendant_path)

            # Delete the existing records for the categories in the new data
            for partition_value in df_final.select(*partition_columns).distinct().collect():
                partition_filter = " AND ".join([f"{col} = '{partition_value[col]}'" for col in partition_columns])
                delta_table.delete(partition_filter)

            # Insert new records into the Delta table
            df_final.write.format("delta").mode("append").partitionBy(*partition_columns).save(descendant_path)

        else:
            # Initial write if Delta table doesn't exist
            writer = df_final.write.format("delta").mode(write_mode)

            # Apply schema overwrite if specified
            if overwriteSchema_flag.lower() == "true":
                writer = writer.option("overwriteSchema", "true")

            # Apply partitioning if columns are specified and exist in DataFrame
            if partition_columns and all(col in df_final.columns for col in partition_columns):
                writer = writer.partitionBy(*partition_columns)

            # Save the data to the specified Delta path
            writer.save(descendant_path)

            # Register the table in the Metastore
            spark.sql(f"""
                            CREATE TABLE IF NOT EXISTS {table_name}
                            USING DELTA
                            LOCATION '{descendant_path}'
            """)

        print(f"Delta table operation completed successfully for path: {descendant_path}")

    except Exception as e:
        # Handle errors, including retries for concurrency issues
        if 'ConcurrentAppendException' in e.__class__.__name__ and retry_count < 10:
            print(f"{e.__class__.__name__}: Retry {retry_count + 1}/10 after 30s")
            import time
            time.sleep(30)
            descentant_table_delta_write(
                df_final, descendant_path, descendant_db, descendant_table,
                partition_columns, catalog_name, object_owner_spn,
                retry_count + 1, overwriteSchema_flag, delta_overwrite_mode
            )
        else:
            print(f"Failed to perform Delta table operation: {str(e)}")
            raise e

# COMMAND ----------

def process_flatter_transformation(data_feed, df_final):
    """
    Function to process and transform data based on the specified data feed.

    Parameters:
    data_feed (str): The data feed identifier to determine the transformation logic.
    df_final (DataFrame): The DataFrame containing the data to be transformed.

    Returns:
    list: A list of dictionaries containing the transformed data.

    Raises:
    Exception: If any error occurs during the transformation process.
    """
    try:
        recs = []
        if data_feed == "finance_fact_icr_data":
            for index, row in df_final.toPandas().iterrows():
                # Initialize variables with default values
                business_unit_cost_c = c1 = cc_bu_type = c3 = fs_item_account = c5 = function = c7 = None
                
                # Assign values if they are not empty
                if len(row["business_unit_cost_c"]) > 0:
                    business_unit_cost_c = row["business_unit_cost_c"]
                if len(row["c1"]) > 0:
                    c1 = row["c1"]
                if len(row["cc_bu_type"]) > 0:
                    cc_bu_type = row["cc_bu_type"]
                if len(row["c3"]) > 0:
                    c3 = row["c3"]
                if len(row["fs_item_account"]) > 0:
                    fs_item_account = row["fs_item_account"]
                if len(row["c5"]) > 0:
                    c5 = row["c5"]
                if len(row["function"]) > 0:
                    function = row["function"]
                if len(row["c7"]) > 0:
                    c7 = row["c7"]

                # Create a dictionary for the transformed row
                string = {
                    "business_unit_cost_c": business_unit_cost_c,
                    "c1": c1,
                    "cc_bu_type": cc_bu_type,
                    "c3": c3,
                    "fs_item_account": fs_item_account,
                    "c5": c5,
                    "function": function,
                    "c7": c7,
                    "c8": row["c8"],
                    "monthly_icr": row["monthly_icr"],
                    "log_id": row["log_id"],
                    "created_at": row["created_at"],
                }
                recs.append(string)

        elif data_feed == "finance_fact_icr_target_collection_bu_crg":
            for index, row in df_final.toPandas().iterrows():
                # Initialize variables with default values
                business_unit_cost_c = c1 = cc_bu_type = c3 = cost_reporting_group = c5 = fs_item_account = c7 = function = c9 = None
                
                # Assign values if they are not empty
                if len(row["business_unit_cost_c"]) > 0:
                    business_unit_cost_c = row["business_unit_cost_c"]
                if len(row["c1"]) > 0:
                    c1 = row["c1"]
                if len(row["cc_bu_type"]) > 0:
                    cc_bu_type = row["cc_bu_type"]
                if len(row["c3"]) > 0:
                    c3 = row["c3"]
                if len(row["cost_reporting_group"]) > 0:
                    cost_reporting_group = row["cost_reporting_group"]
                if len(row["c5"]) > 0:
                    c5 = row["c5"]
                if len(row["fs_item_account"]) > 0:
                    fs_item_account = row["fs_item_account"]
                if len(row["c7"]) > 0:
                    c7 = row["c7"]
                if len(row["function"]) > 0:
                    function = row["function"]
                if len(row["c9"]) > 0:
                    c9 = row["c9"]

                # Create a dictionary for the transformed row
                string = {
                    "business_unit_cost_c": business_unit_cost_c,
                    "c1": c1,
                    "cc_bu_type": cc_bu_type,
                    "c3": c3,
                    "cost_reporting_group": cost_reporting_group,
                    "c5": c5,
                    "fs_item_account": fs_item_account,
                    "c7": c7,
                    "function": function,
                    "c9": c9,
                    "c10": row["c10"],
                    "monthly_rico": row["monthly_rico"],
                    "log_id": row["log_id"],
                    "created_at": row["created_at"],
                }
                recs.append(string)

        elif data_feed == "finance_fact_icr_data_bu_crg":
            for index, row in df_final.toPandas().iterrows():
                # Initialize variables with default values
                business_unit_cost_c = c1 = cc_bu_type = c3 = cost_reporting_group = c5 = fs_item_account = c7 = function = c9 = None
                
                # Assign values if they are not empty
                if len(row["business_unit_cost_c"]) > 0:
                    business_unit_cost_c = row["business_unit_cost_c"]
                if len(row["c1"]) > 0:
                    c1 = row["c1"]
                if len(row["cc_bu_type"]) > 0:
                    cc_bu_type = row["cc_bu_type"]
                if len(row["c3"]) > 0:
                    c3 = row["c3"]
                if len(row["cost_reporting_group"]) > 0:
                    cost_reporting_group = row["cost_reporting_group"]
                if len(row["c5"]) > 0:
                    c5 = row["c5"]
                if len(row["fs_item_account"]) > 0:
                    fs_item_account = row["fs_item_account"]
                if len(row["c7"]) > 0:
                    c7 = row["c7"]
                if len(row["function"]) > 0:
                    function = row["function"]
                if len(row["c9"]) > 0:
                    c9 = row["c9"]

                # Create a dictionary for the transformed row
                string = {
                    "business_unit_cost_c": business_unit_cost_c,
                    "c1": c1,
                    "cc_bu_type": cc_bu_type,
                    "c3": c3,
                    "cost_reporting_group": cost_reporting_group,
                    "c5": c5,
                    "fs_item_account": fs_item_account,
                    "c7": c7,
                    "function": function,
                    "c9": c9,
                    "c10": row["c10"],
                    "monthly_icr": row["monthly_icr"],
                    "log_id": row["log_id"],
                    "created_at": row["created_at"],
                }
                recs.append(string)
    except Exception as e:
        raise e

    return recs

# COMMAND ----------

def insert_dummy_record_if_needed(spark, catalog_name, delta_db_silver, delta_table_silver, var_sk):
    """
    Insert a dummy record with a special `var_sk` value (-1) if the target table is empty 
    or the `var_sk = -1` record is missing.

    Args:
        spark: SparkSession object.
        catalog_name: Catalog name for the database.
        delta_db_silver: Silver database name.
        delta_table_silver: Silver table name.
        var_sk: Surrogate key column name.
    """

    # Define the target table and load it into a DataFrame
    table_path = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"
    
    # Check if the table contains records or `var_sk = -1` is missing
    record_count = spark.sql(f"SELECT COUNT(1) FROM {table_path}").collect()[0][0]
    var_sk_neg1_exists = spark.sql(f"SELECT COUNT(1) FROM {table_path} WHERE {var_sk} = -1").collect()[0][0]

    # Insert dummy record if table is empty or `var_sk = -1` is missing
    if record_count == 0 or var_sk_neg1_exists == 0:
        print("Inserting UNK record: Table is empty or `var_sk = -1` not present.")
        
        # Build the dummy record using schema from the target table
        sql_insert_schema = spark.table(table_path).dtypes
        dummy_record = {}

        for column_name, column_type in sql_insert_schema:
            if column_name == var_sk:
                dummy_record[column_name] = -1  # Special case for `var_sk`
            elif column_name == 'dummy_flag':
                dummy_record[column_name] = False  # Set the `dummy_flag` as Boolean False
            elif column_name == 'log_id':
                dummy_record[column_name] = 0
            elif "int" in column_type:
                dummy_record[column_name] = 0  # Default integer value
            elif "string" in column_type:
                dummy_record[column_name] = "unk"  # Default string value
            elif "float" in column_type or "double" in column_type:
                dummy_record[column_name] = 0.0  # Default float/double value
            elif "date" in column_type or "timestamp" in column_type:
                dummy_record[column_name] = None  # Default for date/timestamp
            else:
                dummy_record[column_name] = None  # Default fallback

        # Create the dummy schema
        dummy_schema = StructType([
            StructField(column_name,LongType() if column_name == 'log_id' else
                                      StringType() if "string" in column_type else 
                                      IntegerType() if "int" in column_type else 
                                      FloatType() if "float" in column_type else 
                                      DoubleType() if "double" in column_type else 
                                      BooleanType() if "boolean" in column_type else 
                                      TimestampType() if "timestamp" in column_type else 
                                      DateType() if "date" in column_type else 
                                      NullType(), True)
            for column_name, column_type in sql_insert_schema])

        # Create DataFrame for dummy record
        dummy_df = spark.createDataFrame([Row(**dummy_record)], schema=dummy_schema)

        # Append the dummy record to the Delta Silver Path directly
        dummy_df.write.format("delta").mode("append").saveAsTable(table_path)
        print("Dummy record inserted.")
        dummy_df.display()
    else:
        print("Table already contains data and `var_sk = -1` exists, no insert needed.")



# COMMAND ----------


def process_staging_data(staging_df, surrogate_key, catalog_name, silver_db_name, silver_table_name, silver_table_path, table_owner, debug_mode):
    """
    Process the staging DataFrame to ensure database and table exist, validate schema, and handle Delta table properly.

    Args:
        staging_df: Input DataFrame to be processed.
        surrogate_key: Surrogate key column name.
        catalog_name: Catalog name for the database.
        silver_db_name: Silver database name.
        silver_table_name: Silver table name.
        silver_table_path: File path for the Delta table.
        table_owner: Owner of the table.
        debug_mode: Flag to enable debugging (1 for enabled, 0 for disabled).
    """

    # Ensure the database exists
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog_name}.{silver_db_name}")

    # Construct full table reference
    silver_table_full_path = f"{catalog_name}.{silver_db_name}.{silver_table_name}"

    # Check if table exists in the metastore
    table_exists = spark.catalog.tableExists(silver_table_full_path)
    print(f"Table Exists: {table_exists}")

    if table_exists:
        try:
            # Load the Delta table using its path
            existing_table = DeltaTable.forPath(spark, silver_table_path)
            print(f"Table {silver_table_full_path} found and accessible.")

            # Retrieve table schema for validation
            existing_schema = {field.name: field.dataType.simpleString() for field in existing_table.toDF().schema}
            staging_schema  = {field.name: field.dataType.simpleString() for field in staging_df.schema}

            # Identify schema mismatches
            missing_columns    = [col for col in staging_schema if col not in existing_schema]
            extra_columns      = [col for col in existing_schema if col not in staging_schema]
            mismatched_columns = [col for col in staging_schema if col in existing_schema and staging_schema[col] != existing_schema[col]]

            if missing_columns or extra_columns or mismatched_columns:
                error_message = "Schema mismatch detected."
                if missing_columns:
                    error_message += f" Missing columns in existing table: {missing_columns}."
                if extra_columns:
                    error_message += f" Extra columns in existing table: {extra_columns}."
                if mismatched_columns:
                    error_message += f" Mismatched column data types: {mismatched_columns}."
                raise ValueError(error_message)
            else:
                print("Schema matches, no issues detected.")

        except AnalysisException as e:
            print(f"Delta table {silver_table_full_path} appears to be corrupted or missing. Error: {str(e)}")

    else:
        # Table does not exist, create it
        column_definitions = ", ".join([f"{field.name} {field.dataType.simpleString()}" for field in staging_df.schema])

        create_table_query = f"""
            CREATE TABLE {silver_table_full_path} ({column_definitions})
            USING DELTA
            LOCATION '{silver_table_path}'
        """
        spark.sql(create_table_query)
        print(f"Table {silver_table_full_path} created at {silver_table_path}.")

# COMMAND ----------

def generate_surrogate_key(df, key_columns, col_name):
    """
    Function to generate a surrogate key by concatenating specified columns.

    Parameters:
    df (DataFrame): The DataFrame to add the surrogate key to.
    key_columns (list): A list of column names to concatenate for the surrogate key.
    col_name (str): The name of the new surrogate key column.

    Returns:
    DataFrame: The DataFrame with the new surrogate key column.
    """
    return df.withColumn(
        col_name, concat_ws(",", *[col(c) for c in key_columns])
    )

# COMMAND ----------

def process_surrogate_key_cleanup(df, surrogate_key_col):
    """
    Cleans up the surrogate key column by removing elements that start with 'lv' (case-insensitive)
    and returns a DataFrame with distinct rows.

    Args:
    df (DataFrame): The input DataFrame.
    surrogate_key_col (str): The name of the surrogate key column to be cleaned.

    Returns:
    DataFrame: A DataFrame with the cleaned surrogate key column and distinct rows.
    """
    return df.withColumn(
        "surrogate_key_array", split(col(surrogate_key_col), ",")
    ).withColumn(
        "temp_surrogate_key",
        expr("""
            array_join(
                filter(surrogate_key_array, x -> NOT lower(x) like 'lv%'), ','
            )
        """)
    ).drop("surrogate_key_array").distinct()

# COMMAND ----------

def validate_key_columns_for_nulls(staging_df, key_columns):
    """
    Validates that the key columns in the DataFrame do not contain null or empty values.

    :param staging_df: Spark DataFrame to validate.
    :param key_columns: List of key column names to check for null or empty values.
    :raises Exception: If any key column contains null or empty values.
    """
    null_key_columns = [
        col for col in key_columns 
        if staging_df.filter((staging_df[col].isNull()) | (trim(staging_df[col]) == "")).count() > 0
    ]
    if null_key_columns:
        raise Exception(f"Key columns contain null or empty values: {null_key_columns}")

