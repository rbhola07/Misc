# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Fact GMI Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |  13 Jan 2025     |    Aditya, Dhanapal          |    Notebook Created |
# MAGIC
# MAGIC
# MAGIC ## Purpose
# MAGIC This Notebook is used to load Fact GMI data
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType
from pyspark.sql.functions import (col, lit, lower, regexp_replace, regexp_extract, trim,current_timestamp, desc, row_number, size, replace, to_date, month,year, last, coalesce,expr)
from delta.tables import DeltaTable
import datetime
start_time = datetime.datetime.now()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Utils

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Widgets

# COMMAND ----------

debug_flag          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
uc_catalog_name     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
external_location   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
username            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
data_feed            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
log_id              = int(dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id"))


dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("log_id", log_id)

# COMMAND ----------


dbutils.widgets.removeAll()

dbutils.widgets.text("debug_flag","1")
debug_flag      = dbutils.widgets.get("debug_flag")

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = log_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username, "Market Silver Fact GMI Validation View Ingestion", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for Fact GMI Monthly", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    
    param = get_param_data(uc_catalog_name)

    # Fetch specific configuration
    process_feed_df                      = fetch_config(param, data_feed)
    
    stream = process_feed_df.select("stream").first()[0]

    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    # Display the filtered data
    display(process_feed_df)

    catalog_name                         = uc_catalog_name
    delta_db_staging                     = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging                  = process_feed_df.select("delta_table_staging").first()[0]

    # json values
    delta_path_silver                    = process_feed_df.select("delta_path_silver").first()[0]
    delta_table_silver                   = process_feed_df.select("delta_table_silver").first()[0]
    delta_db_silver                      = process_feed_df.select("delta_db_silver").first()[0]

    rename_columns = config_data.get("rename_cols_silver",{})
    if rename_columns:
        rename = True
    else:
        rename = False

    if debug_flag == "1":

        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

def unpivot(df, dim_cols, kpi_cols):
  df_new = df.select([col(x).cast("String") for x in df.columns])
  df_actual = df_new.drop(*dim_cols)
  columnsCount =str(len(kpi_cols))
  unpvt_format = ",".join(["'"+ x + "',`" + x +"`" for x in kpi_cols])
  final_unpvt_format = columnsCount + "," + unpvt_format
  final_format_unpvt = "stack(" + final_unpvt_format + ")" + " as (`MeasureType`,Mkt_Value)"
  return df_new.select(*dim_cols, expr(final_format_unpvt))

# COMMAND ----------

try:
    tables = {
        
        "df_fact": f"{catalog_name}.{delta_db_staging}.{delta_table_staging}"
        }

    for df_name, table in tables.items():
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Reading fact data failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact data read successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

try:
  df_fact_columns = [col for col in df_fact.columns if col in ['is_active', 'log_id', 'created_date']]
  df_fact_final =  df_fact.filter((col("measure").isin(['Value','Volume','Value Share','Volume Share'])) & 
                                (col("category_level") < 6) & (col("brand_position_name") == "ALL BRAND POSITIONS") &
                                (col("global_manufacturer_name").isin(['ALL MANUFACTURERS','Unilever'])) 
                                ).withColumn("log_id",lit(log_id).cast(IntegerType()))\
                                  .withColumn("created_date",lit(current_timestamp()))
except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "creating final dataframe failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "final dataframe created", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Writing** in to Silver Table

# COMMAND ----------

try:
    concurrent_external_table_delta_write(df_fact_final,absolute_path + delta_path_silver, delta_db_silver, delta_table_silver,None, catalog_name, object_owner_spn, retry_count=0, delta_overwrite_mode = "full" )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Silver Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
