# Databricks notebook source
# MAGIC %md
# MAGIC # **Fact_BusinessWinning_Silver_Ingestion For Market**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |20April 2025        |    Ashwini               |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Fact Business Winning Table Load along with Compass Measures for market
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and silver delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import re
import time
import json
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pyspark.sql
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string,BooleanType,IntegralType, StringType, DateType, TimestampType,IntegerType, StructType, StructField
from pyspark.sql.functions import col, lit, current_timestamp, desc, row_number,trim,concat,regexp_replace, substring
from pyspark.sql.functions import size, replace, to_date, month, year,concat_ws,when,monotonically_increasing_id,coalesce
from delta.tables import *
from pyspark.sql.functions import upper,lower,col
from pyspark.sql.functions import expr, length
from pyspark.sql.functions import col, when, sum


# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intialize Widget Parameters

# COMMAND ----------

# getting from parent notebook
external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
username                = dbutils.widgets.get("username")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("run_id")
job_id                  = dbutils.widgets.get("job_id")


# Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------


dbutils.widgets.removeAll()

# Create text widgets for various master data feeds and retrieve their values

dbutils.widgets.text("product_data_feed","master_data_product_category")
product_data_feed       = dbutils.widgets.get("product_data_feed")

dbutils.widgets.text("master_data_descendant","master_data_descendant")
descendant_data_feed       = dbutils.widgets.get("master_data_descendant")

dbutils.widgets.text("flow_data_feed","master_data_flow")
flow_data_feed       = dbutils.widgets.get("flow_data_feed")

dbutils.widgets.text("measure_data_feed","master_data_measure")
measure_data_feed       = dbutils.widgets.get("measure_data_feed")

dbutils.widgets.text("geography_data_feed","master_data_geography")
geography_data_feed       = dbutils.widgets.get("geography_data_feed")

dbutils.widgets.text("calendar_data_feed","master_data_calendar")
calendar_data_feed       = dbutils.widgets.get("calendar_data_feed")

dbutils.widgets.text("master_data_country_bu_map","master_data_country_bu_map")
master_data_country_bu_map       = dbutils.widgets.get("master_data_country_bu_map")



dbutils.widgets.text("debug_flag","1")
debug_flag      = dbutils.widgets.get("debug_flag")


# COMMAND ----------

# MAGIC %md
# MAGIC #Read Notebook config metadata parameters

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username, "Market Silver Fact BusinessWinning Ingestion", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for Fact BusinessWinning", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Main Orchestration -> Silver Ingestion

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    
    param = get_param_data(uc_catalog_name)

    # Fetch specific configuration
    process_feed_df                      = fetch_config(param, data_feed)
    product_process_feed_df              = fetch_config(param, product_data_feed)
    flow_process_feed_df              = fetch_config(param, flow_data_feed)
    measure_process_feed_df              = fetch_config(param, measure_data_feed)
    geography_process_feed_df              = fetch_config(param, geography_data_feed)
    calendar_process_feed_df                = fetch_config(param, calendar_data_feed)
    descendant_process_feed_df                = fetch_config(param, descendant_data_feed)

    master_data_country_bu_map_df = fetch_config(param, master_data_country_bu_map)
    
    stream = process_feed_df.select("stream").first()[0]

    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    # Display the filtered data
    display(process_feed_df)

    catalog_name                         = uc_catalog_name
    delta_db_staging                     = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging                  = process_feed_df.select("delta_table_staging").first()[0]

    # json values
    delta_path_silver                    = process_feed_df.select("delta_path_silver").first()[0]
    delta_table_silver                   = process_feed_df.select("delta_table_silver").first()[0]
    delta_db_silver                      = process_feed_df.select("delta_db_silver").first()[0]
  
    master_data_country_bu_map_db_gold = master_data_country_bu_map_df.select("delta_db_gold").first()[0]
    master_data_country_bu_map_view = master_data_country_bu_map_df.select("view_name").first()[0]

    descendant_delta_db_silver           = descendant_process_feed_df.select("delta_db_silver").first()[0]
    descendant_delta_table_silver           = descendant_process_feed_df.select("delta_table_silver").first()[0]
    product_delta_db_silver                      = product_process_feed_df.select("delta_db_silver").first()[0]
    product_delta_table_silver                   = product_process_feed_df.select("delta_table_silver").first()[0]
    flow_delta_db_silver                      = flow_process_feed_df.select("delta_db_silver").first()[0]
    flow_delta_table_silver                   = flow_process_feed_df.select("delta_table_silver").first()[0]
    measure_delta_db_silver                      = measure_process_feed_df.select("delta_db_silver").first()[0]
    measure_delta_table_silver                   = measure_process_feed_df.select("delta_table_silver").first()[0]
    geography_delta_db_silver                      = geography_process_feed_df.select("delta_db_silver").first()[0]
    geography_delta_table_silver                   = geography_process_feed_df.select("delta_table_silver").first()[0]
    calendar_delta_db_silver                      = calendar_process_feed_df.select("delta_db_silver").first()[0]
    calendar_delta_table_silver                   = calendar_process_feed_df.select("delta_table_silver").first()[0]

    rename_columns = config_data.get("rename_cols_silver",{})
    if rename_columns:
        rename = True
    else:
        rename = False

    if debug_flag == "1":

        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)
        print('product_delta_db_silver          :', product_delta_db_silver)
        print('product_delta_table_silver       :', product_delta_table_silver)
        print('flow_delta_db_silver             :', flow_delta_db_silver)
        print('flow_delta_table_silver          :', flow_delta_table_silver)
        print('measure_delta_db_silver          :', measure_delta_db_silver)
        print('measure_delta_table_silver       :', measure_delta_table_silver)
        print('geography_delta_db_silver        :', geography_delta_db_silver)
        print('geography_delta_table_silver     :', geography_delta_table_silver)
        print('descendant_delta_db_silver     :', descendant_delta_db_silver)
        print('descendant_delta_table_silver     :', descendant_delta_table_silver)
        print('master_data_country_bu_map_view :', master_data_country_bu_map_view)
        

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# Check if required tables exist.

try:
    tables = {
        
        "df_fact": f"{catalog_name}.{delta_db_staging}.{delta_table_staging}",
        "df_product": f"{catalog_name}.{product_delta_db_silver}.{product_delta_table_silver}",
        "df_bu_country_map": f"{catalog_name}.{master_data_country_bu_map_db_gold}.{master_data_country_bu_map_view}",
        "df_measure": f"{catalog_name}.{measure_delta_db_silver}.{measure_delta_table_silver}",
        "df_flow" : f"{catalog_name}.{flow_delta_db_silver}.{flow_delta_table_silver}",
        "df_calendar":f"{catalog_name}.{calendar_delta_db_silver}.{calendar_delta_table_silver}",
        "df_descendant": f"{catalog_name}.{descendant_delta_db_silver}.{descendant_delta_table_silver}",
        "df_master_data_map_cross_pcat": f"{catalog_name}.gold_master_data.vw_cross_functional_mapping_description"

        }

    for df_name, table in tables.items():
        table_exists =(spark.sql(f"SHOW TABLES IN {catalog_name}.{delta_db_staging}").filter(f"tableName = '{table}'").count() > 0)
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")
    
    # Selecting rows with is_active = true
    df_flow = df_flow.filter(col("is_active")==True)
    df_product = df_product.filter(col("is_active")==True)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Reading tables master and fact data", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# Logic to generate derived columns for fact table.

try:
    df_bu_country_map=df_bu_country_map.withColumnRenamed('Country Description','country_name')
    df_bu_country_map=df_bu_country_map.withColumnRenamed('Geography SK','geography_sk')
    df_bu_country_map = df_bu_country_map.withColumn(
        'country_name', 
        lower(trim(regexp_replace(df_bu_country_map['country_name'], ' ', '')))
    )

    
    df_product = df_product.withColumn(
        'division_description', 
        lower(df_product['division_description']))\
    .withColumn(
        'market_description', 
        lower(df_product['market_description']))\
    .withColumn(
        'category_description', 
        lower(df_product['category_description']))\
    .withColumn(
        'sector_description', 
        lower(df_product['sector_description']))
    

    df_fact=df_fact.withColumn("measure_group_id",lit(1))\
                            .withColumn('category_hierarchy',lower(df_fact['category_hierarchy']))\
                            .withColumn( 'country',lower(trim(regexp_replace(df_fact['country'], ' ', ''))))\
                            .withColumn('brand_position', lower(df_fact['brand_position']))\
                            .withColumn('local_brand', lower(df_fact['local_brand']))\
                            .withColumn('GMI_NonGMI_Converted',when(df_fact['gmi_non_gmi']=='GMI Cells',1).otherwise(0))
    
    ## ADDING LOGIC for CROSS FUNC MAPPING

    df_temp_fact = df_fact
        
    df_master_data_map_cross_pcat = df_master_data_map_cross_pcat.withColumn('modified_lookup_description', lower(col('PCAT Description'))).withColumn('description', lower(col('GCAD Description'))).select("description", "modified_lookup_description")

    df_temp_fact = df_temp_fact.join(df_master_data_map_cross_pcat, df_temp_fact.category_hierarchy == df_master_data_map_cross_pcat.modified_lookup_description, "left")
    
    df_temp_fact = df_temp_fact.withColumn('category_hierarchy', 
                                           when(col('description').isNull(), 
                                                col('category_hierarchy'))
                                           .otherwise(col('description')))

    df_fact = df_temp_fact.drop("description", "modified_lookup_description")
  

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "lower case conversion for product,bumap,fact table failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "lower case conversion for product,bumap,fact table successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

# Joins to extract surrogate key columns from master table.

try:
    df_fact_columns = [colu for colu in df_fact.columns if col in ['log_id', 'created_date']]

    df_fact_BW = df_fact \
        .join(df_bu_country_map, df_fact.country == df_bu_country_map.country_name) \
        .join(df_measure, df_fact.measure_type == df_measure.measure_description) \
        .join(df_calendar, df_fact.period == df_calendar.month_short_description)
    df_test_div = df_fact_BW.join(df_product,df_fact.category_hierarchy == df_product.division_description, "left")\
            .select(
            df_fact["*"],
            df_bu_country_map.geography_sk,
            df_measure.measure_sk,
            df_calendar.month_sk,
            df_product.division_code
            ).distinct()
    df_test_mark = df_test_div.join(df_product,df_fact.category_hierarchy == df_product.market_description, "left")\
            .select(
            df_test_div["*"],
            df_product.market_code
            ).distinct()
    df_test_cate = df_test_mark.join(df_product,df_fact.category_hierarchy == df_product.category_description, "left")\
            .select(
            df_test_mark["*"],
            df_product.category_code
            ).distinct()
    df_combined = df_test_cate.join(df_product,df_fact.category_hierarchy == df_product.sector_description, "left")\
            .select(
            df_test_cate["*"],
            df_product.sector_code
            ).distinct()

    df_fact_BW = df_combined.withColumn('cate_code',coalesce(df_combined.division_code,df_combined.market_code,df_combined.category_code,df_combined.sector_code))

    df_fact_BW = df_fact_BW.join(df_descendant, df_fact_BW.cate_code==df_descendant.child_code).select(df_fact_BW['*'],df_descendant['descendant_sk']).drop('cate_code', 'market_code','division_code','sector_code','category_code')
                   
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Join failed for product,bumap,fact table", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Join Successful for product,bumap,fact table", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# Country lookup not requred as all country listed from manual file are available at lookup country for BW ETL

# COMMAND ----------

# Unpivot and join to get flow details.

try:
        Col_list=[]
        for colu in df_fact_BW.columns:
                if colu not in ("mat_gaining_turnover", "l12w_gaining_turnover", "ytd_gaining_turnover", "fy_gaining_turnover"):
                        Col_list.append(colu)
        Unpivot_cols=["mat_gaining_turnover", "l12w_gaining_turnover", "ytd_gaining_turnover", "fy_gaining_turnover"]
         # Dynamically build the stack expression correctly formatted
        stack_expr = ", ".join([f"'{colu}', {colu}" for colu in Unpivot_cols])
         # Construct the final select expression for unpivoting
        unpivot_expr = f" stack({len(Unpivot_cols)}, {stack_expr}) as (value_type, gaining_turnover)"
         # Assuming `staging_df` is your DataFrame
        df_new_fact_data = df_fact_BW.selectExpr(Col_list,unpivot_expr)
        df_new_fact_data = df_new_fact_data.withColumn('flow_type',col( 'value_type')) \
                                        .withColumn('flow_type', regexp_replace('flow_type', '_gaining_turnover', '')) \
                                        .withColumn('flow_type', regexp_replace('flow_type', 'fy', 'Month')) \
                                        .withColumn('flow_type', regexp_replace('flow_type', 'ytd', 'YTD')) \
                                        .withColumn('flow_type', regexp_replace('flow_type', 'mat', 'MAT')) \
                                        .withColumn('flow_type', regexp_replace('flow_type', 'l12w', 'L12W'))
        
        df_target=df_new_fact_data.join(df_flow,df_new_fact_data.flow_type==df_flow.flow_description).select(df_new_fact_data['*'],df_flow['flow_sk'])

        df_target = df_target.withColumn(
        'alternative_bps',
        when(col('value_type') == 'mat_gaining_turnover', col('alternative_mat_bps'))
        .when(col('value_type') == 'l12w_gaining_turnover', col('alternative_l12w_bps'))
        .otherwise(0)
        ).withColumn(
        'mkt_growth',
        when(col('value_type') == 'mat_gaining_turnover', col('mat_mkt_growth_p1'))
        .when(col('value_type') == 'l12w_gaining_turnover', col('l12w_mkt_growth_p1'))
        .otherwise(0)
         )

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Unpivot value_type for gaining_turnover and join with flow failed ", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Unpivot value_type for gaining_turnover and join with flow successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")



# COMMAND ----------



# COMMAND ----------

df_target.columns

# COMMAND ----------

try:
    # Create separate columns for each measure_type and metric
    df_pivot = df_target.groupBy('gmi_non_gmi',
    'country',
    'category_hierarchy',
    'brand_position',
    'local_brand',
    'period',
    'total_turnover',
    'measure_group_id',
    'GMI_NonGMI_Converted',
    'geography_sk',
    'month_sk',
    'descendant_sk',
    'flow_type',
    'flow_sk',
    ).pivot("measure_type").agg({"gaining_turnover": "first", "alternative_bps": "first", "mkt_growth": "first"})


    df_pivot=df_pivot.withColumnRenamed('Value_first(gaining_turnover)','Value_gaining_turnover')\
    .withColumnRenamed('Value_first(alternative_bps)','Value_alternative_bps')\
    .withColumnRenamed('Value_first(mkt_growth)','Value_mkt_growth')\
    .withColumnRenamed('Volume_first(gaining_turnover)','Volume_gaining_turnover')\
    .withColumnRenamed('Volume_first(alternative_bps)','Volume_alternative_bps')\
    .withColumnRenamed('Volume_first(mkt_growth)','Volume_mkt_growth')


    display(df_pivot)

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Unpivot value_type for gaining_turnover and join with flow failed ", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Unpivot value_type for gaining_turnover and join with flow successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")


# COMMAND ----------

# Transformations to generate required columns.

try:
    df_target = df_pivot.withColumn(
        'Value_gaining_turnover_cell',
        when(col('Value_gaining_turnover') +0 > 0, 1)
        .otherwise(0)
    ).withColumn(
        'Value_losing_turnover_cell',
        when(col('Value_gaining_turnover') +0 <= 0, 1)
        .otherwise(0)
    ).withColumn(
        'Volume_gaining_turnover_cell',
        when(col('Volume_gaining_turnover') +0 > 0, 1)
        .otherwise(0)
    ).withColumn(
        'Volume_losing_turnover_cell',
        when(col('Volume_gaining_turnover') +0 <= 0, 1)
        .otherwise(0)
    ).withColumn(
        'gmi_nongmi_converted',
        when(col('gmi_non_gmi')=='GMI Cells', 1)
        .otherwise(0)
    ).withColumnRenamed('total_turnover','turnover')\
    .withColumn('gmi_nongmi_turnover',col('gmi_nongmi_converted')*col('turnover'))\
    .withColumn('gmi_nongmi_gaining_turnover',col('gmi_nongmi_converted')*col('Value_gaining_turnover'))\
    .withColumn(
        'gmi_nongmi_gaining_turnover_cell',
        when(col('gmi_nongmi_gaining_turnover') +0 > 0, 1)
        .otherwise(0)
    ).withColumn(
        'gmi_nongmi_losing_turnover_cell',
        when(col('gmi_nongmi_gaining_turnover') +0 <= 0, 1)
        .otherwise(0)
    ).withColumnRenamed('descendant_sk', 'product_sk')

    df_target_final=df_target.select('country','category_hierarchy','geography_sk','flow_sk','month_sk', 'product_sk','gmi_non_gmi','turnover','Value_gaining_turnover','Volume_gaining_turnover','Value_gaining_turnover_cell','Value_losing_turnover_cell','Volume_gaining_turnover_cell','Volume_losing_turnover_cell','gmi_nongmi_turnover','gmi_nongmi_gaining_turnover','gmi_nongmi_gaining_turnover_cell','gmi_nongmi_losing_turnover_cell','Value_alternative_bps','Value_mkt_growth','Volume_alternative_bps','Volume_mkt_growth',lit(log_id).alias("log_id"),lit(current_timestamp()).alias("created_date"))


except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "case when applied on final_df to generate some derived columns is failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "case when applied on final_df to generate some derived columns is successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

try:
    df_flow_val = df_target_final.groupby(
        'country',
        'category_hierarchy',
        'month_sk'
    ).agg(
        sum('Value_gaining_turnover_cell').alias('No_of_Cells_Gaining'),
        sum('Value_losing_turnover_cell').alias('No_of_Cells_Losing')
    )

    df_flow_volume = df_target_final.groupby(
        'country',
        'category_hierarchy',
        'month_sk'
    ).agg(
        sum('Volume_gaining_turnover_cell').alias('Vol_No_of_Cells_Gaining'),
        sum('Volume_losing_turnover_cell').alias('Vol_No_of_Cells_Losing')
    )

    df_target_kpi=df_flow_val.join(df_flow_volume,((df_flow_val['country']==df_flow_volume['country'])&(df_flow_volume['category_hierarchy']==df_flow_val['category_hierarchy'])& (df_flow_volume['month_sk']==df_flow_val['month_sk'])),how='inner').select(df_flow_val['country'],df_flow_val['category_hierarchy'],df_flow_val['month_sk'],df_flow_val['No_of_cells_gaining'],df_flow_val['No_of_cells_losing'],df_flow_volume['Vol_No_of_cells_gaining'],df_flow_volume['Vol_No_of_cells_losing'])

    df_target_kpi_alias = df_target_kpi.alias("target_kpi")
    df_fact_kpi_alias = df_target_final.alias("fact")

    df_target = df_fact_kpi_alias.join(
        df_target_kpi_alias,
        ((col('fact.country') == col('target_kpi.country')) & (col('fact.category_hierarchy') == col('target_kpi.category_hierarchy')) &(col('fact.month_sk') == col('target_kpi.month_sk'))),
        how='inner'
    ).select(
        df_fact_kpi_alias['*'],
        df_target_kpi_alias['No_of_cells_gaining'],
        df_target_kpi_alias['No_of_cells_losing'],
        df_target_kpi_alias['Vol_No_of_cells_gaining'],
        df_target_kpi_alias['Vol_No_of_cells_losing']
    )

    df_target_final =df_target.select('geography_sk','month_sk','flow_sk', 'product_sk','turnover','Value_gaining_turnover','Value_mkt_growth','Value_alternative_bps','Value_gaining_turnover_cell','Value_losing_turnover_cell','Volume_gaining_turnover','Volume_mkt_growth','Volume_alternative_bps','gmi_nongmi_turnover','gmi_nongmi_gaining_turnover','gmi_nongmi_gaining_turnover_cell','gmi_nongmi_losing_turnover_cell','No_of_cells_gaining','No_of_cells_losing','Vol_No_of_cells_gaining','Vol_No_of_cells_losing',lit(log_id).cast(LongType()).alias("log_id"),lit(current_timestamp()).alias("created_date"))


except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Aggregated Columns Generation is failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Aggregated Columns Generation is successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")


# COMMAND ----------

display(df_target_final)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Write into Silver Delta Path

# COMMAND ----------

try:
    concurrent_external_table_delta_write(df_target_final,absolute_path + delta_path_silver, delta_db_silver, delta_table_silver,None, catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False",delta_overwrite_mode = "full" )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact Business Winning completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# %sql
# create or replace view pds_pmrs_930972_dev.gold_market.vw_fact_business_winning_row
# as
# SELECT
#   cbm.`BU SK` as `BU SK`,
#   f.geography_sk as `Geography SK`,
#   f.flow_sk as `Flow SK`,
#   f.measure_sk as `Measure SK`,
#   cast(f.month_sk as int) as `Month SK`,
#   f.product_sk as `Product SK`,
#   f.turnover as `Turnover`,
#   f.gaining_turnover as `Gaining Turnover`,
#   f.gaining_turnover_cell as `Gaining Turnover Cell`,
#   f.losing_turnover_cell as `Losing Turnover Cell`,
#   f.gmi_nongmi_turnover as `Gmi Nongmi`,
#   f.gmi_nongmi_gaining_turnover as `Gmi Nongmi Gaining Turnover`,
#   f.gmi_nongmi_gaining_turnover_cell as `Gmi Nongmi Gaining Turnover Cell`,
#   f.gmi_nongmi_losing_turnover_cell as `Gmi Nongmi Losing Turnover Cell`,
#   f.Value_alternative_bps as `Value Alternative Bps`,
#   f.Value_mkt_growth as `Value Market Growth`,
#   (cast(f.turnover as DOUBLE) * cast(f.Value_alternative_bps as DOUBLE)) as `Value Turnover Weighted Numerator`,
#   (
#     cast(f.turnover as DOUBLE) * cast(f.Value_mkt_growth as DOUBLE)
#   ) as `Value Turnover Weighted Growth Numerator`,
#   (cast(f.turnover as DOUBLE) * cast(f.Volume_alternative_bps as DOUBLE)) as `Volume Turnover Weighted Numerator`,
#   (
#     cast(f.turnover as DOUBLE) * cast(f.Volume_mkt_growth as DOUBLE)
#   ) as `Volume Turnover Weighted Growth Numerator`,
#   f.No_of_cells_gaining As `No Of Cells Gaining`,
#   f.No_of_cells_losing As `No Of Cells Losing`,
#   (f.No_of_cells_gaining) + (f.No_of_cells_losing) as `Total No of Cells`,
#   f.Vol_No_of_cells_gaining As `Vol No Of Cells Gaining`,
#   f.Vol_No_of_cells_losing As `Vol No Of Cells Losing`,
#   CAST(f.created_date AS TIMESTAMP) AS `Created Date`
# From
#   pds_pmrs_930972_dev.silver_market.fact_business_winning as f
#     inner join pds_pmrs_930972_dev.gold_master_data.vw_country_bu_map cbm
#       on F.geography_sk = cbm.`Geography SK`
# Where
#   f.month_sk = (
#     SELECT
#       MAX(month_sk)
#     FROM
#       pds_pmrs_930972_dev.silver_market.fact_business_winning
#   )

# COMMAND ----------


