# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 11 March  2025        | Dhanapal,Ashwini     |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Purpose of this Notebook is to run fact notebooks based on feed
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and Gold delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC workflow trigger from webapp
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

data_feed         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed") or ""
uc_catalog_name   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name") or ""
external_location = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location") or ""
object_owner_spn  = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn") or ""
debug_flag        = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag") or ""
username          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username") or ""
file_name         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
log_id              = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

# Log the fetched values (useful for debugging)
print(f"Data Feed: {data_feed}")
print(f"UC Catalog Name: {uc_catalog_name}")
print(f"External Location: {external_location}")
print(f"Object Owner SPN: {object_owner_spn}")
print(f"Debug Flag: {debug_flag}")
print(f"Username: {username}")


# COMMAND ----------

try:
    # Define common parameters
    common_params = {
        "data_feed": data_feed,
        "uc_catalog_name": uc_catalog_name,
        "external_location": external_location,
        "object_owner_spn": object_owner_spn,
        "debug_flag": debug_flag,
        "username": username,
        "file_name" : file_name,
        "run_id": log_id,
        "job_id": int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    }

    # Conditional logic to run the correct notebook
    if data_feed == "market_fact_business_winning":  
        print("Executing: market_fact_business_winning...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/market/nb_pmrs_fact_business_winning", -1, common_params)  

    elif data_feed == "market_fact_bw_usg":  
        print("Executing: market_fact_bw_usg...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/market/nb_pmrs_fact_bw_usg", -1, common_params)

    else:
        raise ValueError(f"Unknown data_feed value: {data_feed}")

    dbutils.jobs.taskValues.set("key_value", result)

    print("Notebook execution completed successfully!")

except Exception as e:
    print(f"Error occurred: {str(e)}")
    raise Exception(f"Parent notebook failed due to child error: {str(e)}")
