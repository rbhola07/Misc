# Databricks notebook source
# MAGIC %md
# MAGIC # **Fact_BW_USG silver Ingestion**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |6 FEB 2025        |    Ashwini,Dhanapal               |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Finance Measures calculated for market
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and silver delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import re
import time
import json
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pyspark.sql
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string,BooleanType,IntegralType, StringType, DateType, TimestampType,IntegerType, StructType, StructField
from pyspark.sql.functions import col, lit, current_timestamp, desc, row_number,trim,concat,regexp_replace
from pyspark.sql.functions import size, replace, to_date, month, year,concat_ws,when,monotonically_increasing_id,coalesce
from delta.tables import *
from pyspark.sql.functions import upper
import pyspark.sql.functions as F
from pyspark.sql.functions import col, lit

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intialize ADF Parameters

# COMMAND ----------

#getting from parent notebook
external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
username                = dbutils.widgets.get("username")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("log_id")
job_id                  = dbutils.widgets.get("job_id")

#Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------


dbutils.widgets.removeAll()

# Create text widgets for various master data feeds and retrieve their values

dbutils.widgets.text("business_unit_feed","master_data_business_unit_mu")
business_unit_feed       = dbutils.widgets.get("business_unit_feed")


dbutils.widgets.text("geography_data_feed","master_data_geography")
geography_data_feed       = dbutils.widgets.get("geography_data_feed")

dbutils.widgets.text("fact_actuals_data_feed","finance_fact_actuals_test")
fact_actuals_data_feed       = dbutils.widgets.get("fact_actuals_data_feed")

dbutils.widgets.text("fact_actuals_data_feed","finance_fact_actuals_test")
fact_actuals_data_feed       = dbutils.widgets.get("fact_actuals_data_feed")

dbutils.widgets.text("flow_data_feed","master_data_flow")
flow_data_feed       = dbutils.widgets.get("flow_data_feed")

dbutils.widgets.text("measure_data_feed","master_data_measure")
measure_data_feed       = dbutils.widgets.get("measure_data_feed")

dbutils.widgets.text("debug_flag","1")
debug_flag      = dbutils.widgets.get("debug_flag")
# dbutils.jobs.taskValues.set(key = "debug_flag", value = debug_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC #Read Notebook config metadata parameters

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)


    # job_id, run_id =  9791950266, 1068835831918561
    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username, "Market Silver Fact BW_USG", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for Fact BW_USG", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Main Orchestration -> Silver Ingestion

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    
    param = get_param_data(uc_catalog_name)

    # Fetch specific configuration
    process_feed_df                      = fetch_config(param, data_feed)
    business_unit_process_feed_df        = fetch_config(param, business_unit_feed)
    geography_process_feed_df            = fetch_config(param, geography_data_feed)
    fact_actuals_process_feed_df         = fetch_config(param, fact_actuals_data_feed)
    flow_process_feed_df                 = fetch_config(param, flow_data_feed)
    measure_process_feed_df              = fetch_config(param, measure_data_feed)

    
    stream = process_feed_df.select("stream").first()[0]

    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    # Display the filtered data
    display(process_feed_df)

    catalog_name                         = uc_catalog_name
    delta_db_staging                     = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging                  = process_feed_df.select("delta_table_staging").first()[0]

    # json values
    delta_path_silver                    = process_feed_df.select("delta_path_silver").first()[0]
    delta_table_silver                   = process_feed_df.select("delta_table_silver").first()[0]
    delta_db_silver                      = process_feed_df.select("delta_db_silver").first()[0]

    business_unit_delta_db_silver                      = business_unit_process_feed_df.select("delta_db_silver").first()[0]
    business_unit_delta_table_silver                   = business_unit_process_feed_df.select("delta_table_silver").first()[0]
    geography_delta_db_silver                          = geography_process_feed_df.select("delta_db_silver").first()[0]
    geography_delta_table_silver                       = geography_process_feed_df.select("delta_table_silver").first()[0]
    flow_delta_db_silver                               = flow_process_feed_df.select("delta_db_silver").first()[0]
    flow_delta_table_silver                            = flow_process_feed_df.select("delta_table_silver").first()[0]
    fact_actuals_delta_db_gold                         = fact_actuals_process_feed_df.select("delta_db_gold").first()[0]
    fact_actuals_view                                  = fact_actuals_process_feed_df.select("view_name").first()[0]
    measure_delta_db_silver                      = measure_process_feed_df.select("delta_db_silver").first()[0]
    measure_delta_table_silver                   = measure_process_feed_df.select("delta_table_silver").first()[0]
    
   
    rename_columns = config_data.get("rename_cols_silver",{})
    if rename_columns:
        rename = True
    else:
        rename = False

    if debug_flag == "1":

        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)
        print('geography_delta_db_silver        :', geography_delta_db_silver)
        print('geography_delta_table_silver     :', geography_delta_table_silver)
        print('flow_delta_db_silver             :', flow_delta_db_silver)     
        print('flow_delta_table_silver          :', flow_delta_table_silver)  
        print('measure_delta_db_silver          :', measure_delta_db_silver)
        print('measure_delta_table_silver       :', measure_delta_table_silver)


except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    tables = {
        
        "df_fact": f"{catalog_name}.{fact_actuals_delta_db_gold}.{fact_actuals_view}",
        "df_business_unit": f"{catalog_name}.{business_unit_delta_db_silver}.{business_unit_delta_table_silver}",
        "df_bu_country_map": f"{uc_catalog_name}.bronze_market.country_bu_map",
        "df_geography": f"{catalog_name}.{geography_delta_db_silver}.{geography_delta_table_silver}",
        "df_measure": f"{catalog_name}.{measure_delta_db_silver}.{measure_delta_table_silver}",
        "df_flow" : f"{catalog_name}.{flow_delta_db_silver}.{flow_delta_table_silver}"
        }

    for df_name, table in tables.items():
        table_exists =(spark.sql(f"SHOW TABLES IN {catalog_name}.{delta_db_staging}").filter(f"tableName = '{table}'").count() > 0)
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Reading tables master and fact data", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    measures = ['Turnover PY','Acquisition Turnover','Disposal Turnover','Deflated Acquisition Turnover','Deflated CY Turnover','Turnover']

    # Creating DataFrame
    df_measure_list = spark.createDataFrame(measures, ["measure_desc"])

    df_join_measure=df_measure_list.join(df_measure, df_measure_list.measure_desc==df_measure.measure_description, how='inner').select(df_measure.measure_sk)


    df_fact1 = df_fact.withColumnRenamed('BU SK', 'bu_sk').withColumnRenamed('Product SK', 'product_sk').withColumnRenamed('Measure SK', 'measure_sk').withColumnRenamed('Flow SK', 'flow_sk').withColumnRenamed('Month SK', 'month_sk').withColumnRenamed('Value', 'value').select("bu_sk", "product_sk", "measure_sk", "month_sk", "value")

    df_fact_final=df_fact1.join(df_join_measure, df_fact1.measure_sk==df_join_measure.measure_sk, how='inner').select(df_fact1['*'])

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Rename fact columns and create measure dictionary failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Rename fact columns and create measure dictionary successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")



# COMMAND ----------


try:

    window_spec_rn = Window.partitionBy("product_sk", "bu_sk", "measure_sk").orderBy("month_sk")

    df_target = df_fact_final.withColumn("rn", row_number().over(window_spec_rn))
                # .withColumn("flow_sk",lit(4))

        # Step 2: Apply the Moving Aggregation Window (12-month rolling sum)
    window_spec_mat = Window.partitionBy("product_sk", "bu_sk","measure_sk").orderBy("rn").rowsBetween(-11, 0)
    window_spec_l12wmat = Window.partitionBy("product_sk", "bu_sk","measure_sk").orderBy("rn").rowsBetween(-2, 0)
    df_final = (
        df_target
            .select(
                "bu_sk",
                "product_sk",
                "month_sk",
                "measure_sk",
                F.col("Value").alias("Month"),
                F.sum("Value").over(window_spec_mat).alias("MAT"),
                F.sum("Value").over(window_spec_l12wmat).alias("L3M")  # Aggregating values
            )
        )

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Window function failed for L3P and MAT", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Window function successful for L3P and MAT", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

try:
        Col_list=[]
        for colu in df_final.columns:
                if colu not in ("Month","MAT","L3M"):
                        Col_list.append(colu)
        Unpivot_cols=["Month","MAT","L3M"]
         # Dynamically build the stack expression correctly formatted
        stack_expr = ", ".join([f"'{colu}', {colu}" for colu in Unpivot_cols])
         # Construct the final select expression for unpivoting
        unpivot_expr = f" stack({len(Unpivot_cols)}, {stack_expr}) as (flow_desc, Value)"
         # Assuming `staging_df` is your DataFrame
        df_target = df_final.selectExpr(Col_list,unpivot_expr)

        df_flow = df_flow.filter(col("is_active")==True)
        df_target_flow=df_target.join(df_flow,df_target.flow_desc==df_flow.flow_description,'inner').select(
        df_target['bu_sk'], 
        df_target['product_sk'], 
        df_target['month_sk'], 
        df_target['measure_sk'], 
        df_flow['flow_sk'],
        df_target['Value'])

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Unpivot for flow_desc and join to fetch flow_sk failed ", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Unpivot for flow_desc and join to fetch flow_sk is successful", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

try:
    
    df_target_final = (df_target_flow
                   .join(df_business_unit, df_target_flow.bu_sk == df_business_unit.bu_sk, "inner")\
                   .join(df_bu_country_map, df_business_unit.bu_code == df_bu_country_map.bu_code, "inner")
                   .join(df_geography, df_bu_country_map.country_code == df_geography.mu_iso_country_code, "inner")
                   .select(
                       df_target_flow['*'],
                       df_geography['geography_sk']
                   )).select("geography_sk", "product_sk","month_sk","measure_sk","flow_sk","value",lit(log_id).alias("log_id"),lit(current_timestamp()).alias("created_date"))
    
except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "join between targetdf,bu,country_map and geography failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "join between targetdf,bu,country_map and geography successfu", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"") 


# COMMAND ----------

# MAGIC %md
# MAGIC ###Write into Silver Delta Path

# COMMAND ----------

try:
    concurrent_external_table_delta_write(df_target_final,absolute_path + delta_path_silver, delta_db_silver, delta_table_silver,None, catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False",delta_overwrite_mode = "full" )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact BW_USG completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------


