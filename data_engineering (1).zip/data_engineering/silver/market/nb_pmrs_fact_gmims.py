# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Fact GMI Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |  13 Jan 2025     |    Aditya, Dhanapal          |    Notebook Created |
# MAGIC
# MAGIC
# MAGIC ## Purpose
# MAGIC This Notebook is used to load Fact GMI data
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType
from pyspark.sql.functions import (col, lit, lower, regexp_replace, regexp_extract, trim,current_timestamp, desc, row_number, size, replace, to_date, month,year, last, coalesce,expr)
from delta.tables import DeltaTable
import datetime
start_time = datetime.datetime.now()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Utils

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Widgets

# COMMAND ----------

debug_flag          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
uc_catalog_name     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
external_location   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
username            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
data_feed            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
log_id              = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")


dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("log_id", log_id)

# COMMAND ----------


dbutils.widgets.removeAll()

# Create text widgets for various master data feeds and retrieve their values

dbutils.widgets.text("product_data_feed","master_data_product_category")
product_data_feed       = dbutils.widgets.get("product_data_feed")

dbutils.widgets.text("flow_data_feed","master_data_flow")
flow_data_feed       = dbutils.widgets.get("flow_data_feed")

dbutils.widgets.text("measure_data_feed","master_data_measure")
measure_data_feed       = dbutils.widgets.get("measure_data_feed")

dbutils.widgets.text("geography_data_feed","master_data_geography")
geography_data_feed       = dbutils.widgets.get("geography_data_feed")

dbutils.widgets.text("brand_data_feed","master_data_brand")
brand_data_feed       = dbutils.widgets.get("brand_data_feed")

dbutils.widgets.text("brand_pos_data_feed","master_data_brand_position")
brand_pos_data_feed       = dbutils.widgets.get("brand_pos_data_feed")

dbutils.widgets.text("debug_flag","1")
debug_flag      = dbutils.widgets.get("debug_flag")
dbutils.jobs.taskValues.set(key = "debug_flag", value = debug_flag)

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = int(log_id)
    

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username, "Market Silver Fact GMI Ingestion", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for Fact GMI Snapshot", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    
    param = get_param_data(uc_catalog_name)

    # Fetch specific configuration
    process_feed_df                      = fetch_config(param, data_feed)
    product_process_feed_df              = fetch_config(param, product_data_feed)
    flow_process_feed_df              = fetch_config(param, flow_data_feed)
    measure_process_feed_df              = fetch_config(param, measure_data_feed)
    geography_process_feed_df              = fetch_config(param, geography_data_feed)
    brand_process_feed_df              = fetch_config(param, brand_data_feed)
    brand_pos_process_feed_df              = fetch_config(param, brand_pos_data_feed)
    
    stream = process_feed_df.select("stream").first()[0]

    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    # Display the filtered data
    display(process_feed_df)

    catalog_name                         = uc_catalog_name
    delta_db_staging                     = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging                  = process_feed_df.select("delta_table_staging").first()[0]

    # json values
    delta_path_silver                   = json.loads(process_feed_df.select("delta_path_silver").first()[0].replace("'",'"'))
    delta_db_silver                     = json.loads(process_feed_df.select("delta_db_silver").first()[0].replace("'",'"'))
    delta_table_silver                  = json.loads(process_feed_df.select("delta_table_silver").first()[0].replace("'",'"'))
    delta_path_gold                     = json.loads(process_feed_df.select("delta_path_gold").first()[0].replace("'",'"'))
    delta_db_gold                       = json.loads(process_feed_df.select("delta_db_gold").first()[0].replace("'",'"'))
    delta_table_gold                    = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'",'"'))
    delta_pivot_table                   = list(delta_table_gold.values())[0].replace("'", '"') + "_pivot"
    delta_path_gold_pivot                = list(delta_path_gold.values())[0].replace("'", '"').rstrip('/') + "_pivot/"


    product_delta_db_silver             = product_process_feed_df.select("delta_db_silver").first()[0]
    product_delta_table_silver          = product_process_feed_df.select("delta_table_silver").first()[0]
    flow_delta_db_silver                = flow_process_feed_df.select("delta_db_silver").first()[0]
    flow_delta_table_silver             = flow_process_feed_df.select("delta_table_silver").first()[0]
    measure_delta_db_silver             = measure_process_feed_df.select("delta_db_silver").first()[0]
    measure_delta_table_silver          = measure_process_feed_df.select("delta_table_silver").first()[0]
    geography_delta_db_silver           = geography_process_feed_df.select("delta_db_silver").first()[0]
    geography_delta_table_silver        = geography_process_feed_df.select("delta_table_silver").first()[0]
    brand_delta_db_silver               = brand_process_feed_df.select("delta_db_silver").first()[0]
    brand_delta_table_silver            = brand_process_feed_df.select("delta_table_silver").first()[0]
    brand_pos_delta_db_silver           = brand_pos_process_feed_df.select("delta_db_silver").first()[0]
    brand_pos_delta_table_silver        = brand_pos_process_feed_df.select("delta_table_silver").first()[0]

    rename_columns = config_data.get("rename_cols_silver",{})
    if rename_columns:
        rename = True
    else:
        rename = False

    if debug_flag == "1":

        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)
        print('product_delta_db_silver          :', product_delta_db_silver)
        print('product_delta_table_silver       :', product_delta_table_silver)
        print('flow_delta_db_silver             :', flow_delta_db_silver)
        print('flow_delta_table_silver          :', flow_delta_table_silver)
        print('measure_delta_db_silver          :', measure_delta_db_silver)
        print('measure_delta_table_silver       :', measure_delta_table_silver)
        print('geography_delta_db_silver        :', geography_delta_db_silver)
        print('geography_delta_table_silver     :', geography_delta_table_silver)
        print('brand_delta_db_silver            :', brand_delta_db_silver)
        print('brand_delta_table_silver         :', brand_delta_table_silver)
        print('brand_pos_delta_db_silver        :', brand_pos_delta_db_silver)
        print('brand_pos_delta_table_silver     :', brand_pos_delta_table_silver)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

def unpivot(df, dim_cols, kpi_cols):
  df_new = df.select([col(x).cast("String") for x in df.columns])
  df_actual = df_new.drop(*dim_cols)
  columnsCount =str(len(kpi_cols))
  unpvt_format = ",".join(["'"+ x + "',`" + x +"`" for x in kpi_cols])
  final_unpvt_format = columnsCount + "," + unpvt_format
  final_format_unpvt = "stack(" + final_unpvt_format + ")" + " as (`MeasureType`,Mkt_Value)"
  return df_new.select(*dim_cols, expr(final_format_unpvt))

# COMMAND ----------

try:
    tables = {

        "df_fact": f"{catalog_name}.{delta_db_staging}.{delta_table_staging}",
        "df_product": f"{catalog_name}.{product_delta_db_silver}.{product_delta_table_silver}",
        "df_geography": f"{catalog_name}.{geography_delta_db_silver}.{geography_delta_table_silver}",
        "df_measure": f"{catalog_name}.{measure_delta_db_silver}.{measure_delta_table_silver}",
        "df_flow" : f"{catalog_name}.{flow_delta_db_silver}.{flow_delta_table_silver}",
        "df_brand" : f"{catalog_name}.{brand_delta_db_silver}.{brand_delta_table_silver}",
        "df_brand_pos" : f"{catalog_name}.{brand_pos_delta_db_silver}.{brand_pos_delta_table_silver}"
        }

    for df_name, table in tables.items():
        table_exists =(spark.sql(f"SHOW TABLES IN {catalog_name}.{delta_db_staging}").filter(f"tableName = '{table}'").count() > 0)
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")
    
# Selecting rows with is_active = true
    df_flow = df_flow.filter(col("is_active")==True)
    df_product = df_product.filter(col("is_active")==True)
    df_brand = df_brand.filter(col("is_active")==True)
    df_brand_pos = df_brand_pos.filter(col("is_active")==True)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Reading tables master and fact data", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
  #check whether the incoming fact data has all the countires present in the geography table
  df_fact_country = df_fact.select("country_code").distinct()
  df_geography_country = df_geography.select("mu_iso_country_code")

  df_country_joined = df_fact_country.join(df_geography_country, df_fact_country.country_code == df_geography_country.mu_iso_country_code, "left")

  if df_country_joined.filter(col("country_code").isNull()).count() > 0:
    update_job(job_id, module_id, data_feed, feed_id, status_failure_id)
    update_job_log(status_failure_id, job_id, run_id, data_feed, feed_id, module_id)
    insert_job_detail_log(1, run_id, username, "Countries missing in master data geography table",datetime.now(), status_failure_id, data_feed, feed_id, module_id, 0, "", "")
    dbutils.notebook.exit(f"{df_country_joined.filter(col('country_code').isNotNull()).count()} countries from fact is not present in master data geography table")

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Country comparison from fact with geography table", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e

# COMMAND ----------

try:
  df_fact_columns = [col for col in df_fact.columns if col in ['is_active', 'log_id', 'created_date']]

  #unpivoting to get value and volume columns into rows under a single column
  df_fact =  df_fact.withColumnRenamed("cy_sales_value","Value")
  df_fact =  df_fact.withColumnRenamed("cy_sales_volume","Volume")
  df_fact =  df_fact.withColumn("month_sk",when((day(current_date()) <= 31) & (day(current_date()) > 21), concat(year(add_months(current_date(), -1)),
lpad(month(add_months(current_date(), -1)).cast("string"),2,"0")))
.otherwise(concat(year(add_months(current_date(), -2)),
lpad(month(add_months(current_date(), -2)).cast("string"),2,"0"))))

  dim_cols = ["country_code",  "product_form_code",  "global_manufacturer_code",   "brand_position_code", "brand_code" , "local_manufacturer_code",  "period",  "default_UOM",   "product_form_name",  "country_name",  "global_manufacturer_name",   "brand_position_name", "brand_position_status_name",   "brand_name",    "local_manufacturer_name","latest_available_date","month_sk" ]
  kpi_cols_fs = ["Value","Volume"]

  df_fact = unpivot(df_fact,dim_cols,kpi_cols_fs)

  df_fact_trans = df_fact.withColumn("year", col('period').substr(-4,4)).withColumn("month",
            when(col('period').contains("4WEEK1-") | col('period').contains("MTH1-"), '01').
            when(col('period').contains("4WEEK2") | col('period').contains("MTH2"), '02').
            when(col('period').contains("4WEEK3") | col('period').contains("MTH3"), '03').
            when(col('period').contains("4WEEK4") | col('period').contains("MTH4"), '04').
            when(col('period').contains("4WEEK5") | col('period').contains("MTH5"), '05').
            when(col('period').contains("4WEEK6") | col('period').contains("MTH6"), '06').
            when(col('period').contains("4WEEK7") | col('period').contains("MTH7"), '07').
            when(col('period').contains("4WEEK8") | col('period').contains("MTH8"), '08').
            when(col('period').contains("4WEEK9") | col('period').contains("MTH9"), '09').
            when(col('period').contains("4WEEK10") | col('period').contains("MTH10"), '10').
            when(col('period').contains("4WEEK11") | col('period').contains("4WEEK12") | col('period').contains("MTH11"), '11').
            when(col('period').contains("4WEEK13") | col('period').contains("MTH12"), '12').
            otherwise(col('period')))

  df_fact_trans = df_fact_trans.withColumn("month_sk",
                              when(col('period').contains("4WEEK") | col('period').contains("MTH"), concat(col('year'),col('month')))
                              .otherwise(col('month_sk')))

  # Workings for flow SKs

  df_fact_trans = df_fact_trans.withColumn("Sales_Period_Group_ID",when (col("period").contains("4WEEK"), "4W")
            .when (col("period").contains("MTH"), "MON")
            .otherwise(col("period")))

  df_fact = df_fact_trans.filter(col("Sales_Period_Group_ID").isin(['L12W','L12W-1','L12W-1Y','L12W-2','L12W-2Y','L12W-3Y','L12W-4Y','MAT','MAT-1','MAT-2','MAT-3','MAT-4','YTD','YTD-1','YTD-2','YTD-3','YTD-4','L4W','L4W-1Y','L4W-1','L4W-2',"4W","MON"]) | col("Sales_Period_Group_ID").rlike('FY-.*'))

except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Pivoting the upcoming data failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "pivoting the records completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Creating Manufacturer Master, GMIMS and GMI_Latest_Available dates (ConfCutBack) dataframes

# COMMAND ----------

try:
  #creating manufacturer data from Fact GMI data
  window = Window.orderBy(lit(1)).partitionBy(lit(1))
  df_manufacturer = df_fact.select('global_manufacturer_code','global_manufacturer_name','local_manufacturer_code','local_manufacturer_name').dropDuplicates()
  df_manufacturer = df_manufacturer.withColumn("manufacturer_sk",row_number().over(window)).select("manufacturer_sk", "local_manufacturer_code", "local_manufacturer_name","global_manufacturer_code", "global_manufacturer_name",lit(log_id).cast(IntegerType()).alias("job_id"),lit(current_timestamp()).alias("created_date"))

  #joining with necessary dimensions and bringing the sk's to fact
  df_product = df_product.where(col("source").like(f"%{stream.capitalize()}%" ))
  df_joined = df_fact.join(df_product, 'product_form_code', "left") \
                      .join(df_geography, df_fact.country_code == df_geography.mu_iso_country_code, "left") \
                      .join(df_measure, df_fact.MeasureType == df_measure.measure_description, "left") \
                      .join(df_flow, df_fact.Sales_Period_Group_ID == df_flow.flow_description, "left")\
                      .join(df_manufacturer, 'local_manufacturer_code',"left")\
                      .join(df_brand, df_fact.brand_code == df_brand.corporate_brand_code,"left")\
                      .join(df_brand_pos, df_fact.brand_position_code == df_brand_pos.brand_position_default_code,"left")\
    .select(df_fact["*"], df_product.product_sk, df_geography.geography_sk, df_measure.measure_sk, df_flow.flow_sk,df_manufacturer.manufacturer_sk,df_brand.brand_sk,df_brand_pos.brand_position_sk ).drop(*df_fact_columns)

  # creating GMI latest avilable data from fact GMI
  df_gmi_latest_available = df_joined.select("geography_sk", "country_code", "country_name", "product_sk","product_form_code", "product_form_name", "month_sk", "latest_available_date").\
    withColumn("month_name", date_format(col("latest_available_date"), "MMM-yyyy")).dropDuplicates().\
    withColumn("job_id",lit(log_id).cast(IntegerType()).alias("log_id")).\
    withColumn("created_date",lit(current_timestamp()))
    
  #structure of final dataframe for Fact GMI which will be used to write to delta
  df_final_0 = df_joined.select(col("product_sk")
                              ,coalesce(col("brand_sk"),lit(-1)).alias("brand_sk")
                              ,coalesce(col("brand_position_sk"),lit(-1)).alias("brand_position_sk")
                              ,col("flow_sk")
                              ,col("measure_sk")
                              ,col("geography_sk")
                              ,col("manufacturer_sk")
                              ,col("month_sk")
                              ,(col("Mkt_Value").cast("DOUBLE")/1000).alias("value")
                              ,lit(log_id).cast(IntegerType()).alias("log_id")
                              ,lit(current_timestamp()).alias("created_date")
                              )
  df_final = df_final_0.groupBy("product_sk","brand_sk","brand_position_sk","flow_sk","measure_sk","geography_sk","manufacturer_sk","month_sk","log_id","created_date").agg(sum("value").alias("value")).select("product_sk","brand_sk","brand_position_sk","flow_sk","measure_sk","geography_sk","manufacturer_sk","month_sk","value","log_id","created_date")
except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed at creating the final transformed dataframe", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Dataframe created for Manufacturer,Fact GMI and GMI_Latest_Available_dates", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

try:
  #creating dictionary for dataframes similar to other dictionaries path,database and table name, for passing it inside the write function dynamically
  df_dict = dict()
  df_list = [df_final,df_gmi_latest_available,df_manufacturer]
  key_list = list(delta_db_silver.keys())
  for value in range(0,len(key_list)):
    df_dict.update({key_list[value]:df_list[value]})
except Exception as e:
  error = str(e).replace("'", "")
  error_code = type(e).__name__
  counter = counter + 1
  update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
  update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
  insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Creating dictionary using dataframes failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
  raise e
else :
  counter = counter+1
  insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Dictionary created with all the dataframes", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name,"")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Writing** in to Silver Table

# COMMAND ----------

try:
    for key in key_list:
        concurrent_external_table_delta_write(df_dict[key],absolute_path + delta_path_silver[key], delta_db_silver[key], delta_table_silver[key],None, catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False",delta_overwrite_mode = "full" )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing to GMI Measure Pivot Table

# COMMAND ----------

try:
    df_fact = df_final.join(df_measure,df_final["measure_sk"] == df_measure["measure_sk"],"left").select(df_final["*"],df_measure["measure_description"]).groupBy("product_sk","brand_sk","brand_position_sk","flow_sk","geography_sk","manufacturer_sk","month_sk","log_id","created_date").pivot("measure_description").agg(sum('value'))

    concurrent_external_table_delta_write(df_fact,absolute_path + delta_path_gold_pivot, list(delta_db_gold.values())[0], delta_pivot_table,None, catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False",delta_overwrite_mode = "full" )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to pivot delta table failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Pivot delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")



# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact GMI completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
