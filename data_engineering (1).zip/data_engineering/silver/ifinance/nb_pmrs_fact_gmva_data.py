# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Fact Actuals Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   25 Nov 2024     |    Vinod          |    Notebook Created |
# MAGIC
# MAGIC
# MAGIC ## Purpose
# MAGIC This Notebook is used to load Fact Autuals data
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType, DecimalType
from pyspark.sql.functions import (col, lit, lower, regexp_replace, regexp_extract, trim,current_timestamp, desc, row_number, size, replace, to_date, month,year, last, coalesce, expr, when)
from delta.tables import DeltaTable
import datetime
start_time = datetime.datetime.now()


# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "192")  # Adjust based on your total cores
spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Utils

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Widgets

# COMMAND ----------

#getting from parent notebook
external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
#username                = dbutils.widgets.get("user_name")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("run_id")
job_id                  = dbutils.widgets.get("job_id")
#file_name               = dbutils.widgets.get("file_name")

#Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------


dbutils.widgets.removeAll()

dbutils.widgets.text("measure_data_feed","master_data_measure")
measure_data_feed       = dbutils.widgets.get("measure_data_feed")

dbutils.widgets.text("currency_data_feed","master_data_currency")
currency_data_feed       = dbutils.widgets.get("currency_data_feed")

dbutils.widgets.text("version_data_feed","master_data_version")
version_data_feed       = dbutils.widgets.get("version_data_feed")

dbutils.widgets.text("cont_disc_ops_data_feed","master_data_cont_disc_ops")
cont_disc_ops_data_feed       = dbutils.widgets.get("cont_disc_ops_data_feed")

dbutils.widgets.text("calendar_data_feed","master_data_calendar")
calendar_data_feed       = dbutils.widgets.get("calendar_data_feed")

dbutils.widgets.text("flow_data_feed","master_data_flow")
flow_data_feed       = dbutils.widgets.get("flow_data_feed")

dbutils.widgets.text("descendant_data_feed","master_data_descendant")
descendant_data_feed       = dbutils.widgets.get("descendant_data_feed")

dbutils.widgets.text("user_name", "default")
username = dbutils.widgets.get("user_name")

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]
    current_nb_name = "nb_pmrs_fact_gmva_data"
    
    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username,"GMVA Manual File ingestion", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for GMVA manual load", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

try:
    
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    param       = get_param_data(uc_catalog_name)
    config_data = get_config_data(data_feed,uc_catalog_name,"finance")


    # Fetch specific configuration
    process_feed_df                      = fetch_config(param, data_feed)
    calendar_process_feed_df             = fetch_config(param, calendar_data_feed)
    cont_dis_ops_process_feed_df         = fetch_config(param, cont_disc_ops_data_feed)
    currency_process_feed_df             = fetch_config(param, currency_data_feed)
    flow_process_feed_df                 = fetch_config(param, flow_data_feed)
    measure_process_feed_df              = fetch_config(param, measure_data_feed)
    version_process_feed_df              = fetch_config(param, version_data_feed)
    descendant_process_feed_df           = fetch_config(param, descendant_data_feed)

    # Display the filtered data
    display(process_feed_df)

    catalog_name                         = uc_catalog_name
    delta_db_staging                     = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging                  = process_feed_df.select("delta_table_staging").first()[0]
    delta_db_silver                      = process_feed_df.select("delta_db_silver").first()[0]
    delta_table_silver                   = process_feed_df.select("delta_table_silver").first()[0]
    delta_path_silver                    = absolute_path+process_feed_df.select("delta_path_silver").first()[0]
    calendar_delta_db_gold               = calendar_process_feed_df.select("delta_db_gold").first()[0]
    calendar_delta_table_gold            = calendar_process_feed_df.select("delta_table_gold").first()[0]
    cont_disc_ops_delta_db_gold          = cont_dis_ops_process_feed_df.select("delta_db_gold").first()[0]
    cont_disc_ops_delta_table_gold       = cont_dis_ops_process_feed_df.select("delta_table_gold").first()[0]
    currency_delta_db_gold               = currency_process_feed_df.select("delta_db_gold").first()[0]
    currency_delta_table_gold            = currency_process_feed_df.select("delta_table_gold").first()[0]
    flow_delta_db_gold                   = flow_process_feed_df.select("delta_db_gold").first()[0]
    flow_delta_table_gold                = flow_process_feed_df.select("delta_table_gold").first()[0]
    measure_delta_db_gold                = measure_process_feed_df.select("delta_db_gold").first()[0]
    measure_delta_table_gold             = measure_process_feed_df.select("delta_table_gold").first()[0]
    version_delta_db_gold                = version_process_feed_df.select("delta_db_gold").first()[0]
    version_delta_table_gold             = version_process_feed_df.select("delta_table_gold").first()[0]
    descendant_delta_db_silver           = descendant_process_feed_df.select("delta_db_silver").first()[0]
    descendant_delta_table_silver        = descendant_process_feed_df.select("delta_table_silver").first()[0]

    rename_columns = config_data.get("rename_cols_silver",{})
    if rename_columns:
        rename = True
    else:
        rename = False

    if debug_flag == "1":

        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)
        print('calendar_delta_db_gold           :', calendar_delta_db_gold)
        print('calendar_delta_table_gold        :', calendar_delta_table_gold)
        print('cont_disc_ops_delta_db_gold      :', cont_disc_ops_delta_db_gold)
        print('cont_disc_ops_delta_table_gold   :', cont_disc_ops_delta_table_gold)
        print('currency_delta_db_gold           :', currency_delta_db_gold)
        print('currency_delta_table_gold        :', currency_delta_table_gold)
        print('flow_delta_db_gold               :', flow_delta_db_gold)
        print('flow_delta_table_gold            :', flow_delta_table_gold)
        print('measure_delta_db_gold            :', measure_delta_db_gold)
        print('measure_delta_table_gold         :', measure_delta_table_gold)
        print('version_delta_db_gold            :', version_delta_db_gold)
        print('version_delta_table_gold         :', version_delta_table_gold)
        print('descendant_delta_db_silver       :', descendant_delta_db_silver)
        print('descendant_delta_db_silver       :', descendant_delta_table_silver)
        print('rename_columns                   :', rename)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:

    tables = {
        "df_fact"           : f"{catalog_name}.{delta_db_staging}.{delta_table_staging}",
        "df_bu"             : f"{catalog_name}.{measure_delta_db_gold}.business_unit",
        "df_pcat"           : f"{catalog_name}.{measure_delta_db_gold}.product",
        "df_measure"        : f"{catalog_name}.{measure_delta_db_gold}.{measure_delta_table_gold}",
        "df_currency"       : f"{catalog_name}.{currency_delta_db_gold}.{currency_delta_table_gold}",
        "df_version"        : f"{catalog_name}.{version_delta_db_gold}.{version_delta_table_gold}",
        "df_cont_disc_ops"  : f"{catalog_name}.{cont_disc_ops_delta_db_gold}.{cont_disc_ops_delta_table_gold}",
        "df_calendar"       : f"{catalog_name}.{calendar_delta_db_gold}.{calendar_delta_table_gold}",
        "df_flow"           : f"{catalog_name}.{flow_delta_db_gold}.{flow_delta_table_gold}",
        "df_descendant"     : f"{catalog_name}.{descendant_delta_db_silver}.{descendant_delta_table_silver}"
    }

    for df_name, table in tables.items():
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in table checking", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:

        df_descendant_bu = df_descendant.filter(df_descendant["dimension"].isin("mu")).withColumnRenamed("descendant_sk", "des_bu_sk")
        df_descendant_pcat = df_descendant.filter(df_descendant["dimension"] == "pcat").withColumnRenamed("descendant_sk", "des_product_sk")

        df_bu = df_bu.withColumn("bu_code",regexp_replace("bu_code", "CBU-", ""))\
                        .filter(lower(df_bu["source"]) == 'local finance')

        df_fact_columns = [ col for col in df_fact.columns if col not in ["is_active", "log_id", "created_date"]]

        df_fact = df_fact.withColumnRenamed("bu_code", "bucode")
        df_flow   = df_flow.filter(df_flow["is_active"] == True)

        df  = df_fact.join(df_bu , df_fact.bucode == df_bu.bu_code,"left")\
                .join(df_descendant_bu, df_fact.bucode  ==  df_descendant_bu.child_code,"left") \
                .join(df_pcat, df_pcat['product_form_code'].contains(df_fact['pccode']) , "left")\
                .join(df_descendant_pcat, df_fact.pccode  ==  df_descendant_pcat.child_code,"left")\
                .join(df_flow,lower(trim(df_fact["flow"])) == lower(trim(df_flow["flow_description"])),"left")

        # # Apply the filter condition with LIKE and LOWER for case-insensitivity
        # df = df.withColumn("source_status",
        #                 when(
        #                 (lower(df_bu['source']).like('%local%')) | 
        #                 (lower(df_pcat['source']).like('%local%')) | 
        #                 (lower(df_flow['source']).like('%local%')),
        #                 'Valid').otherwise('Invalid')
        #                 )

        # # Check if any rows are invalid and raise an exception
        # if df.filter(df['source_status'] == 'Invalid').count() > 0:
        #         raise AnalysisException("Invalid data detected! Some rows contain 'Invalid' source status.")

        df = df.select(col("des_product_sk"),
                col("des_bu_sk"),
                col("bu_sk"),
                col("product_sk")
                ,*[col(c) for c in df_fact_columns])

        df1 = (df.withColumn("bu_sk_1", when(col("des_bu_sk").isNotNull(), col("des_bu_sk")).otherwise(col("bu_sk")))
                .drop("bu_sk", "des_bu_sk")
                .withColumn("product_sk_1",when(df.des_product_sk.isNotNull(), df.des_product_sk).otherwise(df.product_sk), )
                .drop("des_product_sk", "product_sk"))
        for col in df1.columns:
                new_col = col.replace('%', 'percent').replace('p_m', 'pm')
                if new_col != col:
                        df1 = df1.withColumnRenamed(col, new_col)

        if config_data['rename_cols_silver']:
                print(rename_columns)
                df1 = df1.withColumnsRenamed(rename_columns)

        df1 = df1.withColumn("product_sk", when(df1["product_sk_1"].isNull(), -1).otherwise(df1["product_sk_1"])) \
             .withColumn("bu_sk", when(df1["bu_sk_1"].isNull(), -1).otherwise(df1["bu_sk_1"])).drop("product_sk_1", "bu_sk_1")

        columns_to_unpivot = [col for col in df1.columns if col not in ['product_sk', 'bu_sk', 'bucode', 'business_unit',  'pcat_code', 'pccode', 'product_category', 'period', 'flow', 'version', 'ex_rate_code', 'ex_rate', 'data_type_code', 'data_type','cont_disc_ops','cont_disc_ops_code']]
        columns_with_all_nulls = [col for col in columns_to_unpivot if df1.filter(df1[col].isNotNull()).count() == 0]
        columns_to_unpivot = [col for col in columns_to_unpivot if col not in columns_with_all_nulls]

        num_columns = len(columns_to_unpivot)

    
        unpivoted_df = df1.select('product_sk', 'bu_sk', 'period', 'flow', 'data_type', 'version', 'ex_rate_code', 'cont_disc_ops_code', 
                          expr(f"stack({num_columns}, " + ", ".join([f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure, value)"))
        
        unpivoted_df = unpivoted_df.withColumn("version_1",when(unpivoted_df["version"] == "200 Monthly - Actual", "Actual").otherwise(unpivoted_df["version"])).drop("version")

        unpivoted_df = unpivoted_df.withColumnRenamed("version_1","version")


except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in Pivoting the records", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else:
    counter += 1
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Pivoting the records completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")

# COMMAND ----------

try:
    from pyspark.sql.functions import col, trim, lower
    replacements  = [("%", "percent"),("٪", "percent"),("/", "_"),("&","_"),("[- ]", "_"),("_+", "_"),("–", " "),("[^a-zA-Z0-9_]", ""),(r"^_|_$", "")]

    df_measure    = df_measure.withColumn("temp_description", lower(df_measure["measure_description"]))

    # Apply filtering early
    df_measure   = df_measure.filter(df_measure["is_active"] == True)

    # Apply transformations using a loop
    for pattern, replacement in replacements:
        df_measure = df_measure.withColumn("temp_description", regexp_replace(df_measure["temp_description"], pattern, replacement))

    df_measure  = df_measure.withColumn("temp_description", trim(df_measure["temp_description"]))

    # Rename back to measure_description
    df_measure  = df_measure.drop("measure_description").withColumnRenamed("temp_description", "measure_description")

    final_df = unpivoted_df.join(df_measure, df_measure.measure_description == unpivoted_df.measure, "left")\
                     .join(df_flow,lower(trim(unpivoted_df["flow"])) == lower(trim(df_flow["flow_description"])),"left")\
    
    final_df=final_df.withColumn("year", regexp_extract(final_df["period"], r"\d{4}", 0))
    
    final_df = final_df.withColumn(
	                "filter_summary",
		            when(
		            col('year') % 2 == 0, "Odd"
		            ).otherwise("Even")
		        )
        
    final_df = final_df.withColumn(
	                "version_desc",
		            concat(col('version'), lit(' - '), col('filter_summary'))
		        )

    unmatched_measures = unpivoted_df.join(
    df_measure, 
    df_measure.measure_description == unpivoted_df.measure, 
    "left_anti").select("measure").distinct()
    
    unmatched_measures.display()

    df_final = final_df \
        .join(df_currency, final_df.ex_rate_code == df_currency.currency_code, "left") \
        .join(df_version, lower(final_df.version_desc) == lower(df_version['version_description']), "left") \
        .join(df_cont_disc_ops, final_df.cont_disc_ops_code == df_cont_disc_ops.cont_disc_ops_code, "left") \
        .join(df_calendar, final_df["period"] == df_calendar["month_short_description"], "left") \
        .select('bu_sk', 'product_sk', 'month_sk', 'measure_sk', 'cont_disc_ops_sk', 
                'currency_sk', 'version_sk', 'flow_sk','data_type', 'value')

    df_final = df_final.withColumn("log_id", lit(log_id).cast(IntegerType())) \
                       .withColumn("created_date", lit(current_timestamp())) \
                       .withColumn("value", regexp_replace(col("value"), "[$,€£¥%]", "").cast(DecimalType(36, 16)))
        
    if spark.catalog.tableExists(f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"):
        #Delete and Load if table has records
        key_columns = ['bu_sk', 'product_sk', 'month_sk', 'measure_sk', 'cont_disc_ops_sk', 'currency_sk', 'version_sk', 'flow_sk','data_type']

        target_df = spark.table(f"{catalog_name}.{delta_db_silver}.{delta_table_silver}")

        unmatched_target_df = target_df.join(df_final, key_columns, "left_anti")
 
        if unmatched_target_df.isEmpty():
            result_df = df_final
        else:
            result_df = unmatched_target_df.union(df_final)
    else:
        print("Table does not exist")
        result_df = df_final

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in GMVA Actuals using measure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing in to Silver Table

# COMMAND ----------

try:

    concurrent_external_table_delta_write(result_df, delta_path_silver, delta_db_silver, delta_table_silver, None, catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag="False" , delta_overwrite_mode = "full" )
    
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact GMVA Manual File ingestion completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
