# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks config Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 10 Sept 2024        |    Prasanth         |    Notebook Creation |
# MAGIC
# MAGIC ## Purpose
# MAGIC The purpose of the document is to have all the Dummy and Descendant functionality that will be used by all the notebooks
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and librarys

# COMMAND ----------


from pyspark.sql import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.functions import * 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Descendant and Dummy Logic Functions

# COMMAND ----------

def process_hierarchy_levels(map_hierarchy_main_df: DataFrame, renamed_df: DataFrame, code_col: str, highest_level: int) -> DataFrame:

    map_hierarchy_df = map_hierarchy_main_df

    source_list = [row[code_col] for row in map_hierarchy_df.select(code_col).distinct().collect()]
    
    hierarchy_levels = list(range(0, highest_level))

    final_silver_df = None
    
    print('\n')

    for level in hierarchy_levels:
        
        print(f'Processing {code_col} Hierarchy level {level} in dimension {map_hierarchy_main_df.select("dimension").dropDuplicates().first()[0]}')
        
        col_name = f"hier_level_{level}_code"
        
        filtered_df = renamed_df.filter(col(col_name).isin(source_list))
        
        silver_df = filtered_df.groupBy(col(col_name).alias("level_code")) \
                               .agg(collect_set(col("sugg_sk")).alias("lowest_level_dimension_sk"))
        
        if final_silver_df is None:
            final_silver_df = silver_df
        else:
            final_silver_df = final_silver_df.unionByName(silver_df, allowMissingColumns=True)
    
    final_df = map_hierarchy_df.alias("a") \
                .join(final_silver_df.alias("b"), col(f"a.{code_col}") == col("b.level_code"), "left") \
                .select(col("a.*"), col("b.lowest_level_dimension_sk").alias(f"{code_col}_sk"))
    
    return final_df

# COMMAND ----------

def generate_descent_fn(business_unit_mu, levels):
    """
    Generates a hierarchical descendant DataFrame based on input levels.

    Parameters:
    - business_unit_mu: Input DataFrame containing hierarchy data.
    - levels: The number of levels in the hierarchy to process.

    Returns:
    - A DataFrame containing child-parent relationships, level numbers, and descendant information.
    """

    # Initialize the result DataFrame with the base hierarchy level (level 0)
    result_df = business_unit_mu.select(
        col("hier_level_0_code").alias("child_code"),  # Child code from level 0
        col("dimension")  # Dimension column
    ).distinct() \
        .withColumn("parent_code", lit(None)) \
        .withColumn("level_num", lit(0)) \
        .withColumn("descendant", col("child_code"))

    # Loop through the hierarchy levels and build parent-child relationships
    for i in range(0, levels):
        print('Level Num    : ', i, "\n")
        parent_col = f"hier_level_{i}_code"  # Parent column for the current level
        child_col = f"hier_level_{i + 1}_code"  # Child column for the next level

        # Extract child-parent relationships for the current level
        temp_df = business_unit_mu.select(
            col(child_col).alias("child_code"),  # Child code for the current level
            col(parent_col).alias("parent_code"),  # Parent code for the current level
            col("dimension")  # Dimension column
        ).distinct() \
            .withColumn("level_num", lit(i + 1)) \
            .withColumn("descendant", col("child_code")) 

        # Combine the result with the current level data
        result_df = result_df.unionByName(temp_df)

    # Filter out rows with null child codes
    result_df = result_df.filter(col("child_code").isNotNull())

    # Determine the maximum level number in the hierarchy
    max_level_num = result_df.select(
        col("level_num").cast("int").alias("level_num")  # Cast level number to integer
    ).distinct().orderBy(col("level_num").desc()).limit(1).first()[0]

    # Update the descendant column for rows at the maximum level
    df_combined_final = result_df.withColumn(
        "descendant",
        when(col("level_num") == max_level_num, lit(None))  # Set descendant to None for max level
        .otherwise(concat(lit(f"DL{max_level_num}-"), col("child_code")))  # Append prefix for others
    )

    return df_combined_final 

# COMMAND ----------

def process_hierarchy_levels_with_description(df: DataFrame, levels: list, dimension_name: str) -> DataFrame:
    """
    Processes a hierarchy DataFrame, filling in missing codes and descriptions
    for each level based on parent-child relationships.

    Parameters:
    - df: Input DataFrame containing hierarchy data.
    - levels: List of tuples, where each tuple defines:
        (current_code, current_desc, prefix) for each level.
    - dimension_name: The name of the dimension to add as a column.

    Returns:
    - A DataFrame with updated codes and descriptions for the hierarchy levels.
    """

    # Add a column for the dimension
    df = df.withColumn("dimension", lit(dimension_name))

    # Iterate through levels to process hierarchy relationships
    for i in range(1, len(levels)):
        current_code, current_desc, prefix = levels[i]  # Current level details
        parent_code = levels[i - 1][0]  # Parent level code
        parent_desc = levels[i - 1][1]  # Parent level description

        # Fill missing current codes by concatenating the prefix with the parent code
        df = df.withColumn(
            current_code,
            when(
                col(current_code).isNull(),
                concat(lit(prefix), col(parent_code)),
            ).otherwise(col(current_code)),
        )

        # Remove the parent prefix from the current code if it matches
        if prefix:
            df = df.withColumn(
                current_code,
                when(
                    col(current_code).rlike(f"{prefix}{levels[i - 1][2] or ''}"),
                    regexp_replace(col(current_code), levels[i - 1][2] or "", ""),
                ).otherwise(col(current_code)),
            )

        # Fill missing descriptions with the parent description
        df = df.withColumn(
            current_desc,
            when(
                col(current_desc).isNull(),
                col(parent_desc)
            ).otherwise(col(current_desc)),
        )

    return df

# COMMAND ----------

def dummy_function_call(df_transformed, num_levels, base_columns):
    """
    This function generates the Dummy level entries from each Hierarchy levels for the given dataframe.

    Parameters:
    - df_transformed: Input DataFrame containing transformed data.
    - num_levels: The number of hierarchy levels to process.
    - base_columns: A list of columns that are always included in the output.

    Returns:
    - A unioned DataFrame containing the hierarchical data with levels filled in.
    """

    # Dictionary to store filtered DataFrames for each level
    filter_dfs = {}

    # Loop through each hierarchy level from 0 to num_levels
    for level in range(0, num_levels + 1):
        # Select base columns along with hierarchy codes and descriptions for the current level
        selected_columns = (
            base_columns +
            [f"hier_level_{lvl}_code" for lvl in range(1, level + 1)] +
            [f"hier_level_{lvl}_description" for lvl in range(1, level + 1)]
        )

        # Define the condition to filter rows where both code and description are not null for the current level
        condition = (
            col(f"hier_level_{level}_code").isNotNull() &
            col(f"hier_level_{level}_description").isNotNull()
        )

        # Filter rows based on the condition and select the relevant columns
        filtered_df = df_transformed.select(selected_columns).filter(condition).distinct()
        
        # Store the filtered DataFrame in the dictionary
        filter_dfs[f"filter_df{level}"] = filtered_df

    # Remove the DataFrame for the highest level as it will not be used
    if f"filter_df{num_levels}" in filter_dfs:
        del filter_dfs[f"filter_df{num_levels}"]

    # Initialize a variable to hold the unioned DataFrame
    union_df = None

    # Iterate through the filtered DataFrames for processing
    for key, df_transformed_input in filter_dfs.items():
        df_transformed = df_transformed_input  # Get the current DataFrame

        # Fill in missing levels for the current DataFrame
        for level in range(0, num_levels + 1):
            if f"hier_level_{level}_code" in df_transformed.columns:
                # If the column exists, track the current level
                present_level = level
            else:
                # Add missing columns with default values based on the present level
                df_transformed = df_transformed.withColumn(
                    f"hier_level_{level}_code",
                    concat(lit(f"DL{level}-"), col(f"hier_level_{present_level}_code"))
                ).withColumn(
                    f"hier_level_{level}_description",
                    concat(lit(f"DL{level}-"), col(f"hier_level_{present_level}_description"))
                )

        # Remove duplicate rows
        df_transformed = df_transformed.distinct()

        # Union the current DataFrame with the cumulative result
        if union_df is None:
            union_df = df_transformed
        else:
            union_df = union_df.unionByName(df_transformed).distinct()
            
    # Return the final unioned DataFrame
    return union_df


# COMMAND ----------

def generate_flat_hierarchy(
    df,
    filter_condition,
    level_definitions: List[Union[Tuple[str, str, str], Tuple[str, str, str, int]]],
    output_column_names: Tuple[str, str, str] = ("key", "code", "description"),
    flag_column_name: Optional[str] = None
):
    """
    Creates a unified hierarchical DataFrame with standardized columns.

    :param df: Input DataFrame
    :param filter_condition: Filter condition to apply on the DataFrame
    :param level_definitions: List of tuples representing each hierarchy level.
           Each tuple can be (key_col, code_col, desc_col) or (key_col, code_col, desc_col, flag_val)
    :param output_column_names: Tuple for standardized column names (key, code, description)
    :param flag_column_name: Optional. If provided, adds a flag column with the specified name and value per level
    :return: Unioned and standardized DataFrame
    """
    if filter_condition is not None:
        filtered_df = df.filter(filter_condition)
    else:
        filtered_df = df
    key_out, code_out, desc_out = output_column_names

    all_levels = []

    for level in level_definitions:
        if len(level) == 4:
            key_col, code_col, desc_col, flag_val = level
        else:
            key_col, code_col, desc_col = level
            flag_val = None

        level_df = filtered_df.select(key_col, code_col, desc_col).dropDuplicates() \
            .withColumnRenamed(key_col, key_out) \
            .withColumnRenamed(code_col, code_out) \
            .withColumnRenamed(desc_col, desc_out)

        if flag_column_name and flag_val is not None:
            level_df = level_df.withColumn(flag_column_name, lit(flag_val))

        all_levels.append(level_df)

    final_df = all_levels[0]
    for df_piece in all_levels[1:]:
        final_df = final_df.union(df_piece)

    return final_df.dropDuplicates()


# COMMAND ----------

def bu_flat (staging_df,catalog_name,object_owner_spn,absolute_path):

    staging_df = staging_df.filter(col('dimension_name')=='BusinessUnit').withColumnRenamed('descendant_sk','bu_sk')

    bu_df      = spark.table(f'{catalog_name}.gold_master_data.business_unit_extended')

    bu_hierarchy_levels = [
        ("dim_bu_sk", "dim_mu_hier_level_0_code", "dim_mu_hier_level_0_description"),
        ("dim_bu_sk", "dim_mu_hier_level_1_code", "dim_mu_hier_level_1_description"),
        ("dim_bu_sk", "dim_mu_hier_level_2_code", "dim_mu_hier_level_2_description"),
        ("dim_bu_sk", "dim_mu_hier_level_3_code", "dim_mu_hier_level_3_description"),
        ("dim_bu_sk", "dim_mu_hier_level_4_code", "dim_mu_hier_level_4_description"),
        ("dim_bu_sk", "dim_mu_hier_level_5_code", "dim_mu_hier_level_5_description"),
        ("dim_bu_sk", "dim_mu_code", "dim_mu_description")]

    delta_path_gold = f"{absolute_path}data_engineering/gold/finance/flat_bu"
    delta_table_gold = 'flat_bu'

    bu_filtered_condition = (col("bubg_dashboard_type") == "BUBG") | (col("dim_source") == "calculated")

    bu_final_df = generate_flat_hierarchy(
        bu_df,
        filter_condition=bu_filtered_condition,
        level_definitions=bu_hierarchy_levels,
        output_column_names=("bu_sk", "bu_code", "bu_description"))
 
    joined_df = bu_final_df.join(staging_df, on="bu_sk", how="left")

    final_df = joined_df.withColumn(
        "alternate_description",
        coalesce("alternate_description", "bu_description"))
    
    final_df=final_df.select('bu_sk','bu_code','bu_description','alternate_description')

    concurrent_external_table_delta_write(final_df, delta_path_gold, delta_db_gold, delta_table_gold, "", catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )



# COMMAND ----------

def pcat_flat (staging_df,catalog_name,object_owner_spn,absolute_path):

    staging_df     = staging_df.filter(col('dimension_name')=='ProductCategory').withColumnRenamed('descendant_sk','product_sk')

    product_df      = spark.table(f'{catalog_name}.gold_master_data.product_extended')

    delta_path_gold = f"{absolute_path}data_engineering/gold/finance/flat_pcat"
    delta_table_gold = 'flat_pcat'

    pcat_hierarchy_levels = [
    ("dim_product_sk", "dim_total_unilever_by_product_category_code", "dim_total_unilever_by_product_category_description", 1),
    ("dim_product_sk", "dim_legacy_division_code", "dim_legacy_division_description", 1),
    ("dim_product_sk", "dim_division_code", "dim_division_description", 1),
    ("dim_product_sk", "dim_sub_division_2_code", "dim_sub_division_2_description", 1),
    ("dim_product_sk", "dim_category_code", "dim_category_description", 0),
    ("dim_product_sk", "dim_market_code", "dim_market_description", 0)]

    pcat_filtered_condition = (col("All_dashboard_type") == "All") | (col("dim_source") == "calculated")

    pcat_final_df = generate_flat_hierarchy(
        product_df,
        filter_condition=pcat_filtered_condition,
        level_definitions=pcat_hierarchy_levels,
        output_column_names=("product_sk", "total_unilever_by_product_category_code", "total_unilever_by_product_category_description"),
        flag_column_name="visible_flag"
    )

    pcat_final_df.display()
 
    joined_df = pcat_final_df.join(staging_df, on="product_sk", how="left")
 
    final_df = joined_df.withColumn(
        "alternate_description",
        coalesce("alternate_description", "total_unilever_by_product_category_description"))
    
    final_df=final_df.select('product_sk','total_unilever_by_product_category_code','total_unilever_by_product_category_description','alternate_description','visible_flag')

    concurrent_external_table_delta_write(final_df, delta_path_gold, delta_db_gold, delta_table_gold, "", catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )



# COMMAND ----------

def brand_flat (staging_df,catalog_name,object_owner_spn,absolute_path):

    staging_df = staging_df.filter(col('dimension_name')=='Brand').withColumnRenamed('descendant_sk','brand_sk')

    bu_df      = spark.table(f'{catalog_name}.gold_master_data.brand')

    bu_hierarchy_levels = [
        ("brand_sk", "corporate_brand_code", "corporate_brand_description")]

    delta_path_gold = f"{absolute_path}data_engineering/gold/finance/flat_brand"
    delta_table_gold = 'flat_brand'

    bu_final_df_brand = generate_flat_hierarchy(
        bu_df,
        filter_condition=None,
        level_definitions=bu_hierarchy_levels,
        output_column_names=("brand_sk", "brand_code", "brand_description"))
    
    
    bu_df_bp      = spark.table(f'{catalog_name}.gold_master_data.brand_position')

    bu_hierarchy_levels = [
        ("brand_position_sk", "brand_position_finance_code", "brand_position_description")]

    bu_final_df_bp = generate_flat_hierarchy(
        bu_df_bp,
        filter_condition=None,
        level_definitions=bu_hierarchy_levels,
        output_column_names=("brand_sk", "brand_code", "brand_description"))    

    bu_final_df = bu_final_df_bp.union(bu_final_df_brand)

    concurrent_external_table_delta_write(bu_final_df, delta_path_gold, delta_db_gold, delta_table_gold, "", catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )



# COMMAND ----------

def process_company(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path,debug_flag):
    """
    Processes Customer data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """

    levels = [
        ("hier_level_0_code", "hier_level_0_description", None),
        ("hier_level_1_code", "hier_level_1_description", "LV1-"),
        ("hier_level_2_code", "hier_level_2_description", "LV2-"),
        ("hier_level_3_code", "hier_level_3_description", "LV3-"),
        ("hier_level_4_code", "hier_level_4_description", "LV4-"),
        ("hier_level_5_code", "hier_level_5_description", "LV5-"),
        ("hier_level_6_code", "hier_level_6_description", "LV6-"),
    ]

    # Map the original column names to the new hierarchy column names
    column_re_mappings = {
        "total_legal_entity_geography_code"        : "hier_level_0_code",
        "total_legal_entity_geography_description" : "hier_level_0_description",
        "region_code"                              : "hier_level_1_code",
        "region_description"                       : "hier_level_1_description",
        "cluster_code"                             : "hier_level_2_code",
        "cluster_description"                      : "hier_level_2_description",
        "sub_region_code"                          : "hier_level_3_code",
        "sub_region_description"                   : "hier_level_3_description",
        "country_code"                             : "hier_level_4_code",
        "country_description"                      : "hier_level_4_description",
        "sub_country_code"                         : "hier_level_5_code",
        "sub_country_description"                  : "hier_level_5_description",
        "legal_entity_code"                        : "hier_level_6_code",
        "legal_entity_description"                 : "hier_level_6_description",
    }
    # Get the list of new column names
    columns = list(column_re_mappings.values())

    # Rename the columns in the DataFrame and select the distinct rows
    renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

    # Process the hierarchy levels with descriptions
    final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "company")

    # Define the temporary path for storing the DataFrame
    temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

    # Write the DataFrame to the temporary path in Parquet format
    final_df_new.write.mode("overwrite").parquet(temp_path)

    # Read the DataFrame from the temporary path
    final_df_temp = spark.read.parquet(temp_path)

    # Generate the descendant DataFrame
    final_df = generate_descent_fn(final_df_temp, 6)

    descentant_table_delta_write(final_df, descendant_path, descendant_db, descendant_table, partition_columns=["dimension"],
                                        catalog_name=catalog_name, object_owner_spn=object_owner_spn, retry_count=0, overwriteSchema_flag="false", delta_overwrite_mode="full")

    column_mappings = { 
        "hier_level_0_code"        : "total_legal_entity_geography_code",
        "hier_level_0_description" : "total_legal_entity_geography_description",
        "hier_level_1_code"        : "region_code",
        "hier_level_1_description" : "region_description",
        "hier_level_2_code"        : "cluster_code",
        "hier_level_2_description" : "cluster_description",
        "hier_level_3_code"        : "sub_region_code",
        "hier_level_3_description" : "sub_region_description",
        "hier_level_4_code"        : "country_code",
        "hier_level_4_description" : "country_description",
        "hier_level_5_code"        : "sub_country_code",
        "hier_level_5_description" : "sub_country_description",
        "hier_level_6_code"        : "legal_entity_code",
        "hier_level_6_description" : "legal_entity_description",
    }

    write_df = dummy_function_call(final_df_temp, 6, ["hier_level_0_code", "hier_level_0_description"])
    write_df = write_df.withColumnsRenamed(column_mappings)

    # Rename the columns in the final DataFrame
    final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

    if debug_flag =="1":
        renamed_df.display()

    # Return both DataFrames as a tuple
    return final_df_temp, write_df, final_df


# COMMAND ----------

def process_customer_channel(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes Customer Channel data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    try:
        # Process only for the specified data feed
        if data_feed == "master_data_customer_channel":
            # Filter rows based on the macro_channel_subscribe column
            staging_df = staging_df.filter(lower(col("macro_channel_subscribe")).contains("finance"))

            # Define hierarchical levels with codes and descriptions
            levels = [
                ("hier_level_0_code", "hier_level_0_description", None),
                ("hier_level_1_code", "hier_level_1_description", "LV1-"),
                ("hier_level_2_code", "hier_level_2_description", "LV2-"),
                ("hier_level_3_code", "hier_level_3_description", "LV3-")
            ]

            # Map original column names to hierarchical columns
            column_re_mappings = {
                "total_channel_code"      : "hier_level_0_code",
                "macro_channel_code"      : "hier_level_1_code",
                "format_channel_code"     : "hier_level_2_code",
                "sub_format_channel_code" : "hier_level_3_code",
                "total_channel_name"      : "hier_level_0_description",
                "macro_channel_name"      : "hier_level_1_description",
                "format_channel_name"     : "hier_level_2_description",
                "sub_format_channel_name" : "hier_level_3_description"
            }

            # List of renamed hierarchical columns
            columns = list(column_re_mappings.values())
            print(columns)

            # Rename columns and select the required ones
            renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

            # Process hierarchical levels and add descriptions
            final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "customer_channel")

            # Write intermediate result to a temporary path
            temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed
            final_df_new.write.mode("overwrite").parquet(temp_path)

            # Read the temporary data back for further processing
            final_df_temp = spark.read.parquet(temp_path)

            # Generate descendant data for the hierarchy
            final_df = generate_descent_fn(final_df_temp, 3)

            # Write the descendant table to Delta
            descentant_table_delta_write(
                final_df, descendant_path, descendant_db, descendant_table, 
                partition_columns=["dimension"], catalog_name=catalog_name, 
                object_owner_spn=object_owner_spn, retry_count=0, 
                overwriteSchema_flag="false", delta_overwrite_mode="full"
            )

            # Reverse the column mapping for the output
            column_mappings = {
                "hier_level_0_code"        : "total_channel_code",
                "hier_level_1_code"        : "macro_channel_code",
                "hier_level_2_code"        : "format_channel_code",
                "hier_level_3_code"        : "sub_format_channel_code",
                "hier_level_0_description" : "total_channel_name",
                "hier_level_1_description" : "macro_channel_name",
                "hier_level_2_description" : "format_channel_name",
                "hier_level_3_description" : "sub_format_channel_name"
            }

            # Generate additional hierarchical data with dummy function
            write_df = dummy_function_call(final_df_temp, 3, ["hier_level_0_code", "hier_level_0_description"])

            # Apply reverse mappings to column names
            write_df = write_df.withColumnsRenamed(column_mappings)
            final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

            if debug_flag =="1":
                renamed_df.display()

            # Return the final dataframes
            return final_df_temp, write_df, final_df

    except Exception as e:
        # Handle and log exceptions
        print(f"An error occurred: {str(e)}")
        raise


# COMMAND ----------

def process_customer(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes Customer data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    # Check if the data feed is for master data customer
    if data_feed == "master_data_customer":

        # Define the hierarchy levels and their descriptions
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-"),
            ("hier_level_3_code", "hier_level_3_description", "LV3-")
        ]

        # Map the original column names to the new hierarchy column names
        column_re_mappings = {
            "total_customer_code"                : "hier_level_0_code",
            "customer_importance_code"           : "hier_level_1_code",
            "global_customer_group_finance_code" : "hier_level_2_code",
            "global_customer_finance_code"       : "hier_level_3_code",
            "total_customer_description"         : "hier_level_0_description",
            "customer_importance_name"           : "hier_level_1_description",
            "global_customer_group_name"         : "hier_level_2_description",
            "global_customer_name"               : "hier_level_3_description"
        }

        # Get the list of new column names
        columns = list(column_re_mappings.values())

        # Rename the columns in the DataFrame and select the distinct rows
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process the hierarchy levels with descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "customer")

        # Define the temporary path for storing the DataFrame
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

        # Write the DataFrame to the temporary path in Parquet format
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read the DataFrame from the temporary path
        final_df_temp = spark.read.parquet(temp_path)

        # Generate the descendant DataFrame
        final_df = generate_descent_fn(final_df_temp, 3)

        # Write the descendant DataFrame to the Delta table
        descentant_table_delta_write(final_df, descendant_path, descendant_db, descendant_table, partition_columns=["dimension"],
                                     catalog_name=catalog_name, object_owner_spn=object_owner_spn, retry_count=0, overwriteSchema_flag="false", delta_overwrite_mode="full")

        # Map the hierarchy column names back to the original column names
        column_mappings = {
            "hier_level_0_code"        : "total_customer_code",
            "hier_level_1_code"        : "customer_importance_code",
            "hier_level_2_code"        : "global_customer_group_finance_code",
            "hier_level_3_code"        : "global_customer_finance_code",
            "hier_level_0_description" : "total_customer_description",
            "hier_level_1_description" : "customer_importance_name",
            "hier_level_2_description" : "global_customer_group_name",
            "hier_level_3_description" : "global_customer_name"
        }

        # Call a dummy function and rename the columns in the resulting DataFrame
        write_df = dummy_function_call(final_df_temp, 3, ["hier_level_0_code", "hier_level_0_description"])
        write_df = write_df.withColumnsRenamed(column_mappings)

        # Rename the columns in the final DataFrame
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return both DataFrames as a tuple
        return final_df_temp, write_df, final_df

# COMMAND ----------

def process_business_unit_mu(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes Business data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    if data_feed == "master_data_business_unit_mu":

        # Define hierarchical levels with codes and descriptions
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-"),
            ("hier_level_3_code", "hier_level_3_description", "LV3-"),
            ("hier_level_4_code", "hier_level_4_description", "LV4-"),
            ("hier_level_5_code", "hier_level_5_description", "LV5-"),
            ("hier_level_6_code", "hier_level_6_description", "LV6-"),
        ]

        # Map original column names to hierarchical columns
        column_re_mappings = {
            "mu_hier_level_0_code"        : "hier_level_0_code",
            "mu_hier_level_1_code"        : "hier_level_1_code",
            "mu_hier_level_2_code"        : "hier_level_2_code",
            "mu_hier_level_3_code"        : "hier_level_3_code",
            "mu_hier_level_4_code"        : "hier_level_4_code",
            "mu_hier_level_5_code"        : "hier_level_5_code",
            "mu_code"                     : "hier_level_6_code",
            "bu_code"                     : "hier_level_7_code",
            "mu_hier_level_0_description" : "hier_level_0_description",
            "mu_hier_level_1_description" : "hier_level_1_description",
            "mu_hier_level_2_description" : "hier_level_2_description",
            "mu_hier_level_3_description" : "hier_level_3_description",
            "mu_hier_level_4_description" : "hier_level_4_description",
            "mu_hier_level_5_description" : "hier_level_5_description",
            "mu_description"              : "hier_level_6_description",
            "bu_description"              : "hier_level_7_description",
        }

        # List of renamed hierarchical columns
        columns = list(column_re_mappings.values())

        # Rename columns and select distinct values
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process hierarchical levels and add descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "mu")

        # Define the temporary path for storing the DataFrame
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

        # Write the DataFrame to the temporary path in Parquet format
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read the processed data from temporary location
        final_df_temp = spark.read.parquet(temp_path)

        # Generate descendant data for the hierarchy
        final_df = generate_descent_fn(final_df_temp, 7)

        # Write the descendant table to Delta
        descentant_table_delta_write(
            final_df, descendant_path, descendant_db, descendant_table,
            partition_columns=["dimension"], catalog_name=catalog_name,
            object_owner_spn=object_owner_spn, retry_count=0,
            overwriteSchema_flag="false", delta_overwrite_mode="full"
        )

        # Map hierarchical columns back to original names for output
        column_mappings = {
            "hier_level_0_code"         : "mu_hier_level_0_code",
            "hier_level_1_code"         : "mu_hier_level_1_code",
            "hier_level_2_code"         : "mu_hier_level_2_code",
            "hier_level_3_code"         : "mu_hier_level_3_code",
            "hier_level_4_code"         : "mu_hier_level_4_code",
            "hier_level_5_code"         : "mu_hier_level_5_code",
            "hier_level_6_code"         : "mu_code",
            "hier_level_7_code"         : "bu_code",
            "hier_level_0_description"  : "mu_hier_level_0_description",
            "hier_level_1_description"  : "mu_hier_level_1_description",
            "hier_level_2_description"  : "mu_hier_level_2_description",
            "hier_level_3_description"  : "mu_hier_level_3_description",
            "hier_level_4_description"  : "mu_hier_level_4_description",
            "hier_level_5_description"  : "mu_hier_level_5_description",
            "hier_level_6_description"  : "mu_description",
            "hier_level_7_description"  : "bu_description",
        }

        # Generate additional hierarchical data with the dummy function
        write_df = dummy_function_call(final_df_temp, 7, ["hier_level_0_code", "hier_level_0_description"])

        # Apply reverse mappings to column names
        write_df = write_df.withColumnsRenamed(column_mappings)
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return the processed dataframes
        return final_df_temp, write_df, final_df

# COMMAND ----------

def process_business_unit_sc(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes Business data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    if data_feed == "master_data_business_unit_sc":

        # Define hierarchical levels with codes and descriptions
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-"),
            ("hier_level_3_code", "hier_level_3_description", "LV3-"),
            ("hier_level_4_code", "hier_level_4_description", "LV4-"),
            ("hier_level_5_code", "hier_level_5_description", "LV5-"),
            ("hier_level_6_code", "hier_level_6_description", "LV6-"),
            ("hier_level_7_code", "hier_level_7_description", "LV7-"),
            ("hier_level_8_code", "hier_level_8_description", "LV8-"),
        ]
        
        # Map original column names to hierarchical columns
        column_re_mappings = {
            "sc_level_0_code"        : "hier_level_0_code",
            "sc_level_1_code"        : "hier_level_1_code",
            "sc_level_2_code"        : "hier_level_2_code",
            "sc_level_3_code"        : "hier_level_3_code",
            "sc_level_4_code"        : "hier_level_4_code",
            "sc_level_5_code"        : "hier_level_5_code",
            "sc_level_6_code"        : "hier_level_6_code",
            "sc_mu_code"             : "hier_level_7_code",
            "sc_bu_finance_code"     : "hier_level_8_code",
            "sc_level_0_description" : "hier_level_0_description",
            "sc_level_1_description" : "hier_level_1_description",
            "sc_level_2_description" : "hier_level_2_description",
            "sc_level_3_description" : "hier_level_3_description",
            "sc_level_4_description" : "hier_level_4_description",
            "sc_level_5_description" : "hier_level_5_description",
            "sc_level_6_description" : "hier_level_6_description",
            "sc_mu_description"      : "hier_level_7_description",
            "sc_bu_description"      : "hier_level_8_description"
        }

        # List of renamed hierarchical columns
        columns = list(column_re_mappings.values())
        print(columns)

        # Rename columns and select distinct values
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process hierarchical levels and add descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "sc")

        # Define temporary path and save the processed data
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read the processed data from temporary location
        final_df_temp = spark.read.parquet(temp_path)

        # Generate descendant data for the hierarchy
        final_df = generate_descent_fn(final_df_temp, 8)

        # Write the descendant table to Delta
        descentant_table_delta_write(
            final_df, descendant_path, descendant_db, descendant_table,
            partition_columns=["dimension"], catalog_name=catalog_name,
            object_owner_spn=object_owner_spn, retry_count=0,
            overwriteSchema_flag="false", delta_overwrite_mode="full"
        )
        
        # Map hierarchical columns back to original names for output
        column_mappings = {
            "hier_level_0_code"         : "sc_level_0_code",
            "hier_level_1_code"         : "sc_level_1_code",
            "hier_level_2_code"         : "sc_level_2_code",
            "hier_level_3_code"         : "sc_level_3_code",
            "hier_level_4_code"         : "sc_level_4_code",
            "hier_level_5_code"         : "sc_level_5_code",
            "hier_level_6_code"         : "sc_level_6_code",
            "hier_level_7_code"         : "sc_mu_code",
            "hier_level_8_code"         : "sc_bu_finance_code",
            "hier_level_0_description"  : "sc_level_0_description",
            "hier_level_1_description"  : "sc_level_1_description",
            "hier_level_2_description"  : "sc_level_2_description",
            "hier_level_3_description"  : "sc_level_3_description",
            "hier_level_4_description"  : "sc_level_4_description",
            "hier_level_5_description"  : "sc_level_5_description",
            "hier_level_6_description"  : "sc_level_6_description",
            "hier_level_7_description"  : "sc_mu_description",
            "hier_level_8_description"  : "sc_bu_description"
        }

        # Generate additional hierarchical data with the dummy function
        write_df = dummy_function_call(final_df_temp, 8, ["hier_level_0_code", "hier_level_0_description"])

        # Apply reverse mappings to column names
        write_df = write_df.withColumnsRenamed(column_mappings)
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return the processed dataframes
        return final_df_temp, write_df, final_df


# COMMAND ----------

def process_product_category(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes Product data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    if data_feed == "master_data_product_category":
        # Define hierarchical levels with codes and descriptions
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-"),
            ("hier_level_3_code", "hier_level_3_description", "LV3-"),
            ("hier_level_4_code", "hier_level_4_description", "LV4-"),
            ("hier_level_5_code", "hier_level_5_description", "LV5-"),
            ("hier_level_6_code", "hier_level_6_description", "LV6-"),
        ]
        
        # Append additional hierarchical levels
        levels.append(("hier_level_7_code", "hier_level_7_description", "LV7-"))
        levels.append(("hier_level_8_code", "hier_level_8_description", "LV8-"))
        levels.append(("hier_level_9_code", "hier_level_9_description", "LV9-"))

        # Map original column names to hierarchical column names
        column_re_mappings = {
            "total_unilever_by_product_category_code"        : "hier_level_0_code",
            "legacy_division_code"                           : "hier_level_1_code",
            "division_code"                                  : "hier_level_2_code",
            "sub_division_2_code"                            : "hier_level_3_code",
            "category_code"                                  : "hier_level_4_code",
            "market_code"                                    : "hier_level_5_code",
            "sector_code"                                    : "hier_level_6_code",
            "sub_sector_code"                                : "hier_level_7_code",
            "segment_code"                                   : "hier_level_8_code",
            "product_form_code"                              : "hier_level_9_code",
            "total_unilever_by_product_category_description" : "hier_level_0_description",
            "legacy_division_description"                    : "hier_level_1_description",
            "division_description"                           : "hier_level_2_description",
            "sub_division_2_description"                     : "hier_level_3_description",
            "category_description"                           : "hier_level_4_description",
            "market_description"                             : "hier_level_5_description",
            "sector_description"                             : "hier_level_6_description",
            "sub_sector_description"                         : "hier_level_7_description",
            "segment_description"                            : "hier_level_8_description",
            "product_form_description"                       : "hier_level_9_description",
        }

        # Rename columns and select distinct values
        columns = list(column_re_mappings.values())
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process hierarchical levels with descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "pcat")
        # Define temporary path for saving data
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

        # Save the processed data in temporary storage
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read back the saved data
        final_df_temp = spark.read.parquet(temp_path)

        # Generate descendant data for the hierarchy
        final_df = generate_descent_fn(final_df_temp, 9)

        # Write the processed data to Delta table
        descentant_table_delta_write(
            final_df, descendant_path, descendant_db, descendant_table,
            partition_columns=["dimension"], catalog_name=catalog_name,
            object_owner_spn=object_owner_spn, retry_count=0,
            overwriteSchema_flag="false", delta_overwrite_mode="full"
        )

        # Reverse the column mappings for output
        column_mappings = {
            "hier_level_0_code"        : "total_unilever_by_product_category_code",
            "hier_level_1_code"        : "legacy_division_code",
            "hier_level_2_code"        : "division_code",
            "hier_level_3_code"        : "sub_division_2_code",
            "hier_level_4_code"        : "category_code",
            "hier_level_5_code"        : "market_code",
            "hier_level_6_code"        : "sector_code",
            "hier_level_7_code"        : "sub_sector_code",
            "hier_level_8_code"        : "segment_code",
            "hier_level_9_code"        : "product_form_code",
            "hier_level_0_description" : "total_unilever_by_product_category_description",
            "hier_level_1_description" : "legacy_division_description",
            "hier_level_2_description" : "division_description",
            "hier_level_3_description" : "sub_division_2_description",
            "hier_level_4_description" : "category_description",
            "hier_level_5_description" : "market_description",
            "hier_level_6_description" : "sector_description",
            "hier_level_7_description" : "sub_sector_description",
            "hier_level_8_description" : "segment_description",
            "hier_level_9_description" : "product_form_description",
        }

        # Generate additional hierarchical data with dummy function
        write_df = dummy_function_call(final_df_temp, 9, ["hier_level_0_code", "hier_level_0_description"])

        # Apply column mappings
        write_df = write_df.withColumnsRenamed(column_mappings)
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return both DataFrames
        return final_df_temp, write_df, final_df

# COMMAND ----------

def process_brand(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):
    """
    Processes brand data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    if data_feed == "master_data_brand":
        # Filter staging data to include only rows where 'corporate_brand_subscribe' contains 'finance'
        staging_df = staging_df.filter(lower(col("corporate_brand_subscribe")).contains("finance"))

        # Define hierarchical levels (3 levels in this case)
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-")
        ]

        # Map original column names to hierarchical column names
        column_re_mappings = {
            "total_by_finance_code"         : "hier_level_0_code",
            "corporate_parent_finance_code" : "hier_level_1_code",
            "corporate_brand_code"          : "hier_level_2_code",
            "total_by_brand"                : "hier_level_0_description",
            "corporate_parent_brand"        : "hier_level_1_description",
            "corporate_brand"               : "hier_level_2_description"
        }

        # Select the relevant columns after renaming
        columns = list(column_re_mappings.values())
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process the hierarchical levels with descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "brand")

        # Define temporary path for saving data
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

        # Write the processed data to temporary storage
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read the saved data back into a DataFrame
        final_df_temp = spark.read.parquet(temp_path)

        # Generate descendant data based on hierarchical levels
        final_df = generate_descent_fn(final_df_temp, 2)

        # Write the generated data to a Delta table
        descentant_table_delta_write(
            final_df, descendant_path, descendant_db, descendant_table,
            partition_columns=["dimension"], catalog_name=catalog_name,
            object_owner_spn=object_owner_spn, retry_count=0,
            overwriteSchema_flag="false", delta_overwrite_mode="full"
        )

        # Reverse the column mappings for the final output
        column_mappings = {
            "hier_level_0_code"        : "total_by_finance_code",
            "hier_level_1_code"        : "corporate_parent_finance_code",
            "hier_level_2_code"        : "corporate_brand_code",
            "hier_level_0_description" : "total_by_brand",
            "hier_level_1_description" : "corporate_parent_brand",
            "hier_level_2_description" : "corporate_brand",
        }

        # Generate additional hierarchical data with dummy function
        write_df = dummy_function_call(final_df_temp, 2, ["hier_level_0_code", "hier_level_0_description"])

        # Apply column mappings to the result
        write_df = write_df.withColumnsRenamed(column_mappings)
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return both DataFrames as a tuple
        return final_df_temp, write_df, final_df


# COMMAND ----------

def process_brand_position(staging_df, data_feed, descendant_db, descendant_table, descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag):

    """
    Processes brand Position data, filters based on finance subscription, applies hierarchical transformations,
    and writes results to a Delta table.

    This function filters the input DataFrame to include only rows where the brand position subscription 
    contains "finance". It then renames columns to match the hierarchy levels, processes these levels, 
    and writes the results to a temporary path. The function generates a descendant DataFrame and writes 
    it to a Delta table. Finally, it maps the hierarchy column names back to the original names and returns 
    the processed DataFrames.

    Returns:
    tuple: A tuple containing the final DataFrame, the write DataFrame, and the descendant DataFrame.
    """
    # Check if the data feed is for master data brand position
    if data_feed == "master_data_brand_position":

        # Filter the DataFrame to include only rows where brand_position_subscribe contains "finance"
        staging_df = staging_df.filter(lower(col("brand_position_subscribe")).contains("finance"))

        # Define the hierarchy levels and their descriptions
        levels = [
            ("hier_level_0_code", "hier_level_0_description", None),
            ("hier_level_1_code", "hier_level_1_description", "LV1-"),
            ("hier_level_2_code", "hier_level_2_description", "LV2-"),
            ("hier_level_3_code", "hier_level_3_description", "LV3-"),
            ("hier_level_4_code", "hier_level_4_description", "LV4-")
        ]
        
        # Map the original column names to the new hierarchy column names
        column_re_mappings = {
            "brand_position_level_0_code"        : "hier_level_0_code",
            "brand_position_level_1_code"        : "hier_level_1_code",
            "brand_position_level_2_code"        : "hier_level_2_code",
            "brand_position_level_3_code"        : "hier_level_3_code",
            "brand_position_default_code"        : "hier_level_4_code",
            "brand_position_level_0_description" : "hier_level_0_description",
            "brand_position_level_1_description" : "hier_level_1_description",
            "brand_position_level_2_description" : "hier_level_2_description",
            "brand_position_level_3_description" : "hier_level_3_description",
            "brand_position_description"         : "hier_level_4_description"
        }

        # Get the list of new column names
        columns = list(column_re_mappings.values())
        print(columns)

        # Rename the columns in the DataFrame and select the distinct rows
        renamed_df = staging_df.withColumnsRenamed(column_re_mappings).select(*columns).distinct()

        # Process the hierarchy levels with descriptions
        final_df_new = process_hierarchy_levels_with_description(renamed_df, levels, "brand_position")

        # Define the temporary path for storing the DataFrame
        temp_path = absolute_path + "data_engineering/bronze/temp/" + data_feed

        # Write the DataFrame to the temporary path in Parquet format
        final_df_new.write.mode("overwrite").parquet(temp_path)

        # Read the DataFrame from the temporary path
        final_df_temp = spark.read.parquet(temp_path)

        # Generate the descendant DataFrame
        final_df = generate_descent_fn(final_df_temp, 4)

        # Write the descendant DataFrame to the Delta table
        descentant_table_delta_write(final_df, descendant_path, descendant_db, descendant_table, partition_columns=["dimension"],
                                     catalog_name=catalog_name, object_owner_spn=object_owner_spn, retry_count=0, overwriteSchema_flag="false", delta_overwrite_mode="full")

        # Map the hierarchy column names back to the original column names
        column_mappings = {
            "hier_level_0_code"        : "brand_position_level_0_code",
            "hier_level_1_code"        : "brand_position_level_1_code",
            "hier_level_2_code"        : "brand_position_level_2_code",
            "hier_level_3_code"        : "brand_position_level_3_code",
            "hier_level_4_code"        : "brand_position_default_code",
            "hier_level_0_description" : "brand_position_level_0_description",
            "hier_level_1_description" : "brand_position_level_1_description",
            "hier_level_2_description" : "brand_position_level_2_description",
            "hier_level_3_description" : "brand_position_level_3_description",
            "hier_level_4_description" : "brand_position_description"
        }

        # Call a dummy function and rename the columns in the resulting DataFrame
        write_df = dummy_function_call(final_df_temp, 4, ["hier_level_0_code", "hier_level_0_description"])
        write_df = write_df.withColumnsRenamed(column_mappings)

        # Rename the columns in the final DataFrame
        final_df_temp = final_df_temp.withColumnsRenamed(column_mappings)

        if debug_flag =="1":
            renamed_df.display()

        # Return both DataFrames as a tuple
        return final_df_temp, write_df, final_df

# COMMAND ----------

def generate_element_pairs(bu_list, pcat_list, third_dim_list=None):
    
    """
    Generate parent-child pairs for BU, PCAT, and optionally a third dimension.

    This function takes in lists of Business Units (BU), Product Categories (PCAT), 
    and an optional third dimension. It generates pairs of parent-child relationships 
    for each dimension, reversing the input lists for processing. If a third dimension 
    is provided, it includes it in the pairs; otherwise, it generates pairs for BU and PCAT only.

    Parameters:
    bu_list (list): List of Business Units.
    pcat_list (list): List of Product Categories.
    third_dim_list (list, optional): List of elements for the third dimension. Default is None.

    Returns:
    list: A list of tuples containing parent-child pairs for the provided dimensions.

    Example:
    >>> bu_list = ['BU1', 'BU2', 'BU3']
    >>> pcat_list = ['PCAT1', 'PCAT2', 'PCAT3']
    >>> third_dim_list = ['DIM1', 'DIM2', 'DIM3']
    >>> generate_element_pairs(bu_list, pcat_list, third_dim_list)
    [('BU3,PCAT3,DIM3', 'BU2,PCAT2,DIM2'), ('BU2,PCAT2,DIM2', 'BU1,PCAT1,DIM1')]

    >>> generate_element_pairs(bu_list, pcat_list)
    [('BU3,PCAT3', 'BU2,PCAT2'), ('BU2,PCAT2', 'BU1,PCAT1')]
    """
    
    pairs = []

    # Reverse the input lists for processing
    bu_reversed = bu_list[::-1]
    pcat_reversed = pcat_list[::-1]
    
    if third_dim_list:
        third_dim_reversed = third_dim_list[::-1]
        # Determine the maximum length among the lists
        max_len = __builtins__.max(len(bu_reversed), len(pcat_reversed), len(third_dim_reversed))
    else:
        third_dim_reversed = []
        max_len = __builtins__.max(len(bu_reversed), len(pcat_reversed))

    for i in range(max_len - 1):
        # Get parent and child elements for BU
        bu_parent = bu_reversed[i] if i < len(bu_reversed) else bu_reversed[-1]
        bu_child = bu_reversed[i + 1] if i + 1 < len(bu_reversed) else bu_reversed[-1]

        # Get parent and child elements for PCAT
        pcat_parent = pcat_reversed[i] if i < len(pcat_reversed) else pcat_reversed[-1]
        pcat_child = pcat_reversed[i + 1] if i + 1 < len(pcat_reversed) else pcat_reversed[-1]
        
        if third_dim_list:
            # Get parent and child elements for the third dimension
            third_dim_parent = third_dim_reversed[i] if i < len(third_dim_reversed) else third_dim_reversed[-1]
            third_dim_child = third_dim_reversed[i + 1] if i + 1 < len(third_dim_reversed) else third_dim_reversed[-1]
            # Add the pair including the third dimension
            pairs.append((f"{bu_parent},{pcat_parent},{third_dim_parent}", f"{bu_child},{pcat_child},{third_dim_child}"))
        else:
            # Add the pair without the third dimension
            pairs.append((f"{bu_parent},{pcat_parent}", f"{bu_child},{pcat_child}"))

    return pairs

# COMMAND ----------

def group_and_transform(df, group_by_columns, rename_columns, agg_expressions=None):
    """
    Group a DataFrame, apply aggregations, and rename columns.
    """
    
    # Group the DataFrame and apply aggregation expressions
    grouped_df = df.groupby(group_by_columns).agg(*agg_expressions)
    
    # Rename columns based on the provided mapping
    for new_col, old_col in rename_columns.items():
        grouped_df = grouped_df.withColumnRenamed(old_col, new_col)
    
    return grouped_df

# COMMAND ----------

def process_join_and_aggregate(df, descendant_bu_df, descendant_pcat_df,drop_columns,selected_columns,agg_columns, descendant_third_dim_df=None, third_dim_exists=False, decimal_type=None):
    """
    Processes the join and aggregation logic dynamically based on the existence of the third dimension.

    This function performs joins between the main DataFrame and descendant DataFrames for Business Units (BU) and Product Categories (PCAT). 
    If a third dimension exists, it also joins with the third dimension DataFrame. The function then defines and applies aggregation expressions 
    based on the presence of the third dimension

    """
    
    # Perform joins with BU and PCAT DataFrames
    join_df = (
        df
        .join(
            descendant_bu_df,
            (lower(descendant_bu_df.bu_child_code) == lower(df.business_unit)) |
            (substring(lower(descendant_bu_df.bu_child_code), 5, length(col("bu_child_code"))) == lower(df.business_unit)),
            "left"
        )
        .join(
            descendant_pcat_df,
            (lower(descendant_pcat_df.pcat_child_code) == lower(df.product_category)) |
            (substring(lower(descendant_pcat_df.pcat_child_code), 5, length(col("pcat_child_code"))) == lower(df.product_category)),
            "left"
        )
    )

    join_df.display()

    # If third_dim exists, join with third_dim DataFrame
    if third_dim_exists and descendant_third_dim_df:
        join_df = join_df.join(
            descendant_third_dim_df,
            (lower(descendant_third_dim_df.third_dim_child_code) == lower(df.third_dim)) |
            (substring(lower(descendant_third_dim_df.third_dim_child_code), 5, length(col("third_dim_child_code"))) == lower(df.third_dim)),
            "left"
        )

    # Define aggregation expressions for join
    agg_expressions_join = [(col(colName).cast(decimal_type)).alias(f"{colName}") for colName in agg_columns]

    # Define aggregation expressions with a conditional check for third_dim existence
    if third_dim_exists:
        agg_expressions_regex = [
            when(
                (col("bu_child_code").rlike("^LV\\d+-")) & 
                (col("pcat_child_code").rlike("^LV\\d+-")) & 
                (col("third_dim_child_code").rlike("^LV\\d+-")),
                lit(0).cast(decimal_type)
            ).otherwise(col(colName).cast(decimal_type))
            .alias(f"{colName}")
            for colName in agg_columns
        ]
    else:
        agg_expressions_regex = [
            when(
                (col("bu_child_code").rlike("^LV\\d+-")) & 
                (col("pcat_child_code").rlike("^LV\\d+-")),
                lit(0).cast(decimal_type)
            ).otherwise(col(colName).cast(decimal_type))
            .alias(f"{colName}")
            for colName in agg_columns
        ]

    join_df = join_df.select(*selected_columns, *agg_expressions_join)

    # Apply the aggregation expressions for regex
    join_df = join_df.select(*selected_columns, *agg_expressions_regex)

    return join_df

# COMMAND ----------

def process_hierarchy(join_df, descendant_bu_df, descendant_pcat_df, descendant_third_dim_df=None):
    """
    Calculate the difference between child and parent aggregations for specified columns.

    This function processes the hierarchy levels for Business Units (BU), Product Categories (PCAT), 
    and optionally a third dimension. It generates parent-child pairs and fetches the maximum level 
    numbers for each dimension.

    Parameters:
    join_df (DataFrame): The main DataFrame to be processed.
    descendant_bu_df (DataFrame): DataFrame containing descendant BU codes.
    descendant_pcat_df (DataFrame): DataFrame containing descendant PCAT codes.
    descendant_third_dim_df (DataFrame, optional): DataFrame containing descendant codes for the third dimension. Default is None.

    Returns:
    dict: A dictionary containing hierarchies, dimension pairs, and maximum level numbers for each dimension.
    """

    # BU Hierarchy
    bu_hier_list = join_df.filter(col("bu_level_num").isNotNull()) \
        .withColumn("bu_level_num", col("bu_level_num").cast("int")) \
        .select(col("bu_level_num")).distinct().orderBy(col("bu_level_num").asc()).collect()

    bu_hierarchy = [x["bu_level_num"] for x in bu_hier_list]
    
    # PCAT Hierarchy
    pcat_hier_list = join_df.filter(col("pcat_level_num").isNotNull()) \
        .withColumn("pcat_level_num", col("pcat_level_num").cast("int")) \
        .select(col("pcat_level_num")).distinct().orderBy(col("pcat_level_num").asc()).collect()

    pcat_hierarchy = [x["pcat_level_num"] for x in pcat_hier_list]

    # Third Dimension Hierarchy (Optional)
    if descendant_third_dim_df and 'third_dim_level_num' in join_df.columns:
        third_dim_hier_list = join_df.filter(col("third_dim_level_num").isNotNull()) \
            .withColumn("third_dim_level_num", col("third_dim_level_num").cast("int")) \
            .select(col("third_dim_level_num")).distinct().orderBy(col("third_dim_level_num").asc()).collect()

        third_dim_hierarchy = [x["third_dim_level_num"] for x in third_dim_hier_list]
    else:
        third_dim_hierarchy = []

    # Generate pairs based on the available dimensions
    dim_pairs = generate_element_pairs(bu_hierarchy, pcat_hierarchy, third_dim_hierarchy if third_dim_hierarchy else None)

    # Fetch descendant dummy numbers for each dimension
    bu_descendant_dummy_number   = descendant_bu_df.select(max(col("bu_level_num"))).first()[0]
    pcat_descendant_dummy_number = descendant_pcat_df.select(max(col("pcat_level_num"))).first()[0]

    if third_dim_hierarchy:
        third_dim_descendant_dummy_number = descendant_third_dim_df.select(max(col("third_dim_level_num"))).first()[0]
    else:
        third_dim_descendant_dummy_number = None

    return {
        "bu_hierarchy"        : bu_hierarchy,
        "pcat_hierarchy"      : pcat_hierarchy,
        "third_dim_hierarchy" : third_dim_hierarchy,
        "dim_pairs"           : dim_pairs,
        "bu_descendant_dummy_number"    : bu_descendant_dummy_number,
        "pcat_descendant_dummy_number"  : pcat_descendant_dummy_number,
        "third_dim_descendant_dummy_number": third_dim_descendant_dummy_number
    }

# COMMAND ----------

def calculate_parent_child_differences(join_df, dim_pairs, agg_columns, 
                          bu_descendant_dummy_number, pcat_descendant_dummy_number, 
                          third_dim_descendant_dummy_number,column_list,third_dim_exists=False):
    """
    Calculate the difference between child and parent aggregations for specified columns.

    This function processes the join DataFrame to calculate differences between child and parent 
    aggregations for Business Units (BU), Product Categories (PCAT), and optionally a third dimension. 
    It generates dummy records for the differences and returns the final accumulated DataFrame.

    Parameters:
    join_df (DataFrame): The main DataFrame to be processed.
    dim_pairs (list): List of dimension pairs for BU, PCAT, and optionally a third dimension.
    agg_columns (list): List of columns to be aggregated.
    bu_descendant_dummy_number (int): Dummy number for BU descendants.
    pcat_descendant_dummy_number (int): Dummy number for PCAT descendants.
    third_dim_descendant_dummy_number (int): Dummy number for third dimension descendants.
    third_dim_exists (bool, optional): Flag indicating if the third dimension exists. Default is False.

    Returns:
    DataFrame: The final accumulated DataFrame with calculated differences and dummy records.
    """
    # Prepare the difference expressions for each column
    difference_expressions = [
        (col(f"parent_{colName}") - col(f"child_{colName}")).alias(f"{colName}_difference") 
        for colName in agg_columns
    ]

    # Aggregate expressions for child and parent
    agg_expressions_child  = [sum(col(colName)).alias(f"child_{colName}") for colName in agg_columns]
    agg_expressions_parent = [sum(col(colName)).alias(f"parent_{colName}") for colName in agg_columns]

    # Loop through the BU-PCAT pairs
    for i, pair in enumerate(dim_pairs):
        first_pair, second_pair = pair

        if third_dim_exists:
            bu_child, pcat_child, third_dim_child = first_pair.split(',')
            bu_parent, pcat_parent, third_dim_parent = second_pair.split(',')
        else:
            third_dim_parent  = None
            third_dim_child   = None
            bu_child, pcat_child    = first_pair.split(',')
            bu_parent, pcat_parent  = second_pair.split(',')

        # Initialize lowest levels for the first iteration
        if i == 0:
            lowest_bu_level   = bu_child
            lowest_pcat_level = pcat_child
            if third_dim_exists:
                lowest_third_dim_level = third_dim_child

        print(f"bu_parent   : {bu_parent:<15}   pcat_parent   : {pcat_parent:<15}   third_dim_parent  : {third_dim_parent}")
        print(f"bu_child    : {bu_child:<15}   pcat_child    : {pcat_child:<15}   third_dim_child   : {third_dim_child}\n")

        # Filter data based on BU, PCAT, and 3rd dimension levels (if exists)
        child_df  = join_df.filter(col("bu_level_num") == bu_child).filter(col("pcat_level_num") == pcat_child)
        parent_df = join_df.filter(col("bu_level_num") == bu_parent).filter(col("pcat_level_num") == pcat_parent)

        # If third_dim exists, include third_dim_level_num in filtering for both child_df and parent_df
        if third_dim_exists:
            child_df  = child_df.filter(col("third_dim_level_num")   == third_dim_child)
            parent_df = parent_df.filter(col("third_dim_level_num") == third_dim_parent)

        # Define group_by_columns
        group_by_columns = [
            'bu_child_code', 'bu_level_num', 
            'pcat_child_code', 'pcat_level_num'
        ]

        group_by_columns.extend(column_list)

        # Add third_dim columns if they exist
        if third_dim_exists:
            group_by_columns.extend(['third_dim_child_code', 'third_dim_level_num'])

        # Perform aggregation on the parent data
        parent_sum_df = group_and_transform(parent_df, group_by_columns, {}, agg_expressions_parent)

        # Extract levels for comparison
        bu_level_parent   = parent_df.select("bu_level_num").distinct().first()[0]
        bu_level_child    = child_df.select("bu_level_num").distinct().first()[0]
        pcat_level_parent = parent_df.select("pcat_level_num").distinct().first()[0]
        pcat_level_child  = child_df.select("pcat_level_num").distinct().first()[0]

        # Third dimension level extraction if exists
        if third_dim_exists:
            third_dim_parent  = parent_df.select("third_dim_level_num").distinct().first()[0]
            third_dim_child   = child_df.select("third_dim_level_num").distinct().first()[0]

        # Conditional logic with third_dim handling
        if bu_level_parent == bu_level_child and pcat_level_parent != pcat_level_child:
            print("1st BU level match and PCAT levels not match")
            group_by_columns = ['bu_child_code', 'bu_level_num', 'pcat_parent_code', 'pcat_level_num']
            group_by_columns.extend(column_list)
            rename_columns   = {'bu_parent_code': 'bu_child_code'}
            if third_dim_exists:
                if third_dim_parent != third_dim_child:
                    group_by_columns += ['third_dim_parent_code', 'third_dim_level_num']
                else:
                    group_by_columns += ['third_dim_child_code', 'third_dim_level_num']
                    rename_columns['third_dim_parent_code'] = 'third_dim_child_code'

        elif bu_level_parent != bu_level_child and pcat_level_parent == pcat_level_child:
            print("2nd BU level not match and PCAT levels match")
            group_by_columns = ['bu_parent_code', 'bu_level_num', 'pcat_child_code', 'pcat_level_num']
            group_by_columns.extend(column_list)
            rename_columns = {'pcat_parent_code': 'pcat_child_code'}
            if third_dim_exists:
                if third_dim_parent != third_dim_child:
                    group_by_columns += ['third_dim_parent_code', 'third_dim_level_num']
                else:
                    group_by_columns += ['third_dim_child_code', 'third_dim_level_num']
                    rename_columns['third_dim_parent_code'] = 'third_dim_child_code'

        elif bu_level_parent == bu_level_child and pcat_level_parent == pcat_level_child:
            print("3rd BU level match and PCAT levels not match")
            group_by_columns = ['bu_child_code', 'bu_level_num', 'pcat_child_code', 'pcat_level_num']
            group_by_columns.extend(column_list)
            rename_columns = {'bu_parent_code': 'bu_child_code', 'pcat_parent_code': 'pcat_child_code'}
            if third_dim_exists:
                if third_dim_parent == third_dim_child:
                    group_by_columns += ['third_dim_child_code', 'third_dim_level_num']
                    rename_columns['third_dim_parent_code'] = 'third_dim_child_code'
                else:
                    group_by_columns += ['third_dim_parent_code', 'third_dim_level_num']

        elif bu_level_parent != bu_level_child and pcat_level_parent != pcat_level_child:
            print("4th BU level not match and PCAT levels not match")
            group_by_columns = ['bu_parent_code', 'bu_level_num', 'pcat_parent_code', 'pcat_level_num']
            group_by_columns.extend(column_list)
            rename_columns = {}
            if third_dim_exists:
                if third_dim_parent == third_dim_child:
                    group_by_columns += ['third_dim_child_code', 'third_dim_level_num']
                    rename_columns['third_dim_parent_code'] = 'third_dim_child_code'
                else:
                    group_by_columns += ['third_dim_parent_code', 'third_dim_level_num']

        # Perform aggregation on the child data
        child_sum_df = group_and_transform(child_df, group_by_columns, rename_columns, agg_expressions_child)


        # Define the join condition based on third_dim_exists
        join_condition = (
            (lower(col("bu_parent_code"))   == lower(col("bu_child_code"))) &
            (lower(col("pcat_parent_code")) == lower(col("pcat_child_code")))
                        )

        for column in column_list :
            join_condition = join_condition & (
            lower(child_sum_df[f"{column}"]) == lower(parent_sum_df[f"{column}"]))

        # If third_dim exists, add its condition to the join
        if third_dim_exists:
            join_condition &= (lower(col("third_dim_parent_code")) == lower(col("third_dim_child_code")))

        # Define the columns to select based on third_dim_exists
        select_columns = [
            parent_sum_df.bu_child_code,
            parent_sum_df.bu_level_num,
            parent_sum_df.pcat_child_code,
            parent_sum_df.pcat_level_num
        ]

        for column in column_list :
            select_columns.append(parent_sum_df[column]) 

        # Add third_dim columns if third_dim_exists
        if third_dim_exists:
            select_columns += [
                parent_sum_df.third_dim_child_code,
                parent_sum_df.third_dim_level_num
            ]

        print(select_columns)
        
        # Perform the join and select the necessary columns
        comparison_df = parent_sum_df.join(
            child_sum_df.drop("pcat_level_num", "bu_level_num", "third_dim_level_num"),
            join_condition,
            how="left"
        ).na.fill(0).select(*select_columns, *difference_expressions)
        

        # Difference calculation and dummy record generation
        difference_columns  = [col_name for col_name in comparison_df.columns if "_difference" in col_name]
        filter_expr         = " OR ".join([f"`{col}` != 0.0" for col in difference_columns])

        select_columns = (difference_columns + ["bu_child_code", "pcat_child_code", "bu_level_num", "pcat_level_num"])

        if third_dim_exists:
            select_columns += ["third_dim_child_code", "third_dim_level_num"]
        
        select_columns.extend(column_list)

        difference_df = comparison_df.filter(expr(filter_expr)).select(select_columns)

        # Generate dummy records
        dummy_records = difference_df.withColumn(
            "business_unit",
            concat(lit("DL"), lit(bu_descendant_dummy_number), lit("-"), col("bu_child_code")),
        ).withColumn(
            "product_category",
            concat(
                lit("DL"),
                lit(pcat_descendant_dummy_number),
                lit("-"),
                col("pcat_child_code"),
            ),
        )

        if third_dim_exists:
            dummy_records = dummy_records.withColumn(
                "third_dim",
                concat(
                    lit("DL"),
                    lit(third_dim_descendant_dummy_number),
                    lit("-"),
                    col("third_dim_child_code"),
                ),
            ).drop("third_dim_child_code")

        dummy_records = dummy_records.drop(
            "pcat_parent_code", "bu_parent_code", "bu_child_code", "pcat_child_code"
        ).withColumn(
            "bu_level_num", lit(lowest_bu_level)
        ).withColumn(
            "pcat_level_num", lit(lowest_pcat_level)
        )

        if third_dim_exists:
            dummy_records = dummy_records.withColumn(
                "third_dim_level_num", lit(lowest_third_dim_level)
            )

        dummy_records = dummy_records.select(
            *[col(c).alias(c.replace("_difference", "")) for c in dummy_records.columns]
        )

        # Initialize final accumulated dataframe for the first iteration
        if i == 0:
            final_accumulated_df = spark.createDataFrame([], dummy_records.schema)

        # Union the dummy records to the final accumulated dataframe
        final_accumulated_df = final_accumulated_df.unionByName(dummy_records)

    # Return the final accumulated dataframe
    return final_accumulated_df
