# Databricks notebook source
from pyspark.sql.functions      import *
from pyspark.sql                import DataFrame
from pyspark.sql.functions      import  sum as _sum
from functools                  import reduce as reduce_import
from pyspark.storagelevel       import StorageLevel
from decimal import Decimal
from pyspark.sql.types          import DecimalType

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# Clear existing widgets
dbutils.widgets.removeAll()

# Define input widgets
dbutils.widgets.text("data_feed", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("external_location", "")
dbutils.widgets.text("debug_flag", "")
dbutils.widgets.text("object_owner_spn", "")
dbutils.widgets.text("map_hierarchy_table_name", "")           
dbutils.widgets.text("fact_gold_table_name", "")       
dbutils.widgets.text("fact_view_name", "")                   
dbutils.widgets.text("fact_map_table_name", "")        

# Fetch values from widgets
data_feed               = dbutils.widgets.get("data_feed")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
external_location       = dbutils.widgets.get("external_location")
debug_flag              = dbutils.widgets.get("debug_flag")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
map_hierarchy_table_name= dbutils.widgets.get("map_hierarchy_table_name")
fact_gold_table_name    = dbutils.widgets.get("fact_gold_table_name")
fact_view_name          = dbutils.widgets.get("fact_view_name")
fact_map_table_name     = dbutils.widgets.get("fact_map_table_name")

# Compute the absolute path for the fact map table
absolute_path           = return_absolute_path(external_location)
fact_map_table_path     = f"{absolute_path}data_engineering/gold/finance/{fact_map_table_name}"

# Static job identifiers 
job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
log_id = run_id  

# Log configuration parameters 
print(f"absolute_path            : {absolute_path}")
print(f"data_feed                : {data_feed}")
print(f"uc_catalog_name          : {uc_catalog_name}")
print(f"external_location        : {external_location}")
print(f"object_owner_spn         : {object_owner_spn}")
print(f"debug_flag               : {debug_flag}")
print(f"map_hierarchy_table_name : {map_hierarchy_table_name}")
print(f"fact_gold_table_name     : {fact_gold_table_name}")
print(f"fact_view_name           : {fact_view_name}")
print(f"fact_map_table_name      : {fact_map_table_name}")
print(f"fact_map_table_path      : {fact_map_table_path}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Map Hierarchy VIEW

# COMMAND ----------

# DBTITLE 1,precise multiplication 5 values
from decimal import Decimal

# Define the Python function
def precise_multiplication(val1, val2, val3, val4, val5):
    if None in (val1, val2, val3, val4):
        return Decimal(val5) if val5 is not None else None
    try:
        return Decimal(val1) * Decimal(val2) * Decimal(val3) * Decimal(val4) * Decimal(val5)
    except:
        return Decimal(val5) if val5 is not None else None

# Register it as a UDF
precise_udf = udf(precise_multiplication, DecimalType(36, 16))

# COMMAND ----------

# DBTITLE 1,precise multiplication 4 values
from decimal import Decimal

# Define the Python function
def precise_multiplication_4(val1, val2, val3, val4):
    if None in (val1, val2, val3):
        return Decimal(val4) if val4 is not None else None
    try:
        return Decimal(val1) * Decimal(val2) * Decimal(val3) * Decimal(val4)
    except:
        return Decimal(val4) if val4 is not None else None

# Register it as a UDF
precise_udf_4 = udf(precise_multiplication_4, DecimalType(36, 16))

# COMMAND ----------

# DBTITLE 1,precise multiplication 3 values
from decimal import Decimal

# Define the Python function
def precise_multiplication_3(val1, val2, val3):
    if None in (val1, val2):
        return Decimal(val3) if val3 is not None else None
    try:
        return Decimal(val1) * Decimal(val2) * Decimal(val3)
    except:
        return Decimal(val3) if val3 is not None else None

# Register it as a UDF
precise_udf_3 = udf(precise_multiplication_3, DecimalType(36, 16))

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_actuals":
        measure_df        = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df = measure_df.filter(col("measure_type") == "PnL Direct Measures")
        measure_list      = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str       = ",".join(map(str, measure_list))

        df1 = spark.sql(f"""
                            SELECT * 
                            FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                            WHERE measure_sk IN ({measure_str})
                        """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_pnl_data_actuals where  measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))         
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100)
        
        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS bu_sk,
                CAST(PC.DstCode AS INT) AS product_sk,
                CAST(f.month_sk AS INT) AS month_sk,
                CAST(CDO.DstCode AS INT) AS cont_discont_ops_sk,
                CAST(f.currency_sk AS INT) AS currency_sk,
                CAST(f.version_sk AS INT) AS version_sk,
                CAST(f.flow_sk AS INT) AS flow_sk,
                CAST(f.measure_sk AS INT) AS measure_sk,
                CAST(COM.DstCode AS INT) AS company_sk,
                'unk' AS cell,
                BU.BUFactor,
                COM.COMFactor,
                PC.PCFactor,
                CDO.CDOFactor,
                f.value
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu','sc')
                WHERE BU.is_active IS TRUE
            ) AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN COM.company_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN COM.company_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS COMFactor
                FROM {uc_catalog_name}.gold_master_data.company COM 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON COM.company_sk = MAP.destination_code_sk AND MAP.Dimension = 'company'
                WHERE COM.is_active IS TRUE
            ) AS COM ON COM.Code = f.company_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) AS PC ON PC.Code = f.product_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS CDOFactor
                FROM {uc_catalog_name}.gold_master_data.cont_disc_ops CDO 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON CDO.cont_disc_ops_sk = MAP.destination_code_sk AND MAP.Dimension = 'cdo'
                WHERE CDO.is_active IS TRUE
            ) AS CDO ON CDO.Code = f.cont_disc_ops_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
            """).withColumnRenamed("cont_discont_ops_sk", "cont_disc_ops_sk")

        view_df = view_df.withColumn("value", precise_udf("CDOFactor", "PCFactor", "BUFactor", "COMFactor", "value").cast(DecimalType(36, 16)))\
                         .drop("CDOFactor", "PCFactor", "BUFactor", "COMFactor")

        final_view_df = view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk","currency_sk", "version_sk", "flow_sk", "measure_sk", "company_sk", "cell").agg(sum("Value").alias("value"))\
                                .withColumn("log_id", lit(log_id).cast(LongType()))\
                                .withColumn("created_date", lit(current_timestamp()))

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.product_sk * 100000 + f.bu_sk AS INT) AS `Cell SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.flow_sk AS INT) AS `Flow SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CONCAT(bu.mu_hier_level_5_description, ' ', prod.`Category Cell`) AS `Cell`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            INNER JOIN {uc_catalog_name}.gold_master_data.business_unit bu ON f.bu_sk = bu.bu_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.vw_product_extended prod ON prod.`Product SK` = f.product_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m 
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
            WHERE f.bu_sk != -1 AND f.product_sk != -1 """)

        if debug_flag == "1":
            print('measure_list     :', measure_list)
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_forecast":
        measure_df        = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df = measure_df.filter(col("measure_type") == "PnL Direct Measures")
        measure_list      = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str       = ",".join(map(str, measure_list))

        df1 = spark.sql(f"""
                            SELECT * 
                            FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name} 
                            WHERE measure_sk IN ({measure_str})
                        """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_pnl_data_forecast where  measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))        
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100)
        
        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT)AS bu_sk,
                CAST(PC.DstCode AS INT)AS product_sk,
                CAST(f.month_sk AS INT)AS month_sk,
                CAST(CDO.DstCode AS INT)AS cont_disc_ops_sk,
                CAST(f.currency_sk AS INT)AS currency_sk,
                CAST(f.version_sk AS INT)AS version_sk,
                CAST(f.forecast_level_sk AS INT)AS forecast_level_sk,
                CAST(f.measure_sk AS INT)AS measure_sk,
                CAST(COM.DstCode AS INT)AS company_sk,
                'unk'AS cell,
                BU.BUFactor,
                COM.COMFactor,
                PC.PCFactor,
                CDO.CDOFactor,
                f.value
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.destination_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Factor IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} Map 
                    ON BU.bu_sk = Map.destination_code_sk AND Map.Dimension IN ('mu','sc')
                WHERE BU.is_active IS TRUE
            )AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN COM.company_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.destination_code_sk IS NULL THEN COM.company_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Factor IS NULL THEN 1 ELSE Factor END AS COMFactor
                FROM {uc_catalog_name}.gold_master_data.company COM 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} Map 
                    ON COM.company_sk = Map.destination_code_sk AND Map.Dimension = 'company'
                WHERE COM.is_active IS TRUE
            )AS COM ON COM.Code = f.company_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.destination_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Factor IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} Map 
                    ON PC.product_sk = Map.destination_code_sk AND Map.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            )AS PC ON PC.Code = f.product_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.destination_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Factor IS NULL THEN 1 ELSE Factor END AS CDOFactor
                FROM {uc_catalog_name}.gold_master_data.cont_disc_ops CDO 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} Map 
                    ON CDO.cont_disc_ops_sk = Map.destination_code_sk AND Map.Dimension = 'cdo'
                WHERE CDO.is_active IS TRUE
            )AS CDO ON CDO.Code = f.cont_disc_ops_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
        """).withColumnRenamed("cont_discont_ops_sk", "cont_disc_ops_sk")

        view_df = view_df.withColumn("value",precise_udf("CDOFactor", "PCFactor", "BUFactor", "COMFactor", "value").cast(DecimalType(36, 16)))\
                         .drop("CDOFactor", "PCFactor", "BUFactor", "COMFactor")

        final_view_df = view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "forecast_level_sk", "measure_sk", "company_sk", "cell").agg(sum("value").alias("value"))\
                               .withColumn("log_id", lit(log_id).cast(LongType()))\
                               .withColumn("created_date", lit(current_timestamp()))

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.forecast_level_sk AS INT) AS `Forecast Level SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m 
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print('measure_list     :', measure_list)
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_brand":

        # Load and filter measures
        measure_df        = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df = measure_df.filter(col("measure_type") == "PnL Direct Measures")
        measure_list      = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str       = ",".join(map(str, measure_list))

        # Read fact data
        df = spark.sql(f"""
                            SELECT * 
                            FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                            WHERE measure_sk IN ({measure_str})
                        """).repartition(100)

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        # Join with BU, PC, and Brand hierarchies
        view_df = spark.sql(f"""
            SELECT 
                BU.DSTCode AS bu_sk,
                PC.DstCode AS product_sk,
                brand.DstCode AS brand_sk,
                fact.flow_sk,
                fact.cont_disc_ops_sk,
                fact.measure_sk,
                fact.month_sk,
                fact.currency_sk,
                fact.version_sk,
                BU.BUFactor,
                PC.PCFactor,
                brand.BRANDFactor,
                fact.value
            FROM {fact_gold_table_name}_temp_view AS fact
            INNER JOIN (
                SELECT 
                    CASE WHEN map.source_code_sk IS NULL THEN bu.bu_sk ELSE map.source_code_sk END AS Code,
                    CASE WHEN map.source_code_sk IS NULL THEN bu.bu_sk ELSE map.destination_code_sk END AS DSTCode,
                    CASE WHEN map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit bu
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} map 
                    ON bu.bu_sk = map.destination_code_sk
                    AND map.Dimension IN ('mu', 'sc')
                WHERE bu.is_active = TRUE
            ) AS BU ON BU.Code = fact.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN map.source_code_sk IS NULL THEN pc.product_sk ELSE map.source_code_sk END AS Code,
                    CASE WHEN map.source_code_sk IS NULL THEN pc.product_sk ELSE map.destination_code_sk END AS DstCode,
                    CASE WHEN map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product pc
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} map 
                    ON pc.product_sk = map.destination_code_sk
                    AND map.Dimension = 'pcat'
                WHERE pc.is_active = TRUE
            ) AS PC ON PC.Code = fact.product_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN map.source_code_sk IS NULL THEN brand.brand_sk ELSE map.source_code_sk END AS Code,
                    CASE WHEN map.source_code_sk IS NULL THEN brand.brand_sk ELSE map.destination_code_sk END AS DstCode,
                    CASE WHEN map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BRANDFactor
                FROM {uc_catalog_name}.gold_master_data.brand brand
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} map 
                    ON brand.brand_sk = map.destination_code_sk
                    AND map.Dimension = 'brand'
                WHERE brand.is_active = TRUE
            ) AS brand ON brand.Code = fact.brand_sk
        """)

        # Apply precision multiplication and cleanup
        view_df = view_df.withColumn("value", precise_udf_4("BUFactor", "PCFactor", "BRANDFactor", "value").cast(DecimalType(36, 16)))\
                         .drop("BRANDFactor", "PCFactor", "BUFactor")

        # Aggregate and write to delta table
        final_view_df = view_df.groupBy("bu_sk", "product_sk", "brand_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "flow_sk", "measure_sk" ).agg(sum("value").alias("value"))\
                                .withColumn("log_id", lit(log_id).cast(LongType()))\
                                .withColumn("created_date", lit(current_timestamp()))\

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        # Create or replace view
        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.brand_sk AS INT) AS `Brand SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.flow_sk AS INT) AS `Flow SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            WHERE f.bu_sk != -1 AND f.product_sk != -1 AND f.brand_sk != -1
        """)

        if debug_flag == "1":
            print("measure_list     :", measure_list)
            print(f"{fact_gold_table_name}_temp_view")

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:

    if data_feed == "finance_fact_bex_brand_position":

        measure_df        = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df = measure_df.filter(col("measure_type") == "PnL Direct Measures")
        measure_list      = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str       = ",".join(map(str, measure_list))

        df = spark.sql(f"""
                            SELECT *
                            FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                            WHERE measure_sk IN ({measure_str})
                        """).repartition(100)

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT
                BU.DSTCode AS bu_sk,
                PC.DstCode AS product_sk,
                brand_p.DstCode AS brand_position_sk,
                Fact.flow_sk,
                Fact.cont_disc_ops_sk,
                Fact.measure_sk,
                Fact.month_sk,
                Fact.currency_sk,
                Fact.version_sk,
                BU.BUFactor,
                PC.PCFactor,
                brand_p.BRAND_P_Factor,
                Fact.value
            FROM {fact_gold_table_name}_temp_view AS Fact
            INNER JOIN (
                SELECT
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu','sc')
                WHERE BU.is_active = true
            ) AS BU ON BU.Code = Fact.bu_sk
            INNER JOIN (
                SELECT
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active = true
            ) AS PC ON PC.Code = Fact.product_sk
            INNER JOIN (
                SELECT
                    CASE WHEN Map.source_code_sk IS NULL THEN brand_p.brand_position_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN brand_p.brand_position_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BRAND_P_Factor
                FROM {uc_catalog_name}.gold_master_data.brand_position brand_p
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON brand_p.brand_position_sk = MAP.destination_code_sk AND MAP.Dimension = 'brand_position'
                WHERE brand_p.is_active = true
            ) AS brand_p ON brand_p.Code = Fact.brand_position_sk
        """)

        view_df = view_df.withColumn("value",precise_udf_4("BUFactor", "PCFactor", "BRAND_P_Factor", "value").cast(DecimalType(36, 16)))\
                         .drop("BUFactor", "PCFactor", "BRAND_P_Factor")

        final_view_df = view_df.groupBy("bu_sk", "product_sk", "brand_position_sk", "month_sk", "cont_disc_ops_sk", "version_sk", "currency_sk", "flow_sk", "measure_sk")\
                                .agg(sum("value").alias("value"))\
                                .withColumn("log_id", lit(log_id).cast(LongType()))\
                                .withColumn("created_date", lit(current_timestamp()))

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                f.bu_sk AS `BU SK`,
                f.product_sk AS `Product SK`,
                f.brand_position_sk AS `Brand Position SK`,
                f.month_sk AS `Month SK`,
                f.cont_disc_ops_sk AS `Cont Discont Ops SK`,
                f.currency_sk AS `Currency SK`,
                f.version_sk AS `Version SK`,
                f.flow_sk AS `Flow SK`,
                f.measure_sk AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CASE
                    WHEN p.division_code = 'CF1159' THEN bp.brand_position_level_2_code
                    ELSE bp.brand_position_finance_code
                END AS `Brand Position Code`,
                CASE
                    WHEN p.division_code = 'CF1159' THEN bp.brand_position_level_2_description
                    ELSE bp.brand_position_description
                END AS `Brand Position Description`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            LEFT JOIN {uc_catalog_name}.gold_master_data.brand_position bp
                ON f.brand_position_sk = bp.brand_position_sk
            LEFT JOIN {uc_catalog_name}.gold_master_data.product p
                ON f.product_sk = p.product_sk
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print('measure_list     :', measure_list)
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:

    if data_feed == "finance_fact_bex_gmva_forecast":

        measure_df        = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df = measure_df.filter(col("measure_type") == "GMVA Direct Measures")
        measure_list      = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str       = ",".join(map(str, measure_list))

        df1 = spark.sql(f"""
                            SELECT * FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                            WHERE measure_sk IN ({measure_str})
                        """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_pnl_data_forecast where  version_sk <> 200 and measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))         
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100)        

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS `bu_sk`,
                CAST(PC.DstCode AS INT) AS `product_sk`,
                CAST(f.month_sk AS INT) AS `month_sk`,
                CAST(f.cont_disc_ops_sk AS INT) AS `cont_disc_ops_sk`,
                CAST(f.currency_sk AS INT) AS `currency_sk`,
                CAST(f.version_sk AS INT) AS `version_sk`,
                CAST(f.forecast_level_sk AS INT) AS `forecast_level_sk`,
                CAST(f.measure_sk AS INT) AS `measure_sk`,
                CAST(f.company_sk AS INT) AS `company_sk`,
                'unk' AS cell,
                BU.BUFactor,
                PC.PCFactor,
                f.value,
                f.created_date AS `created_date`
            FROM {fact_gold_table_name}_temp_view f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu','sc')
                WHERE BU.is_active IS TRUE
            ) BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) PC ON PC.Code = f.product_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'GMVA Direct Measures'
        """)

        view_df = view_df.withColumn("value", precise_udf_3("BUFactor", "PCFactor", "value").cast(DecimalType(36, 16)))\
                         .drop("PCFactor", "BUFactor")

        final_view_df = view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "forecast_level_sk", "measure_sk", "company_sk", "cell" ).agg(sum("value").alias("value"))\
                                .withColumn("log_id", lit(log_id).cast(LongType()))\
                                .withColumn("created_date", lit(current_timestamp()))

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.company_sk AS INT) AS `Company SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.forecast_level_sk AS INT) AS `Forecast Level SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                f.created_date AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'GMVA Direct Measures'
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print('measure_list     :', measure_list)
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:

    if data_feed == "finance_fact_bex_gmva_actuals":

        measure_df              = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df       = measure_df.filter(col("measure_type") == "GMVA Direct Measures")
        measure_list            = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str             = ",".join(map(str, measure_list))

        df1     = spark.sql(f"""
                                SELECT * 
                                FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name} 
                                WHERE measure_sk IN ({measure_str})
                            """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_gmva_data where version_sk = 200 and measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))        
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100) 

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS `bu_sk`,
                CAST(PC.DstCode AS INT) AS `product_sk`,
                CAST(f.month_sk AS INT) AS `month_sk`,
                CAST(f.cont_disc_ops_sk AS INT) AS `cont_disc_ops_sk`,
                CAST(f.currency_sk AS INT) AS `currency_sk`,
                CAST(f.version_sk AS INT) AS `version_sk`,
                CAST(f.flow_sk AS INT) AS `flow_sk`,
                CAST(f.measure_sk AS INT) AS `measure_sk`,
                CAST(f.Company_sk AS INT) AS `company_sk`,
                'unk' AS `cell`,
                BU.BUFactor,
                PC.PCFactor,
                f.value,
                f.created_date AS `created_date`
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS `Code`,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS `DSTCode`,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS `BUFactor`
                FROM {uc_catalog_name}.gold_master_data.business_unit BU 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu','sc')
                WHERE BU.is_active IS TRUE
            ) AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS `Code`,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS `DstCode`,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS `PCFactor`
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) AS PC ON PC.Code = f.product_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'GMVA Direct Measures'
        """)

        view_df = view_df.withColumn("value", precise_udf_3("BUFactor", "PCFactor", "value").cast(DecimalType(36, 16))).drop("PCFactor", "BUFactor")
        
        final_view_df = (view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", 
                                         "version_sk", "flow_sk", "measure_sk", "company_sk", "cell").agg(sum("Value").alias("value"))
                                .withColumn("log_id", lit(log_id).cast(LongType()))
                                .withColumn("created_date", lit(current_timestamp())))

        concurrent_external_table_delta_write(final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
                                              uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full")

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT 
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.company_sk AS INT) AS `Company SK`,
                CAST(f.flow_sk AS INT) AS `Flow SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CONCAT(bu.mu_hier_level_5_description, ' ', prod.category_description) AS `Cell`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                f.created_date AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            INNER JOIN {uc_catalog_name}.gold_master_data.business_unit bu
                ON f.bu_sk = bu.bu_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.product prod
                ON prod.product_sk = f.product_sk
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print('measure_list:', measure_list)
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_twc_actuals":

        measure_df              = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df       = measure_df.filter(col("measure_type") == "WC Direct Measures")
        measure_list            = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str             = ",".join(map(str, measure_list))

        df1     = spark.sql(f"""
                                SELECT *
                                FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                                WHERE measure_sk IN ({measure_str})
                            """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_twc_data_actuals where  measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))        
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100) 

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS `bu_sk`,
                CAST(PC.DstCode AS INT) AS `product_sk`,
                CAST(f.month_sk AS INT) AS `month_sk`,
                CAST(CDO.DstCode AS INT) AS `cont_disc_ops_sk`,
                CAST(f.currency_sk AS INT) AS `currency_sk`,
                CAST(f.version_sk AS INT) AS `version_sk`,
                CAST(f.flow_sk AS INT) AS `flow_sk`,
                CAST(f.measure_sk AS INT) AS `measure_sk`,
                CAST(f.Company_sk AS INT) AS `company_sk`,
                'unk' AS `cell`,
                BU.BUFactor,
                PC.PCFactor,
                CDO.CDOFactor,
                f.value,
                f.created_date AS created_date
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu', 'sc')
                WHERE BU.is_active IS TRUE
            ) AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) AS PC ON PC.Code = f.product_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS CDOFactor
                FROM {uc_catalog_name}.gold_master_data.cont_disc_ops CDO
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON CDO.cont_disc_ops_sk = MAP.destination_code_sk AND MAP.Dimension = 'cdo'
                WHERE CDO.is_active IS TRUE
            ) AS CDO ON CDO.Code = f.cont_disc_ops_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'WC Direct Measures'
        """)

        view_df = view_df.withColumn("value", precise_udf_4("BUFactor", "PCFactor", "CDOFactor", "value").cast(DecimalType(36, 16))).drop("PCFactor", "BUFactor", "CDOFactor")

        final_view_df = (view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "flow_sk", "measure_sk", "company_sk", "cell").agg(sum("value").alias("value"))
                                .withColumn("log_id", lit(log_id).cast(LongType()))
                                .withColumn("created_date", lit(current_timestamp())))

        concurrent_external_table_delta_write(final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
                                              uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full")

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT 
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.company_sk AS INT) AS `Company SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.flow_sk AS INT) AS `Flow SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print("measure_list     :", measure_list)
            print(f"{fact_gold_table_name}_temp_view")

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_twc_forecast":

        measure_df              = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        measure_filter_df       = measure_df.filter(col("measure_type") == "WC Direct Measures")
        measure_list            = [row.measure_sk for row in measure_filter_df.select("measure_sk").distinct().orderBy("measure_sk").collect()]
        measure_str             = ",".join(map(str, measure_list))

        df1    = spark.sql(f"""
                            SELECT *
                            FROM {uc_catalog_name}.gold_finance.{fact_gold_table_name}
                            WHERE measure_sk IN ({measure_str})
                        """)
        
        manual_df = spark.sql(f""" select * from {uc_catalog_name}.silver_finance.fact_twc_data_forecast where  measure_sk in ({measure_str}) """)
    
        # Add missing columns with null values to manual_df
        for column in df1.columns:
            if column not in manual_df.columns:
                manual_df = manual_df.withColumn(column, lit(None).cast(df1.schema[column].dataType))        
    
        # Select only the columns available from fact actuals
        manual_df = manual_df.select(df1.columns)
 
        # Union the DataFrames
        df = df1.unionByName(manual_df).repartition(100)        

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS `bu_sk`,
                CAST(PC.DstCode AS INT) AS `product_sk`,
                CAST(f.month_sk AS INT) AS `month_sk`,
                CAST(f.cont_disc_ops_sk AS INT) AS `cont_disc_ops_sk`,
                CAST(f.currency_sk AS INT) AS `currency_sk`,
                CAST(f.version_sk AS INT) AS `version_sk`,
                CAST(f.forecast_level_sk AS INT) AS `forecast_level_sk`,
                CAST(f.measure_sk AS INT) AS `measure_sk`,
                CAST(f.Company_sk AS INT) AS `company_sk`,
                'unk' AS `cell`,
                BU.BUFactor,
                PC.PCFactor,
                f.value,
                f.created_date AS created_date
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu', 'sc')
                WHERE BU.is_active IS TRUE
            ) AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) AS PC ON PC.Code = f.product_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk AND m.measure_type = 'WC Direct Measures'
        """)

        view_df = view_df.withColumn("value", precise_udf_3("BUFactor", "PCFactor", "value").cast(DecimalType(36, 16))).drop("PCFactor", "BUFactor")

        final_view_df = (view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "forecast_level_sk", "measure_sk", "company_sk", "cell").agg(sum("value").alias("value"))
                                .withColumn("log_id", lit(log_id).cast(LongType()))
                                .withColumn("created_date", lit(current_timestamp())))

        concurrent_external_table_delta_write(final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
                                              uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full")

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT 
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.company_sk AS INT) AS `Company SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.forecast_level_sk AS INT) AS `Forecast Level SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            WHERE f.bu_sk != -1 AND f.product_sk != -1
        """)

        if debug_flag == "1":
            print("measure_list     :", measure_list)
            print(f"{fact_gold_table_name}_temp_view")

except Exception as e:
    print(e)
    raise e


# COMMAND ----------

try:
    if data_feed == "finance_fact_offline_data":

        measure_df              = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
        
        df    = spark.sql(f"""
                            SELECT * FROM {uc_catalog_name}.silver_finance.fact_offline_data_actuals
                            UNION ALL
                            SELECT * FROM {uc_catalog_name}.silver_finance.fact_offline_data_forecast
                        """).repartition(100)

        df.createOrReplaceTempView(f"{fact_gold_table_name}_temp_view")

        view_df = spark.sql(f"""
            SELECT 
                CAST(BU.DSTCode AS INT) AS bu_sk,
                CAST(PC.DstCode AS INT) AS product_sk,
                CAST(f.month_sk AS INT) AS month_sk,
                CAST(CDO.DstCode AS INT) AS cont_discont_ops_sk,
                CAST(f.currency_sk AS INT) AS currency_sk,
                CAST(f.version_sk AS INT) AS version_sk,
                CAST(f.flow_sk AS INT) AS flow_sk,
                CAST(f.measure_sk AS INT) AS measure_sk,
                CAST(f.company_sk AS INT) AS company_sk,
                'unk' AS cell,
                BU.BUFactor,
                PC.PCFactor,
                CDO.CDOFactor,
                f.value
            FROM {fact_gold_table_name}_temp_view AS f
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN BU.bu_sk ELSE Map.destination_code_sk END AS DSTCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS BUFactor
                FROM {uc_catalog_name}.gold_master_data.business_unit BU 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON BU.bu_sk = MAP.destination_code_sk AND MAP.Dimension IN ('mu','sc')
                WHERE BU.is_active IS TRUE
            ) AS BU ON BU.Code = f.bu_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS PCFactor
                FROM {uc_catalog_name}.gold_master_data.product PC
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                WHERE PC.is_active IS TRUE
            ) AS PC ON PC.Code = f.product_sk
            INNER JOIN (
                SELECT 
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.source_code_sk END AS Code,
                    CASE WHEN Map.source_code_sk IS NULL THEN CDO.cont_disc_ops_sk ELSE Map.destination_code_sk END AS DstCode,
                    CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE Factor END AS CDOFactor
                FROM {uc_catalog_name}.gold_master_data.cont_disc_ops CDO 
                LEFT OUTER JOIN {uc_catalog_name}.silver_master_data.{map_hierarchy_table_name} MAP 
                    ON CDO.cont_disc_ops_sk = MAP.destination_code_sk AND MAP.Dimension = 'cdo'
                WHERE CDO.is_active IS TRUE
            ) AS CDO ON CDO.Code = f.cont_disc_ops_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m
                ON f.measure_sk = m.measure_sk
            """).withColumnRenamed("cont_discont_ops_sk", "cont_disc_ops_sk")

        view_df = view_df.withColumn("value", precise_udf_4("BUFactor", "PCFactor", "CDOFactor", "value").cast(DecimalType(36, 16))).drop("PCFactor", "BUFactor", "CDOFactor")

        final_view_df = (view_df.groupBy("bu_sk", "product_sk", "month_sk", "cont_disc_ops_sk", "currency_sk", "version_sk", "flow_sk", "measure_sk", "company_sk", "cell").agg(sum("value").alias("value"))
                                .withColumn("log_id", lit(log_id).cast(LongType()))
                                .withColumn("created_date", lit(current_timestamp())))

        concurrent_external_table_delta_write( final_view_df, fact_map_table_path, "gold_finance", fact_map_table_name, [],
            uc_catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full"  )

        refresh_view = spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.gold_finance.{fact_view_name} AS
            SELECT
                CAST(f.bu_sk AS INT) AS `BU SK`,
                CAST(f.product_sk AS INT) AS `Product SK`,
                CAST(f.product_sk * 100000 + f.bu_sk AS INT) AS `Cell SK`,
                CAST(f.month_sk AS INT) AS `Month SK`,
                CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                CAST(f.currency_sk AS INT) AS `Currency SK`,
                CAST(f.company_sk AS INT) AS `Company SK`,
                CAST(f.version_sk AS INT) AS `Version SK`,
                CAST(f.flow_sk AS INT) AS `Flow SK`,
                CAST(f.measure_sk AS INT) AS `Measure SK`,
                CONCAT(bu.mu_hier_level_5_description, ' ', prod.`Category Cell`) AS `Cell`,
                CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                CAST(f.created_date AS TIMESTAMP) AS `Created Date`
            FROM {uc_catalog_name}.gold_finance.{fact_map_table_name} f
            INNER JOIN {uc_catalog_name}.gold_master_data.business_unit bu ON f.bu_sk = bu.bu_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.vw_product_extended prod ON prod.`Product SK` = f.product_sk
            INNER JOIN {uc_catalog_name}.gold_master_data.measure m 
                ON f.measure_sk = m.measure_sk
            WHERE f.bu_sk != -1 AND f.product_sk != -1 """)

        if debug_flag == "1":
            print(f'{fact_gold_table_name}_temp_view')

except Exception as e:
    print(e)
    raise e
