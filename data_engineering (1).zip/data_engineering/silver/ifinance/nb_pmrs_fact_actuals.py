# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Fact Actuals Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   25 Nov 2024     |    Vinod          |    Notebook Created |
# MAGIC
# MAGIC
# MAGIC ## Purpose
# MAGIC This Notebook is used to load Fact Autuals data
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType, DecimalType, LongType
from delta.tables import DeltaTable
from pyspark import StorageLevel
import datetime
start_time = datetime.datetime.now()
from functools import reduce as sum_reduce
from pyspark.sql.functions import sum as spark_sum
from pyspark.sql.functions import when, size, split, array, col, array_contains, sum as spark_sum

# COMMAND ----------

# MAGIC %md
# MAGIC ### Utils

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Widgets

# COMMAND ----------

#getting from parent notebook
external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
username                = dbutils.widgets.get("username")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("run_id")
job_id                  = dbutils.widgets.get("job_id")
file_name               = dbutils.widgets.get("file_name")

#Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------

# Remove all existing widgets
dbutils.widgets.removeAll()

# Create text widgets for various master data feeds and retrieve their values
dbutils.widgets.text("measure_data_feed", "master_data_measure")
measure_data_feed = dbutils.widgets.get("measure_data_feed")

dbutils.widgets.text("currency_data_feed", "master_data_currency")
currency_data_feed = dbutils.widgets.get("currency_data_feed")

dbutils.widgets.text("version_data_feed", "master_data_version")
version_data_feed = dbutils.widgets.get("version_data_feed")

dbutils.widgets.text("cont_disc_ops_data_feed", "master_data_cont_disc_ops")
cont_disc_ops_data_feed = dbutils.widgets.get("cont_disc_ops_data_feed")

dbutils.widgets.text("calendar_data_feed", "master_data_calendar")
calendar_data_feed = dbutils.widgets.get("calendar_data_feed")

dbutils.widgets.text("flow_data_feed", "master_data_flow")
flow_data_feed = dbutils.widgets.get("flow_data_feed")

dbutils.widgets.text("descendant_data_feed", "master_data_descendant")
descendant_data_feed = dbutils.widgets.get("descendant_data_feed")

dbutils.widgets.text("company_data_feed", "master_data_company")
company_data_feed = dbutils.widgets.get("company_data_feed")

# Create widgets for the column values and retrieve their values
dbutils.widgets.text("currency_code",   "2068", "Currency Code")
dbutils.widgets.text("version_code",    "200", "Version Code")
dbutils.widgets.text("current_month_flag", "True")

currency_code       = int(dbutils.widgets.get("currency_code"))
version_code        = dbutils.widgets.get("version_code")
current_month_flag  = dbutils.widgets.get("current_month_flag")

# Create a text widget for debug flag and retrieve its value
dbutils.widgets.text("debug_flag", "1")
debug_flag = dbutils.widgets.get("debug_flag")

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]
    current_nb_name = "nb_pmrs_fact_actuals"
    
    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Pipeline Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10
 
# Insert job log
insert_job_log(log_value, job_id, run_id, username, "Ifinance Silver Fact Actuals Ingestion", datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "", uc_catalog_name)
 
# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to silver ingestion for Fact Actuals", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

try:
    # Extract HBU Code and determine Dimension Code

    hbu_code = file_name.split('#')[2]
    if "HBU1" in hbu_code:
        dimension_code, fact_type = "mu", "dimension_mu"
    elif "HBU3" in hbu_code:
        dimension_code, fact_type = "sc", "dimension_sc"
    print(f"Dimension Code: {dimension_code}, Fact Type: {fact_type}")

    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    param           = get_param_data(uc_catalog_name)

    # Fetch specific configurations for the given data feed
    process_feed_df = fetch_config(param, data_feed)

    config_data     = get_config_data(data_feed, uc_catalog_name, 'finance')

    # Fetch specific configuration for each data feed
    process_feed_df                 = fetch_config(param, data_feed)
    calendar_process_feed_df        = fetch_config(param, calendar_data_feed)
    cont_dis_ops_process_feed_df    = fetch_config(param, cont_disc_ops_data_feed)
    currency_process_feed_df        = fetch_config(param, currency_data_feed)
    flow_process_feed_df            = fetch_config(param, flow_data_feed)
    measure_process_feed_df         = fetch_config(param, measure_data_feed)
    version_process_feed_df         = fetch_config(param, version_data_feed)
    descendant_process_feed_df      = fetch_config(param, descendant_data_feed)
    company_process_feed_df         = fetch_config(param, company_data_feed)

    # Display the filtered data
    display(process_feed_df)

    # Extract configuration details from the dataframes
    catalog_name                    = uc_catalog_name
    delta_db_staging                = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging             = process_feed_df.select("delta_table_staging").first()[0]
    delta_db_silver                 = process_feed_df.select("delta_db_silver").first()[0]
    delta_table_silver              = json.loads(process_feed_df.select("delta_table_silver").first()[0].replace("'", '"')).get(fact_type)
    delta_path_silver               = absolute_path + json.loads(process_feed_df.select("delta_path_silver").first()[0].replace("'", '"')).get(fact_type)
    calendar_delta_db_gold          = calendar_process_feed_df.select("delta_db_gold").first()[0]
    calendar_delta_table_gold       = calendar_process_feed_df.select("delta_table_gold").first()[0]
    cont_disc_ops_delta_db_gold     = cont_dis_ops_process_feed_df.select("delta_db_gold").first()[0]
    cont_disc_ops_delta_table_gold  = cont_dis_ops_process_feed_df.select("delta_table_gold").first()[0]
    currency_delta_db_gold          = currency_process_feed_df.select("delta_db_gold").first()[0]
    currency_delta_table_gold       = currency_process_feed_df.select("delta_table_gold").first()[0]
    flow_delta_db_gold              = flow_process_feed_df.select("delta_db_gold").first()[0]
    flow_delta_table_gold           = flow_process_feed_df.select("delta_table_gold").first()[0]
    measure_delta_db_gold           = measure_process_feed_df.select("delta_db_gold").first()[0]
    measure_delta_table_gold        = measure_process_feed_df.select("delta_table_gold").first()[0]
    version_delta_db_gold           = version_process_feed_df.select("delta_db_gold").first()[0]
    version_delta_table_gold        = version_process_feed_df.select("delta_table_gold").first()[0]
    descendant_delta_db_silver      = descendant_process_feed_df.select("delta_db_silver").first()[0]
    descendant_delta_table_silver   = descendant_process_feed_df.select("delta_table_silver").first()[0]
    delta_silver_partitionBy        = process_feed_df.select("delta_silver_partitionBy").first()[0]

    # Check if there are columns to rename
    rename_columns                  = config_data.get("rename_cols_silver", {})
    rename                          = bool(rename_columns)

    # Compact partitionBy logic
    delta_silver_partitionBy = [col.strip() for col in delta_silver_partitionBy.split(",")] if delta_silver_partitionBy else []

    # If debug_flag is set to "1", print debug information
    if debug_flag == "1":
        print('data_feed                        :', data_feed)
        print('catalog_name                     :', catalog_name)
        print('delta_db_staging                 :', delta_db_staging)
        print('delta_table_staging              :', delta_table_staging)
        print('delta_table_silver               :', delta_table_silver)
        print('delta_db_silver                  :', delta_db_silver)
        print('delta_path_silver                :', delta_path_silver)
        print('calendar_delta_db_gold           :', calendar_delta_db_gold)
        print('calendar_delta_table_gold        :', calendar_delta_table_gold)
        print('cont_disc_ops_delta_db_gold      :', cont_disc_ops_delta_db_gold)
        print('cont_disc_ops_delta_table_gold   :', cont_disc_ops_delta_table_gold)
        print('currency_delta_db_gold           :', currency_delta_db_gold)
        print('currency_delta_table_gold        :', currency_delta_table_gold)
        print('flow_delta_db_gold               :', flow_delta_db_gold)
        print('flow_delta_table_gold            :', flow_delta_table_gold)
        print('measure_delta_db_gold            :', measure_delta_db_gold)
        print('measure_delta_table_gold         :', measure_delta_table_gold)
        print('version_delta_db_gold            :', version_delta_db_gold)
        print('version_delta_table_gold         :', version_delta_table_gold)
        print('descendant_delta_db_silver       :', descendant_delta_db_silver)
        print('descendant_delta_table_silver    :', descendant_delta_table_silver)
        print('rename_columns                   :', rename)
        print('delta_silver_partitionBy         :',delta_silver_partitionBy)

except Exception as e:

    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:

    print(f"Dimension Code: {dimension_code}")

    descendant_bu_df = spark.table(f"{catalog_name}.gold_master_data.dim_descendant") \
                          .filter(col("dimension") == dimension_code)

    # Rename columns for business units
    descendant_bu_df = descendant_bu_df.select(*[col(c).alias(f"bu_{c}") for c in descendant_bu_df.columns])

    # Load descendant data for product categories and filter by dimension pcat
    descendant_pcat_df = spark.table(f"{catalog_name}.gold_master_data.dim_descendant") \
                              .filter(col("dimension") == "pcat")
    

    # Rename columns for product categories
    descendant_pcat_df = descendant_pcat_df.select(*[col(c).alias(f"pcat_{c}") for c in descendant_pcat_df.columns])

    # Join descendant tables for on lowest level hierarchy null handle
    descendant_bu_df    =   (descendant_bu_df.withColumn("bu_descendant_join",
                                    when(col("bu_descendant").isNull(),col("bu_child_code")).otherwise(col("bu_descendant")))
                                    .withColumn("bu_child_list", col("bu_combined_hierarchical_column"))
                                    .drop("bu_combined_hierarchical_column"))

    descendant_pcat_df  =   (descendant_pcat_df.withColumn("pcat_descendant_join",
                                when(col("pcat_descendant").isNull(), col("pcat_child_code")).otherwise(col("pcat_descendant")))
                               .withColumn("pcat_child_list",col("pcat_combined_hierarchical_column"))
                               .drop("pcat_combined_hierarchical_column"))

    # Initialize and assign variables
    third_dim_list                       = []
    desc_top_level_third_dim_code        = None
    desc_lowest_level_third_dim_code     = None
    fact_lowest_level_third_dim_code     = None
    third_dim_flag                       = False

    desc_lowest_level_bu_code            =   descendant_bu_df.select(max(col("bu_level_num"))).collect()[0][0]
    desc_lowest_level_pcat_code          =   descendant_pcat_df.select(max(col("pcat_level_num"))).collect()[0][0]
    if third_dim_flag:
      desc_lowest_level_third_dim_code   =   descendant_third_dim_df.select(max(col("third_dim_level_num"))).collect()[0][0]
    print("desc_lowest_level_bu_code     :",desc_lowest_level_bu_code,"desc_lowest_level_pcat_code     ",desc_lowest_level_pcat_code,"desc_lowest_level_third_dim_code",desc_lowest_level_third_dim_code)

    # Read the bronze fact data
    bronze_staging_df = spark.read.table(f"{catalog_name}.{delta_db_staging}.{delta_table_staging}").filter(col("log_id") == log_id) \
                                  .filter(lower(col("flow")).rlike("month")).drop("log_id","created_date")

    business_unit_df  = spark.read.table(f"{uc_catalog_name}.silver_master_data.business_unit") \
                                  .select("bu_sk","bu_code","bu_description")

    product_df  = spark.read.table(f"{uc_catalog_name}.silver_master_data.product") \
                            .select("product_sk","product_form_code","product_form_description")

    measure_df   = spark.read.table(f"{uc_catalog_name}.silver_master_data.measure").filter(col("is_active") == True) \
                             .select("measure_sk","measure_description")

    # Rename the column first
    measure_df = measure_df.withColumnRenamed("measure_description", "measure_desc_temp")

    # Apply transformations on the new column
    replacements = [("%", "percent"), ("٪", "percent"), ("[- ]", "_"), ("_+", "_"), ("–", " "), ("[^a-zA-Z0-9_]", ""), (r"^_|_$", ""),
        ("p_m", "pm")]
    
    measure_df = measure_df.withColumn("measure_desc_temp", lower(col("measure_desc_temp")))
    for pattern, replacement in replacements:
        measure_df = measure_df.withColumn("measure_desc_temp", regexp_replace(col("measure_desc_temp"), pattern, replacement))

    # Finally, rename it back if needed
    measure_df    =  measure_df.withColumnRenamed("measure_desc_temp", "measure_description")

    flow_df         = spark.read.table(f"{uc_catalog_name}.silver_master_data.flow").select("flow_sk","flow_description")
    calendar_df     = spark.read.table(f"{uc_catalog_name}.silver_master_data.calendar").select("month_sk","month_short_description")
    
    bronze_final_union_df  = bronze_staging_df
    if debug_flag == "1":

        print("bronze_staging_df.count    :",bronze_staging_df.count())
        bronze_final_union_df.display()

except Exception as e:
    
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Reading descendant, fact data failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ### ## Processsing Parent Child Hierarchy **logic**

# COMMAND ----------

def process_parent_child( bronze_staging_df, descendant_bu_df, descendant_pcat_df, base_columns, optional_columns, groupby_columns,
    exclude_columns, third_dim_flag, decimal_type, rename_column, descendant_third_dim_df ):
    
    """
    Processes measure calculations at different hierarchical levels dynamically.

    Args:
        bronze_staging_df (DataFrame): Source DataFrame containing business data.
        descendant_bu_df (DataFrame): DataFrame with business unit hierarchy.
        descendant_pcat_df (DataFrame): DataFrame with product category hierarchy.
        descendant_third_dim_df (DataFrame, optional): DataFrame with third-dimension hierarchy (if applicable).
        third_dim_flag (bool, optional): Flag to indicate whether third-dimension processing is required.

    Returns:
        DataFrame: Processed turnover DataFrame.
    """

    # Join descendant DataFrames
    descendant_combined_df = bronze_staging_df \
        .join(descendant_bu_df, bronze_staging_df["business_unit"]      == descendant_bu_df["bu_child_code"]    , "inner") \
        .join(descendant_pcat_df, bronze_staging_df["product_category"] == descendant_pcat_df["pcat_child_code"], "inner")
    

  
    if third_dim_flag and descendant_third_dim_df:

        descendant_combined_df = descendant_combined_df.withColumn("third_dim", col(f"{rename_column}")).drop(f"{rename_column}")

        descendant_combined_df = descendant_combined_df.join(descendant_third_dim_df, 
                                                            descendant_third_dim_df.third_dim_child_code == descendant_combined_df.third_dim, 
                                                            "inner")

    # Extract hierarchy levels
    levels = {
        "bu": {
            "desc_lowest"   : descendant_bu_df.select(max(col("bu_level_num"))).first()[0],
            "desc_top"      : descendant_bu_df.select(min(col("bu_level_num"))).first()[0],
            "fact_lowest"   : descendant_combined_df.select(max(col("bu_level_num"))).first()[0]
        },
        "pcat": {
            "desc_lowest"   : descendant_pcat_df.select(max(col("pcat_level_num"))).first()[0],
            "desc_top"      : descendant_pcat_df.select(min(col("pcat_level_num"))).first()[0],
            "fact_lowest"   : descendant_combined_df.select(max(col("pcat_level_num"))).first()[0]
        },
    }

    if third_dim_flag and descendant_third_dim_df:
        levels["third_dim"] = {
            "desc_lowest"   : descendant_third_dim_df.select(max(col("third_dim_level_num"))).first()[0],
            "desc_top"      : descendant_third_dim_df.select(min(col("third_dim_level_num"))).first()[0],
            "fact_lowest"   : descendant_combined_df.select(max(col("third_dim_level_num"))).first()[0]
        }
    
    # Generate level lists
    bu_list         = [row[0] for row in descendant_combined_df.select("bu_level_num").distinct().orderBy(col("bu_level_num").desc()).collect()]
    pcat_list       = [row[0] for row in descendant_combined_df.select("pcat_level_num").distinct().orderBy(col("pcat_level_num").desc()).collect()]
    third_dim_list  = (
        [row[0] for row in descendant_combined_df.select("third_dim_level_num").distinct().orderBy(col("third_dim_level_num").desc()).collect()]
        if third_dim_flag else [None]
    )

    print(f"BU Levels: {bu_list} | PCAT Levels: {pcat_list} | Third Dim Levels: {third_dim_list if third_dim_flag else 'N/A'}")

    agg_columns = [col for col in descendant_combined_df.columns if col not in exclude_columns]

    # Initial dummy DataFrame
    dummy_df = descendant_combined_df.filter((col("bu_level_num")    == levels["bu"]["fact_lowest"]) & 
                                             (col("pcat_level_num")  == levels["pcat"]["fact_lowest"]))

    if third_dim_flag and "third_dim" in levels:
        dummy_df = dummy_df.filter(col("third_dim_level_num") == levels["third_dim"]["fact_lowest"])

    agg_exprs = [
        (col(c).cast(decimal_type) - spark_sum(col(f"child_{c}")).cast(decimal_type)).cast(decimal_type).alias(f"calculated_{c}")
        for c in agg_columns
    ]

    # Hierarchical Processing
    for parent_bu_level in bu_list:

        for parent_pcat_level in pcat_list:
            
            for parent_third_dim_level in third_dim_list:

                print(f'Processing: BU {parent_bu_level}, PCAT {parent_pcat_level}, Third Dim {parent_third_dim_level if third_dim_flag else "N/A"}')

                is_lowest_level = (parent_bu_level == levels["bu"]["fact_lowest"]) & (parent_pcat_level == levels["pcat"]["fact_lowest"])

                if third_dim_flag and "third_dim" in levels:
                    is_lowest_level &= (parent_third_dim_level == levels["third_dim"]["fact_lowest"])

                if is_lowest_level:
                    print('Lowest Level Processing')
                    dummy_df = dummy_df.select(*base_columns,*optional_columns,*agg_columns)
                else:
                    # Filter Parent Data
                    parent_df = descendant_combined_df.filter(
                        (col("bu_level_num") == parent_bu_level) & 
                        (col("pcat_level_num") == parent_pcat_level)
                    )

                    if third_dim_flag and "third_dim" in levels:
                        parent_df = parent_df.filter(col("third_dim_level_num") == parent_third_dim_level)

                    # Convert child lists to arrays
                    parent_df = parent_df.withColumn("bu_child_array", split(col("bu_child_list"), ",").cast(ArrayType(StringType()))) \
                                            .withColumn("pcat_child_array", split(col("pcat_child_list"), ",").cast(ArrayType(StringType())))

                    if third_dim_flag:
                        parent_df = parent_df.withColumn("third_dim_child_array", split(col("third_dim_child_list"), ",").cast(ArrayType(StringType())))

                    # Define join condition
                    join_conditions = [
                        array_contains(col("p.bu_child_array"), col("c.business_unit")),
                        array_contains(col("p.pcat_child_array"), col("c.product_category")),
                        col("p.flow") == col("c.flow")
                    ]

                    if third_dim_flag:
                        join_conditions.append(array_contains(col("p.third_dim_child_array"), col("c.third_dim")))

                    join_condition = join_conditions[0]
                    for condition in join_conditions[1:]:
                        join_condition &= condition

                    # Perform join
                    joined_df = parent_df.alias("p").join(
                        dummy_df.alias("c"), join_condition, "left"
                    ).select(col("p.*"), *[col(f"c.{c}").alias(f"child_{c}") for c in agg_columns]).na.fill(0.0)

                    # Aggregate results
                    adjusted_turnover_df = joined_df.groupBy(*groupby_columns,*agg_columns).agg(*agg_exprs).drop(*agg_columns)

                    # Replace previous join logic with the correct one
                    adjusted_turnover_df = adjusted_turnover_df \
                        .join(descendant_bu_df.select("bu_child_code", "bu_child_list", "bu_parent_code"), 
                            col("business_unit") == col("bu_child_code"), "inner") \
                        .join(descendant_pcat_df.select("pcat_child_code", "pcat_child_list", "pcat_parent_code"), 
                            col("product_category") == col("pcat_child_code"), "inner")

                    # Include third_dim join if enabled
                    if third_dim_flag:
                        adjusted_turnover_df = adjusted_turnover_df \
                            .join(descendant_third_dim_df.select("third_dim_child_code", "third_dim_child_list", "third_dim_parent_code"), 
                                col("third_dim") == col("third_dim_child_code"), "inner") \
                            .drop("pcat_child_code", "bu_child_code", "third_dim_child_code")
                    else:
                        adjusted_turnover_df = adjusted_turnover_df.drop("pcat_child_code", "bu_child_code")

                    for c in agg_columns:
                        adjusted_turnover_df = adjusted_turnover_df.withColumnRenamed(f"calculated_{c}", c)

                    dummy_df = adjusted_turnover_df.unionByName(dummy_df).localCheckpoint()

    return dummy_df,descendant_combined_df

# COMMAND ----------

# Define a function to update column values based on level numbers
def update_col_value(df, col_name, level_col, lowest_level_code):
    return df.withColumn(
        col_name,
        when(col(level_col) == lowest_level_code, col(col_name))
        .otherwise(concat(lit(f"DL{lowest_level_code}-"), col(col_name)))
    )

# COMMAND ----------

try:
    base_columns        = ["business_unit", "product_category", "bu_level_num", "pcat_level_num", "bu_parent_code", "pcat_parent_code", "bu_child_list", "pcat_child_list"]
    optional_columns    = ["company", "flow","contdiscops_code"]
    groupby_columns     = ["business_unit", "product_category", "flow", "company","contdiscops_code", "bu_level_num", "pcat_level_num"]

    if third_dim_flag:
        base_columns.extend(["third_dim_level_num", "third_dim_child_list", "third_dim_parent_code"])
        optional_columns.append("third_dim")

    exclude_columns     = set(base_columns + optional_columns + descendant_pcat_df.columns + descendant_bu_df.columns)
    print('exclude_columns  :',exclude_columns)

    if third_dim_flag:
        exclude_columns.update(descendant_third_dim_df.columns)
        groupby_columns.extend(["third_dim", "third_dim_level_num"])

    # Actuals
    processed_df,descendant_combined_df = process_parent_child(
        bronze_final_union_df.drop("log_id","created_date"), descendant_bu_df, descendant_pcat_df, base_columns,
        optional_columns, groupby_columns, exclude_columns, third_dim_flag, decimal_type=DecimalType(36, 16),
        rename_column=None, descendant_third_dim_df=None)

    print('bronze_staging_df      :',bronze_final_union_df.count())
    print('processed_df           :',processed_df.count())
    print('descendant_combined_df :',descendant_combined_df.count())

    # Call update columns function to assign dummy values to the lowest level columns
    final_dummy_df = processed_df
    final_dummy_df = update_col_value(final_dummy_df, "business_unit", "bu_level_num", desc_lowest_level_bu_code)
    final_dummy_df = update_col_value(final_dummy_df, "product_category", "pcat_level_num", desc_lowest_level_pcat_code)

    # Drop unnecessary columns
    drop_columns = set(descendant_bu_df.columns) | set(descendant_pcat_df.columns)

    if third_dim_flag:
        drop_columns |= set(descendant_third_dim_df.columns)

    final_dummy_df = final_dummy_df.drop(*drop_columns)
    final_dummy_df.display()

except Exception as e:
    
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Parent child logic failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ### ## Silver Pivot with SK **logic**

# COMMAND ----------

try:
    
    # Dictionary mapping dataframe names to their corresponding table paths
    tables = {
        "df_measure"        : f"{catalog_name}.{measure_delta_db_gold}.{measure_delta_table_gold}",
        "df_currency"       : f"{catalog_name}.{currency_delta_db_gold}.{currency_delta_table_gold}",
        "df_version"        : f"{catalog_name}.{version_delta_db_gold}.{version_delta_table_gold}",
        "df_cont_disc_ops"  : f"{catalog_name}.{cont_disc_ops_delta_db_gold}.{cont_disc_ops_delta_table_gold}",
        "df_calendar"       : f"{catalog_name}.{calendar_delta_db_gold}.{calendar_delta_table_gold}",
        "df_flow"           : f"{catalog_name}.{flow_delta_db_gold}.{flow_delta_table_gold}",
        "df_descendant"     : f"{catalog_name}.{descendant_delta_db_silver}.{descendant_delta_table_silver}"
                }

    # Iterate over the tables dictionary
    for df_name, table in tables.items():
        # Check if the table exists in the catalog
        if spark.catalog.tableExists(table):
            # Load the table into a dataframe and assign it to a global variable
            globals()[df_name] = spark.table(table)
            # Get the row count of the dataframe
            row_count = globals()[df_name].count()
            # Print the table name and row count
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            # Print a message if the table does not exist
            print(f"Table {table.split('.')[-1]} does not exist")

except Exception as e:

    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in table checking", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    # Prepare the initial DataFrame by dropping unnecessary columns
    df_fact = final_dummy_df
    df_fact_columns = [col for col in df_fact.columns if col not in ['is_active', 'log_id', 'created_date']]
    
    df_fact_joined = df_fact \
                        .join(broadcast(descendant_bu_df), df_fact.business_unit == descendant_bu_df.bu_descendant_join, "left") \
                        .join(broadcast(descendant_pcat_df), df_fact.product_category == descendant_pcat_df.pcat_descendant_join, "left") \
                        .select(descendant_pcat_df['pcat_descendant_sk'].alias('product_sk'), 
                                descendant_bu_df['bu_descendant_sk'].alias('bu_sk'), *df_fact_columns) \
                        .persist(StorageLevel.MEMORY_AND_DISK)

    # Rename columns based on the replacement rules
    for col in df_fact_joined.columns:
        new_col = col.replace('%', 'percent').replace('p_m', 'pm')
        if new_col != col:
            df_fact_joined = df_fact_joined.withColumnRenamed(col, new_col)

    # Rename additional columns if specified in config
    if config_data['rename_cols_silver']:
        df_fact_joined = df_fact_joined.withColumnsRenamed(rename_columns)

    # Handle null values for product_sk and bu_sk
    df_fact_joined = df_fact_joined \
                    .withColumn("product_sk", when(df_fact_joined["product_sk"].isNull(), -1).otherwise(df_fact_joined["product_sk"])) \
                    .withColumn("bu_sk", when(df_fact_joined["bu_sk"].isNull(), -1).otherwise(df_fact_joined["bu_sk"]))

    # Unpivot columns (excluding specific ones)
    columns_to_unpivot = [col for col in df_fact_joined.columns if col not in 
                          ["product_sk", "bu_sk", "flow", 'business_unit', 'product_category', 
                           'log_id', 'created_date', 'company', 'contdiscops_code']]
    
    num_columns = len(columns_to_unpivot)

    # Unpivot the DataFrame using stack
    unpivoted_df = df_fact_joined.select(
                    "product_sk", "bu_sk", "business_unit", "product_category", "flow", "company", "contdiscops_code",
                    expr(f"stack({num_columns}, " + ", ".join([f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure, value)"))

    if debug_flag == "1":
        df_fact_joined.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in Pivoting the records", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else:
    counter += 1
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Pivoting the records completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")

# COMMAND ----------

try:

    replacements = [("%", "percent"),("٪", "percent"),("[- ]", "_"),("_+", "_"),("–", " "),("[^a-zA-Z0-9_]", ""),(r"^_|_$", "")]

    df_measure = df_measure.withColumn("temp_description", lower(df_measure["measure_description"]))

    # Apply filtering early
    df_measure = df_measure.filter(df_measure["is_active"] == True)

    # Apply transformations using a loop
    for pattern, replacement in replacements:
        df_measure = df_measure.withColumn("temp_description", regexp_replace(df_measure["temp_description"], pattern, replacement))

    df_measure = df_measure.withColumn("temp_description", trim(df_measure["temp_description"]))

    # Rename back to measure_description
    df_measure = df_measure.drop("measure_description").withColumnRenamed("temp_description", "measure_description")
    
    unpivoted_df  = unpivoted_df.join(df_measure, df_measure.measure_description == unpivoted_df.measure, "left") \
                      .join(df_flow, regexp_extract(unpivoted_df["flow"], r"(Month)", 1) == df_flow["flow_description"], "left")    

    # Pass the widget values to the columns dynamically
    final_df    = unpivoted_df.withColumn('currency_code', lit(currency_code)) \
                              .withColumn('version_code', lit(version_code)) \
                              .withColumn('current_month_flag', lit(current_month_flag))

    df_company = df_descendant.filter(df_descendant['dimension'] == 'company') \
                              .withColumn('company_sk', df_descendant['descendant_sk'])


    # Join the final DataFrame with currency, version, cont_disc_ops, company, and calendar DataFrames
    df_final    = final_df \
                .join(df_currency, final_df.currency_code == df_currency.currency_code, "left") \
                .join(df_version, final_df.version_code == df_version.version_code, "left") \
                .join(df_cont_disc_ops, final_df.contdiscops_code == df_cont_disc_ops.cont_disc_ops_code, "left") \
                .join(df_company, final_df.company == df_company.child_code, "left") \
                .join(df_calendar, regexp_replace(final_df["flow"], r"^Month\s*", "") == df_calendar["month_short_description"], "left") \
                .select('bu_sk', 'product_sk', 'month_sk', 'measure_sk', 'cont_disc_ops_sk', 
                        'currency_sk', 'version_sk', 'company_sk', 'flow_sk', 'value')
        
    # Add log_id and created_date columns to the final DataFrame
    df_final = df_final.withColumn("log_id", lit(log_id).cast(LongType())) \
                       .withColumn("created_date", lit(current_timestamp())) \
                       .withColumn("value", df_final["value"].cast(DecimalType(36, 16)))

    if debug_flag == "1":
        df_final.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in fact creation using measure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

from pyspark.sql.functions import col

if spark.catalog.tableExists(f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"):
    
    key_columns = ['bu_sk', 'product_sk', 'month_sk', 'measure_sk', 'cont_disc_ops_sk', 
                'currency_sk', 'version_sk', 'company_sk', 'flow_sk']
    
    month_sk= df_final.select("month_sk").distinct().collect()[0][0]

    target_df = spark.table(f"{catalog_name}.{delta_db_silver}.{delta_table_silver}").filter(col('month_sk')== month_sk)

    unmatched_target_df = target_df.join(df_final, key_columns, "left_anti")

    if unmatched_target_df.isEmpty():

        df_final = df_final 
    else:
        df_final = unmatched_target_df.union(df_final) 
        
key_value= df_final.select("month_sk").distinct().collect()[0][0]
print(key_value)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing in to Silver Table

# COMMAND ----------

try:
    # Write the final DataFrame to the Delta table with concurrent external table delta write
    concurrent_external_table_delta_write(df_final, delta_path_silver, delta_db_silver, delta_table_silver, delta_silver_partitionBy, catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag="False", delta_overwrite_mode="full")
    
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to silver delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact Actuals completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

dbutils.notebook.exit(key_value)
