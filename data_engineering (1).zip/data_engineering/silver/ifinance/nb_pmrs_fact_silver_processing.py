# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 2 Feb  2025        |    Vinod      |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Purpose of this Notebook is to run fact notebooks based on feed
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and Gold delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC workflow trigger from webapp
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

data_feed         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed") or ""
uc_catalog_name   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name") or ""
external_location = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location") or ""
object_owner_spn  = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn") or ""
debug_flag        = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag") or ""
username          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username") or ""
file_name         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
log_id            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

# Log the fetched values (useful for debugging)
print(f"Data Feed: {data_feed}")
print(f"UC Catalog Name: {uc_catalog_name}")
print(f"External Location: {external_location}")
print(f"Object Owner SPN: {object_owner_spn}")
print(f"Debug Flag: {debug_flag}")
print(f"Username: {username}")

run_id = log_id
print(f"run_id: {run_id}")

# COMMAND ----------

try:
    # Define common parameters
    common_params = {
        "data_feed": data_feed,
        "uc_catalog_name": uc_catalog_name,
        "external_location": external_location,
        "object_owner_spn": object_owner_spn,
        "debug_flag": debug_flag,
        "username": username,
        "file_name" : file_name,
        "run_id": run_id,
        "job_id": int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    }

    # Conditional logic to run the correct notebook
    if data_feed == "finance_fact_bex_actuals":
        print("Executing: nb_pmrs_fact_actuals...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_actuals", -1, common_params)

    elif data_feed == "finance_fact_bex_forecast":  
        print("Executing: nb_pmrs_fact_forecast...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_forecast", -1, common_params)

    elif data_feed == "finance_fact_bex_brand":  
        print("Executing: nb_pmrs_fact_brand...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_brand", -1, common_params)

    elif data_feed == "finance_fact_bex_brand_position":  
        print("Executing: nb_pmrs_fact_brand_position...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_brand_position", -1, common_params)

    elif data_feed == "finance_fact_bex_customer":  
        print("Executing: nb_pmrs_fact_customer...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_customer", -1, common_params)

    elif data_feed == "finance_fact_bex_gmva_actuals":  
        print("Executing: nb_pmrs_fact_gmva_actuals...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_gmva_actuals", -1, common_params)

    elif data_feed == "finance_fact_bex_gmva_forecast":  
        print("Executing: nb_pmrs_fact_gmva_forecast...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_gmva_forecast", -1, common_params)
    
    elif data_feed == "finance_fact_bex_twc_actuals":  
        print("Executing: nb_pmrs_fact_twc_actuals...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_twc_actuals", -1, common_params)
    
    elif data_feed == "finance_fact_bex_twc_forecast":  
        print("Executing: nb_pmrs_fact_twc_forecast...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_twc_forecast", -1, common_params)

    elif data_feed == "finance_fact_pnl":  
        print("Executing: finance_fact_pnl...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_pnl_actuals_forecast_targets", -1, common_params)

    elif data_feed == "finance_fact_pnl_customer":  
        print("Executing: finance_fact_pnl_customer...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_pnl_customer", -1, common_params)
    
    elif data_feed == "finance_fact_offline_data":  
        print("Executing: finance_fact_offline_data...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_finance_offline_data", -1, common_params)

    elif data_feed == "finance_fact_tax_actuals":  
        print("Executing: finance_fact_tax_actuals...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_tax_actuals", -1, common_params)

    elif data_feed == "finance_fact_tax_forecast":  
        print("Executing: finance_fact_tax_forecast...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_tax_forecast", -1, common_params)

    elif data_feed == "finance_fact_gmva_data":  
        print("Executing: finance_fact_gmva_data...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_gmva_data", -1, common_params)

    elif data_feed == "finance_fact_twc_data":  
        print("Executing: finance_fact_twc_data...")
        result = dbutils.notebook.run("/Workspace/data_engineering/silver/ifinance/nb_pmrs_fact_twc_data", -1, common_params)

    else:
        raise ValueError(f"Unknown data_feed value: {data_feed}")

    dbutils.jobs.taskValues.set("key_value", result)

    print("Notebook execution completed successfully!")

except Exception as e:
    print(f"Error occurred: {str(e)}")
    raise Exception(f"Parent notebook failed due to child error: {str(e)}")
