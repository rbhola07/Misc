# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 20 Sept 2024        |    Gokul/Vinod          |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Ingestion Notebook to ingest the data from bronze table and to create the silver table
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and silver delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import re
import time
import json
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pyspark.sql
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string,BooleanType,IntegralType, StringType, DateType, TimestampType,IntegerType, StructType, StructField,LongType
from pyspark.sql.functions import col, lit, current_timestamp, desc, row_number,trim,concat,regexp_replace
from pyspark.sql.functions import size, replace, to_date, month, year,concat_ws,when,monotonically_increasing_id,coalesce,lower
from delta.tables import *

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/silver/ifinance/nb_pmrs_common_function"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

data_feed         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
external_location = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
object_owner_spn  = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
debug_flag        = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
username          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
log_id            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

# COMMAND ----------

dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("log_id", log_id)

dbutils.widgets.text("data_feed_descendant","master_data_descendant")
data_feed_descendant  = dbutils.widgets.get("data_feed_descendant")

dbutils.widgets.text("is_pcat","")
if dbutils.widgets.get("is_pcat") == 'true':
    data_feed        = "master_data_pcat_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    run_id = int(log_id)

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert/ Update Audit Log Tables
counter = 1
log_value = run_id + 2
detail_log_value = (log_value * 10)

insert_job_log(log_value, job_id, run_id, username,"Ifinance silver Master Ingestion", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Bronze to silver layer ingestion for "+data_feed, datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Read Config Metadata Params

# COMMAND ----------

try:
    # Reading the Ingestion_Configuration_sheet
    param = get_param_data(uc_catalog_name)

    # Fetching the specific configuration
    process_feed_df             = fetch_config(param, data_feed)

    # Display the filtered data
    display(process_feed_df)
    
    # Set up variables from the configuration
    catalog_name                    = uc_catalog_name
    delta_db_silver                 = process_feed_df.select("delta_db_silver").first()[0]
    delta_db_staging                = process_feed_df.select("delta_db_staging").first()[0]
    delta_path_silver               = absolute_path + process_feed_df.select("delta_path_silver").first()[0]
    delta_path_staging              = process_feed_df.select("delta_path_staging").first()[0]
    delta_table_silver              = process_feed_df.select("delta_table_silver").first()[0]
    delta_table_staging             = process_feed_df.select("delta_table_staging").first()[0]
    source_dir_path                 = absolute_path + process_feed_df.select("source_file_path").first()[0]
    delta_silver_partitionBy        = process_feed_df.select("delta_silver_partitionBy").first()[0]
    stream                          = process_feed_df.select("stream").first()[0]
    surrogate_key                   = process_feed_df.select("surrogate_key").first()[0]
    process_descendant              = process_feed_df.select("descendant").first()[0]

    process_feed_descendant_df      = fetch_config(param, data_feed_descendant)
    descendant_db                   = process_feed_descendant_df.select("delta_db_staging").first()[0]
    descendant_table                = process_feed_descendant_df.select("delta_table_staging").first()[0]
    descendant_path                 = absolute_path+process_feed_descendant_df.select("delta_path_staging").first()[0]
    descendant_db_silver            = process_feed_descendant_df.select("delta_db_silver").first()[0]
    descendant_table_silver         = process_feed_descendant_df.select("delta_table_silver").first()[0]
    descendant_path_silver          = absolute_path+process_feed_descendant_df.select("delta_path_silver").first()[0]

    # Define source and target tables
    source_table                    = f"{catalog_name}.{delta_db_staging}.{delta_table_staging}"
    target_table                    = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"

    # Reading json data
    config_data                     = get_config_data(data_feed, uc_catalog_name, stream)

    # Extract key columns, schema, and other configurations
    key_columns                      = config_data.get("key_columns", [])
    
    select_col_silver               = config_data.get("select_col_silver", [])
    overwrite_schema                = config_data.get("overwrite_schema", {})
    exclude_columns                 = config_data.get("exclude_columns", "").strip()
    exclude_columns_silver          = config_data.get("exclude_columns_silver", []) 
    rename_columns_silver           = config_data.get("rename_cols_silver",{}) 

    if rename_columns_silver:
        rename = True
    else:
        rename = False

    if exclude_columns_silver:
        exclude_columns = True
    else:
        exclude_columns = False

    # Ensure partitionBy is a list
    if delta_silver_partitionBy is None:
        delta_silver_partitionBy = ['']

    # Print debug information if debug flag is set
    if debug_flag == "1":
        print('datafeed                          :', data_feed)
        print('datafeed_descendant               :', data_feed_descendant)
        print('catalog_name                      :', catalog_name)
        print('delta_db_silver                   :', delta_db_silver)
        print('delta_db_staging                  :', delta_db_staging)
        print('delta_path_silver                 :', delta_path_silver)
        print('delta_path_staging                :', delta_path_staging)
        print('delta_table_silver                :', delta_table_silver)
        print('delta_table_staging               :', delta_table_staging)
        print('delta_silver_partitionBy          :', delta_silver_partitionBy)
        print('key_columns                       :', key_columns)
        print('source_dir_path                   :', source_dir_path)
        print('source_table                      :', source_table)
        print('rename_columns_silver             :', rename)
        print('exclude_columns_silver            :', exclude_columns)
        print('target_table                      :', target_table)
        print('descendant_db                     :',descendant_db)
        print('descendant_table                  :',descendant_table)
        print('descendant_path                   :',descendant_path)
        print('descendant_db_silver              :',descendant_db_silver)
        print('descendant_table_silver           :',descendant_table_silver)
        print('descendant_path_silver            :',descendant_path_silver)
        print('surrogate_key                     :',surrogate_key)
        print('exclude_columns_silver            :',exclude_columns_silver)
        print('process_descendant                :',process_descendant)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the silver ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Main Orchestration -> Silver Ingestion Master Data

# COMMAND ----------

# MAGIC %md
# MAGIC ###### if datafeed matches silver calendar table creation begins

# COMMAND ----------

try:
    if data_feed == "master_data_calendar":

        # Retrieve start and end date from previous task
        start_date = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="start_date")
        dbutils.jobs.taskValues.set("start_date", start_date)

        end_date = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="end_date")
        dbutils.jobs.taskValues.set("end_date", end_date)
    
        # Call the function to create the silver calendar
        calendar_dim_df = create_silver_calendar(start_date, end_date,log_id)
        
        # Display the DataFrame if debug flag is set
        if debug_flag == "1":
            calendar_dim_df.display()

        # Write the DataFrame to Delta table
        concurrent_external_table_delta_write(
            calendar_dim_df, delta_path_silver, delta_db_silver, delta_table_silver, '', catalog_name,
            object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full"
        )

        counter = counter + 1
        update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "silver calendar Ingestion completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
        
        dbutils.notebook.exit("")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "silver calendar table creation error", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md ##### The below script
# MAGIC ***Check Surrogate Key***: Verify if surrogate keys are not used (`surrogate_key == 'N'`). IF surrogate_key == 'N' below block will be executed and skips remaining all blocks. 
# MAGIC
# MAGIC ***Validate Key Columns***: Check for null, empty, or duplicate values in key columns if specified.
# MAGIC
# MAGIC ***Write to Silver Table***: Write the data to the silver Delta table using a concurrent write function.
# MAGIC
# MAGIC ***Handle Exceptions***: Log failure details and raise an exception if any errors occur.

# COMMAND ----------

from pyspark.sql.functions import col, lower

try:
    if "master_data_map_hierarchy" in data_feed:

        # Load source and target tables
        map_hierarchy_main_df       = spark.table(source_table).withColumn("source_code"   ,trim(col("source_code"))) \
                                        .withColumn("dimension",lower(col("dimension")))

        dim_descendant_main_df      = spark.table(f"{uc_catalog_name}.gold_master_data.dim_descendant")  \
                                        .withColumn("child_code",trim(col("child_code")))

        map_hierarchy_main_df.display()

        map_hierarchy_main_df   = (
                                    map_hierarchy_main_df
                                    .alias("map")
                                    .join(
                                    dim_descendant_main_df.alias("dim"),
                                    (col("dim.child_code") == col("map.source_code")) & (col("map.dimension")==col("dim.dimension")) ,
                                    "left"
                                    )
                                    .select(col("map.destination_code"),col("map.destination_description"),col("map.source_code"),col("map.source_description"),col("map.factor"),col("map.destination_code_level_num"),col("map.destination_code_active"),col("map.dimension"),col("dim.level_num").alias("source_code_level_num"))) \
                                    .filter(col("destination_code_active")==1)
                                    
        map_hierarchy_main_df.display()

        business_unit_mu_df         = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.business_unit  where is_active is true ")   \
                                    .filter(col("mu_hier_level_0_code").isNotNull())

        business_unit_sc_df         = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.business_unit  where is_active is true")   \
                                    .filter(col("sc_level_0_code").isNotNull())

        product_df                  = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.product       where is_active is true ")

        company_df                  = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.company       where is_active is true ")

        cdo_df                      = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.cont_disc_ops where is_active is true ")
        brand_df                    = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.brand where is_active is true ")

        brand_position_df           = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.brand_position where is_active is true ")

        bu_mu_column_re_mappings  = {
                                "mu_hier_level_0_code"          : "hier_level_0_code",
                                "mu_hier_level_1_code"          : "hier_level_1_code",
                                "mu_hier_level_2_code"          : "hier_level_2_code",
                                "mu_hier_level_3_code"          : "hier_level_3_code",
                                "mu_hier_level_4_code"          : "hier_level_4_code",
                                "mu_hier_level_5_code"          : "hier_level_5_code",
                                "mu_code"                       : "hier_level_6_code",
                                "bu_code"                       : "hier_level_7_code",
                                "mu_hier_level_0_description"   : "hier_level_0_description",
                                "mu_hier_level_1_description"   : "hier_level_1_description",
                                "mu_hier_level_2_description"   : "hier_level_2_description",
                                "mu_hier_level_3_description"   : "hier_level_3_description",
                                "mu_hier_level_4_description"   : "hier_level_4_description",
                                "mu_hier_level_5_description"   : "hier_level_5_description",
                                "mu_description"                : "hier_level_6_description",
                                "bu_description"                : "hier_level_7_description",
                                "bu_sk"                         : "sugg_sk",
                                "source" : "source"
                                }

        bu_mu_columns                   = list(bu_mu_column_re_mappings.values())
        renamed_bu_mu_df                = business_unit_mu_df.withColumnsRenamed(bu_mu_column_re_mappings).select(*bu_mu_columns).distinct()

        # BU SC

        bu_sc_column_re_mappings = {
            "sc_level_0_code": "hier_level_0_code",
            "sc_level_1_code": "hier_level_1_code",
            "sc_level_2_code": "hier_level_2_code",
            "sc_level_3_code": "hier_level_3_code",
            "sc_level_4_code": "hier_level_4_code",
            "sc_level_5_code": "hier_level_5_code",
            "sc_level_6_code": "hier_level_6_code",
            "sc_mu_code": "hier_level_7_code",
            "bu_code": "hier_level_8_code",
            "sc_level_0_description": "hier_level_0_description",
            "sc_level_1_description": "hier_level_1_description",
            "sc_level_2_description": "hier_level_2_description",
            "sc_level_3_description": "hier_level_3_description",
            "sc_level_4_description": "hier_level_4_description",
            "sc_level_5_description": "hier_level_5_description",
            "sc_level_6_description": "hier_level_6_description",
            "sc_mu_description": "hier_level_7_description",
            "bu_description": "hier_level_8_description",
            "bu_sk"         :"sugg_sk",
            "source" : "source"
        }

        bu_sc_columns                   = list(bu_sc_column_re_mappings.values())
        renamed_bu_sc_df                = business_unit_sc_df.withColumnsRenamed(bu_sc_column_re_mappings).select(*bu_sc_columns).distinct()

        # PCAT

        pcat_column_re_mappings = {
        "total_unilever_by_product_category_code": "hier_level_0_code",
        "legacy_division_code": "hier_level_1_code",
        "division_code": "hier_level_2_code",
        "sub_division_2_code": "hier_level_3_code",
        "category_code": "hier_level_4_code",
        "market_code": "hier_level_5_code",
        "sector_code": "hier_level_6_code",
        "sub_sector_code": "hier_level_7_code",
        "segment_code": "hier_level_8_code",
        "product_form_code": "hier_level_9_code",
        "total_unilever_by_product_category_description": "hier_level_0_description",
        "legacy_division_description"   : "hier_level_1_description",
        "division_description"          : "hier_level_2_description",
        "sub_division_2_description"    : "hier_level_3_description",
        "category_description"          : "hier_level_4_description",
        "market_description"            : "hier_level_5_description",
        "sector_description"            : "hier_level_6_description",
        "sub_sector_description"        : "hier_level_7_description",
        "segment_description"           : "hier_level_8_description",
        "product_form_description"      : "hier_level_9_description",
        "product_sk"                    :"sugg_sk",
        "source" : "source"
        }

        pcat_columns             =   list(pcat_column_re_mappings.values())
        renamed_pcat_df          =   product_df.withColumnsRenamed(pcat_column_re_mappings).select(*pcat_columns).distinct()

        # Company

        company_column_re_mappings = {
            "total_legal_entity_geography_code": "hier_level_0_code",
            "total_legal_entity_geography_description": "hier_level_0_description",
            "region_code": "hier_level_1_code",
            "region_description": "hier_level_1_description",
            "cluster_code": "hier_level_2_code",
            "cluster_description": "hier_level_2_description",
            "sub_region_code": "hier_level_3_code",
            "sub_region_description": "hier_level_3_description",
            "country_code": "hier_level_4_code",
            "country_description": "hier_level_4_description",
            "sub_country_code": "hier_level_5_code",
            "sub_country_description": "hier_level_5_description",
            "legal_entity_code": "hier_level_6_code",
            "legal_entity_description": "hier_level_6_description",
            "company_sk": "sugg_sk",
            "source" : "source"
                            }

        # Rename columns and select distinct values
        renamed_company_df = company_df.selectExpr(*[f"{old} as {new}" for old, new in company_column_re_mappings.items()]
        ).distinct()

        # CDO

        cdo_column_re_mappings = {
                            "cont_disc_ops_code"            : "hier_level_0_code",
                            "cont_disc_ops_description"     : "hier_level_0_description",
                            "cont_disc_ops_sk"              :"sugg_sk",
                            "source" : "source"
                                }

        cdo_columns             = list(cdo_column_re_mappings.values())
        renamed_cdo_df          = cdo_df.withColumnsRenamed(cdo_column_re_mappings).select(*cdo_columns).distinct()

        #brand position
        brand_position_re_mappings = {
            "brand_position_level_0_code"        : "hier_level_0_code",
            "brand_position_level_1_code"        : "hier_level_1_code",
            "brand_position_level_2_code"        : "hier_level_2_code",
            "brand_position_level_3_code"        : "hier_level_3_code",
            "brand_position_default_code"        : "hier_level_4_code",
            "brand_position_level_0_description" : "hier_level_0_description",
            "brand_position_level_1_description" : "hier_level_1_description",
            "brand_position_level_2_description" : "hier_level_2_description",
            "brand_position_level_3_description" : "hier_level_3_description",
            "brand_position_description"         : "hier_level_4_description",
            "brand_position_sk"                  : "sugg_sk",
            "source"                             : "source"}

        brand_position_columns     = list(brand_position_re_mappings.values())
        renamed_brand_position_df  = brand_position_df.withColumnsRenamed(brand_position_re_mappings).select(*brand_position_columns).distinct()
         
        #brand

        brand_re_mappings = {
            "total_by_finance_code"         : "hier_level_0_code",
            "corporate_parent_finance_code" : "hier_level_1_code",
            "corporate_brand_code"          : "hier_level_2_code",
            "total_by_brand_description"    : "hier_level_0_description",
            "corporate_parent_brand_description"        : "hier_level_1_description",
            "corporate_brand_description"   : "hier_level_2_description",
            "brand_sk"                      : "sugg_sk",
            "source"                        : "source"
        }

        brand_columns              = list(brand_re_mappings.values())
        renamed_brand_df           = brand_df.withColumnsRenamed(brand_re_mappings).select(*brand_columns).distinct()

        # MU Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("mu")).count() > 0:

            bu_mu_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension")=="mu"), renamed_bu_mu_df.filter(~col("source").isin('calculated')), "source_code",8)

            bu_mu_destination_code_df      =   process_hierarchy_levels(bu_mu_source_code_df, renamed_bu_mu_df.filter(col("source").isin("local finance","calculated")), "destination_code",8)

            bu_mu_destination_code_df      =   bu_mu_destination_code_df \
            .filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))

            final_df = bu_mu_destination_code_df

            bu_mu_destination_code_df.display()
            final_df.display()

        # SC Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("sc")).count()>0:

            bu_sc_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension")=="sc"), renamed_bu_sc_df.filter(~col("source").isin('calculated')), "source_code",9)

            bu_sc_destination_code_df      =   process_hierarchy_levels(bu_sc_source_code_df, renamed_bu_sc_df.filter(col("source").isin("local finance","calculated")), "destination_code",9)

            bu_sc_destination_code_df      =   bu_sc_destination_code_df \
            .filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))
            
            final_df = final_df.unionByName(bu_sc_destination_code_df)

            bu_sc_destination_code_df.display()
            final_df.display()

        # PCAT Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("pcat")).count()>0:

            pcat_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension")=="pcat"), renamed_pcat_df.filter(~col("source").isin('calculated')), "source_code",10)

            pcat_destination_code_df      =   process_hierarchy_levels(pcat_source_code_df, renamed_pcat_df.filter(col("source").isin("local finance","calculated")), "destination_code",10)

            pcat_destination_code_df      =   pcat_destination_code_df \
            .filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))

            final_df = final_df.unionByName(pcat_destination_code_df)
        
        pcat_destination_code_df.display()
        final_df.display()

        # Company Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("company")).count()>0:

            company_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension").like("company")), renamed_company_df.filter(~col("source").isin('calculated')), "source_code",7)

            company_destination_code_df      =   process_hierarchy_levels(company_source_code_df, renamed_company_df.filter(col("source").isin("local finance","calculated")), "destination_code",7)

            company_destination_code_df      =   company_destination_code_df.filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))

            final_df = final_df.unionByName(company_destination_code_df)

        # CDO Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("cdo")).count()>0:

            cdo_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension").like("%cdo%")), renamed_cdo_df.filter(~col("source").isin('calculated')), "source_code",1)

            cdo_destination_code_df      =   process_hierarchy_levels(cdo_source_code_df, renamed_cdo_df.filter(col("source").isin("local finance","calculated")), "destination_code",1)

            cdo_destination_code_df      =   cdo_destination_code_df.filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))
            
            final_df = final_df.unionByName(cdo_destination_code_df)
        
        # brand position Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("brand_position")).count()>0:
            brand_position_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension").like("%brand_position%")), renamed_brand_position_df.filter(~col("source").isin('calculated')), "source_code",5)
            
            brand_position_destination_code_df      =   process_hierarchy_levels(brand_position_source_code_df, renamed_brand_position_df.filter(col("source").isin("local finance","calculated")), "destination_code",5)

            brand_position_destination_code_df      =   brand_position_destination_code_df.filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))

            final_df = final_df.unionByName(brand_position_destination_code_df)

        # brand Dimension
        if map_hierarchy_main_df.filter(col("dimension").like("brand")).count()>0:
            brand_source_code_df           =   process_hierarchy_levels(map_hierarchy_main_df.filter(col("dimension").like("%brand%")), renamed_brand_df.filter(~col("source").isin('calculated')), "source_code",3)        

            brand_destination_code_df      =   process_hierarchy_levels(brand_source_code_df, renamed_brand_df.filter(col("source").isin("local finance","calculated")), "destination_code",3)

            brand_destination_code_df      =   brand_destination_code_df.filter((col("destination_code_sk").isNotNull()) & (col("source_code_sk").isNotNull()))

            final_df = final_df.unionByName(brand_destination_code_df)
            
        # final_df    = bu_mu_destination_code_df.unionByName(pcat_destination_code_df).unionByName(company_destination_code_df).unionByName(bu_sc_destination_code_df).unionByName(cdo_destination_code_df)
        
        final_df.display()
        
        final_exp_df = final_df  \
                    .withColumn("destination_code_sk", explode(array_sort("destination_code_sk"))) \
                    .withColumn("source_code_sk", explode(array_sort("source_code_sk"))) \
                    .select("destination_code","destination_description","source_code","source_description","destination_code_level_num","destination_code_active","factor","dimension","source_code_level_num","destination_code_sk","source_code_sk") \
                    .withColumn("log_id", lit(log_id).cast(LongType())).withColumn("created_date", lit(current_timestamp()))

        final_exp_df.display()

        concurrent_external_table_delta_write(final_exp_df, delta_path_silver, delta_db_silver, delta_table_silver,[], uc_catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag="False" , delta_overwrite_mode = "full" )

except Exception as e:
    # Capture and log the error
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Failed in Map Hierarchy record processing", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e
else:
    # Log successful completion of calculated record processing
    counter += 1
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Map Hierarchy silver table " + data_feed, datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")

# COMMAND ----------

if "master_data_map_hierarchy" in data_feed:
    dbutils.notebook.exit("Execution stopped.")

# COMMAND ----------

if surrogate_key == 'N':  
    try:
        # Verify if the bronze Delta table exists
        if not delta_table_exists(spark, delta_path_staging):
            raise Exception(f"Bronze table missing at {delta_path_staging}. Please create it first.")

        # Load DataFrame
        staging_df = spark.table(source_table)

        # Validate key columns if specified
        if key_columns:
            validate_key_columns_for_nulls(staging_df, key_columns)  
            if staging_df.count() != staging_df.select(key_columns).distinct().count():
                raise Exception(f"Duplicate values found in key columns: {key_columns}")
            print("Key column validation passed. No nulls or duplicates.")

        # Apply transformations
        if rename :
            staging_df = staging_df.withColumnsRenamed(rename_columns_silver)

        if exclude_columns:
            staging_df = staging_df.drop(*exclude_columns_silver)
        
        if data_feed in ['master_data_top20brand','master_data_dimension_alternate_description']:
            df_target_table = f"{catalog_name}.{descendant_db_silver}.{descendant_table_silver}"
            target_df = spark.table(df_target_table)

            staging_df = staging_df.alias("staging")
            target_df = target_df.alias("target")
            if data_feed == 'master_data_top20brand':
                staging_df = staging_df.join(
                    target_df,
                    on=staging_df["brand_code"] == target_df["child_code"],
                    how="inner" ).select(target_df["descendant_sk"],
                    *staging_df.columns) 
            else:
                staging_df = staging_df.join(
                    target_df,
                    on=staging_df["attribute_code"] == target_df["child_code"],
                    how="inner" ).select(target_df["descendant_sk"],
                    *staging_df.columns) 
        
        staging_df = staging_df.withColumn("has_data", lit(0).cast(BooleanType()))  # Add has_data column
        
        # Reorder columns
        bronze_cols  = [col for col in staging_df.columns if col not in ['log_id', 'created_date', 'is_active', 'has_data']]
        staging_df   = staging_df.select(bronze_cols + ['is_active', 'has_data', 'log_id', 'created_date'])

        # Write to silver Delta table
        concurrent_external_table_delta_write(staging_df, delta_path_silver, delta_db_silver, delta_table_silver, '', catalog_name,
                object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full" )

        # Log success
        update_job_log(log_value, status_success_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log( int(detail_log_value + counter), log_value, run_id, username, "Ingestion to Silver Calendar Table Completed",
                               datetime.now(),status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "" )

        dbutils.notebook.exit("Execution stopped.")

    except Exception as e:
        error_message, error_code = str(e).replace("'", ""), type(e).__name__
        counter += 1
        print(f"error : {error_message}")
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Silver Calendar Table Creation Error", datetime.now(), 
            status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error_message)
        raise e


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Creating dataframe without dummy and descendant table
# MAGIC - The below script first checks if the `data_feed` is not part of the allowed list.
# MAGIC - If it is, the script initiates a key column check to see if it has duplicates.
# MAGIC - It will rename the columns if the `rename` flag is true.
# MAGIC - It will exclude the columns specified in the JSON if the `exclude` flag is true.
# MAGIC - The final staging DataFrame will be created and a surrogate key will be generated.

# COMMAND ----------

try:
    if process_descendant != "Y" and data_feed not in ["master_data_pcat_hierarchy"]:
        #process_descendant not required tables

        # Check if the bronze table exists in the specified location
        if not delta_table_exists(spark, delta_path_staging):
            raise Exception(f"Bronze table does not exist in the file location {delta_path_staging}. Please create the bronze table first.")
        else:
            print(f"Bronze table exists at {delta_path_staging}")

        # Load the bronze table into a staging DataFrame
        staging_df = spark.table(source_table)

        # Generate the surrogate key column name
        var_sk = delta_table_silver + "_sk"

        if data_feed == 'master_data_geography':
            staging_df  = staging_df.filter(lower(staging_df["iso_country_active_status"]) == 'active')
            staging_df  = generate_surrogate_key(staging_df, key_columns, "surrogate_key")
            key_columns = ['surrogate_key']

        # Validate the presence of key columns and check for null or empty values
        if key_columns:
            validate_key_columns_for_nulls(staging_df, key_columns)
            print("key_columns do not have null values")

            # Add additional columns for staging
            staging_df = staging_df.withColumns({   "is_active": lit(True).cast(BooleanType()),
                                                    "updated_date": lit(current_timestamp()),
                                                    var_sk: lit(None).cast(IntegerType()),
                                                    "has_data": lit(0).cast(BooleanType()) })
        else:
            raise Exception("key_columns is empty")

        
        # Rename columns based on configuration if specified
        if rename: 
            staging_df = staging_df.withColumnsRenamed(rename_columns_silver)
        
        # Drop excluded columns if specified
        if exclude_columns: 
            staging_df = staging_df.drop(*exclude_columns_silver)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in silver data processing", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Bronze Descendant Table Creation
# MAGIC - The below script first checks if the `data_feed` is part of the allowed list.
# MAGIC - If it is, the script initiates the parent-child logic, dummy, and descendant function calls based on the `data_feed`.
# MAGIC - It generates a surrogate key, which is a combination of the code column from the dummy DataFrame and the parent-child DataFrame. For each data feed we need to filter out `finance` record for dummy and descendant so many if block will be there
# MAGIC - The script then joins these two DataFrames to create the final DataFrame, which is used to create the silver table.
# MAGIC - In this code, the descendant table will be created, containing parent and child codes with dimensions.

# COMMAND ----------

if process_descendant == "Y" and data_feed not in ["master_data_business_unit_sc", "master_data_business_unit_mu"]:
    try:
        # Mapping data feeds to their respective processing functions
        data_feed_function_map = {
            "master_data_brand_position": process_brand_position,
            "master_data_customer": process_customer,
            "master_data_brand": process_brand,
            "master_data_customer_channel": process_customer_channel,
            "master_data_product_category": process_product_category,
            "master_data_company": process_company
        }

        # Check if the bronze table exists
        path_existing = delta_table_exists(spark, delta_path_staging)
        if not path_existing:
            raise Exception(f"Bronze table does not exist at {delta_path_staging}. Please create the bronze table first.")

        # Surrogate key column name
        var_sk = delta_table_silver + "_sk"

        # Load bronze table into a staging DataFrame
        staging_df = spark.table(source_table)

        # Apply specific filters for each data feed

        if data_feed == "master_data_brand_position":
            staging_df = staging_df.filter((col("active_status") == 1) & (col("brand_position_subscribe").isNotNull()))
        elif data_feed == "master_data_brand":
            staging_df = staging_df.filter((col("corporate_brand_active_status") == "Active") & (col("corporate_brand_subscribe").isNotNull()))
        elif data_feed == "master_data_customer":
            staging_df = staging_df.filter(col("active_status") == "Active") \
                .withColumns({"total_customer_code": lit("TOTAL"), "total_customer_description": lit("Total Description")})
        elif data_feed == "master_data_customer_channel":
            staging_df = staging_df.filter(
                (col("total_channel_active_status") == "Active") &
                (col("macro_channel_active_status") == "Active") &
                (col("format_channel_active_status") == "Active") &
                (col("sub_format_channel_active_status") == "Active")
            )
        elif data_feed == "master_data_company":
            staging_df = staging_df.filter(col("used_in_ifinance") == "Yes").withColumns({
                "total_legal_entity_geography_code": concat(lit('J'), col("total_legal_entity_geography_code")),
                "region_code": concat(lit('J'), col("region_code")),
                "cluster_code": concat(lit('J'), col("cluster_code")),
                "sub_region_code": when(col("sub_region_code").like("LV3_%"),
                                        regexp_replace(col("sub_region_code"), "LV3_", "LV3_J"))
                                    .otherwise(concat(lit('J'), col("sub_region_code"))),
                "sub_country_code": concat(lit('J'), col("sub_country_code")),
                "legal_entity_code": concat(lit('J'), col("legal_entity_code"))})
            
            staging_df = staging_df.dropDuplicates(key_columns)

        # Drop columns based on configuration
        if exclude_columns:
            staging_df = staging_df.drop(*exclude_columns_silver)

        # Process data feed-specific logic
        if path_existing:
            process_function = data_feed_function_map.get(data_feed)
            if process_function:
                processed_df, dummy_df, transformed_df = process_function(staging_df, data_feed, descendant_db, descendant_table,
                                                                          descendant_path, catalog_name, object_owner_spn, absolute_path, debug_flag)

        # Filter out rows where key columns are null
        processed_df = processed_df.drop("dimension").filter(" OR ".join([f"{col} IS NOT NULL" for col in key_columns]))

        # Additional processing for specific data feeds
        if data_feed == "master_data_brand":
            staging_df_temp = staging_df.filter((lower(col("corporate_brand_subscribe")).contains("marketing")) & (~lower(col("corporate_brand_subscribe")).contains("finance")))
            staging_df_temp = generate_surrogate_key(staging_df_temp, key_columns, "surrogate_key")

        elif data_feed == "master_data_customer_channel":
            staging_df_temp = staging_df.filter((lower(col("macro_channel_subscribe")).contains("marketing")) & (~lower(col("macro_channel_subscribe")).contains("finance")))
            dummy_df = dummy_df.withColumn("macro_channel_subscribe", lit("FINANCE Dummy"))
            staging_df_temp = generate_surrogate_key(staging_df_temp, key_columns, "surrogate_key")

        elif data_feed == "master_data_brand_position":
            staging_df_temp = staging_df.filter((lower(col("brand_position_subscribe")).contains("marketing")) & (~lower(col("brand_position_subscribe")).contains("finance")))
            staging_df_temp = generate_surrogate_key(staging_df_temp, key_columns, "surrogate_key")

        # Generate surrogate keys
        processed_df = generate_surrogate_key(processed_df, key_columns, "surrogate_key")
        dummy_df = generate_surrogate_key(dummy_df, key_columns, "surrogate_key")
        staging_df = generate_surrogate_key(staging_df, key_columns, "surrogate_key_der")

        # Process surrogate keys and clean up data
        processed_df = process_surrogate_key_cleanup(processed_df, "surrogate_key")

        # Join staging data
        extra_columns_from_staging_df = [col_name for col_name in staging_df.columns if col_name not in processed_df.columns]
        staging_df = staging_df.select(*extra_columns_from_staging_df).distinct()
        if data_feed == "master_data_company":
            result_df = staging_df.join(processed_df, staging_df["surrogate_key_der"] == processed_df["surrogate_key"], how="inner") \
                .drop("surrogate_key_der", "temp_surrogate_key", "created_date", "log_id")
        else:
            result_df = staging_df.join(processed_df, staging_df["surrogate_key_der"] == processed_df["temp_surrogate_key"], how="inner") \
                .drop("surrogate_key_der", "temp_surrogate_key", "created_date", "log_id")

        # Append additional data for specific feeds
        if data_feed == "master_data_brand":
            staging_df_temp = staging_df_temp.drop("log_id", "created_date")
            result_df = result_df.unionByName(staging_df_temp)

        if data_feed == "master_data_brand_position":
            staging_df_temp = staging_df_temp.drop("log_id", "created_date")
            result_df = result_df.unionByName(staging_df_temp)

        # Finalize data for union
        dummy_df = dummy_df.withColumn("dummy_flag", lit(1).cast("boolean"))
        result_df = result_df.withColumn("dummy_flag", lit(0).cast("boolean"))
        for col in result_df.columns:
            if col not in dummy_df.columns:
                dummy_df = dummy_df.withColumn(col, lit(None).cast("String"))
        staging_df = dummy_df.unionByName(result_df)

        key_columns = ['surrogate_key']

        # Validate key columns for null values
        if key_columns:
            validate_key_columns_for_nulls(staging_df, key_columns)
            staging_df = staging_df.withColumns({
                "is_active": lit(True).cast(BooleanType()),
                var_sk: lit(None).cast(IntegerType()),
                "updated_date": lit(current_timestamp()),
                "created_date": lit(current_timestamp()),
                "has_data": lit(0).cast(BooleanType()),
                "log_id": lit(log_id).cast(LongType())
            })

        else:
            raise Exception("key_columns is empty")

        # Rename columns if configuration is provided
        if rename:
            staging_df = staging_df.withColumnsRenamed(rename_columns_silver)
            print("Column rename using config JSON completed.")

        # Add the "source" column with values from the bronze table
        bronze_df = spark.table(source_table)
        bronze_source_value_row = bronze_df.filter(bronze_df['source'].isNotNull()).select('source').first()[0]
        staging_df = staging_df.withColumn("source", lit(bronze_source_value_row))

        # Display the final staging DataFrame
        staging_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter = counter + 1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Failed in Bronze decentant table creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e
    else:
        counter = counter + 1
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze decentant table creation completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Bronze Descendant Table Creation
# MAGIC - The below script first checks if the `data_feed` is part of the `business_unit_mu and business_unit_sc'`.
# MAGIC - If it is, the script initiates the parent-child logic, dummy, and descendant function calls based on the `data_feed`.
# MAGIC - It generates a surrogate key, which is a combination of the code column from the dummy DataFrame and the parent-child DataFrame. For each data feed we need to filter out `finance` record for dummy and descendant so many if block will be there
# MAGIC - In this code we will merge two table in to single table `business_unit_mu and business_unit_sc` into `business_unit' table
# MAGIC -- If MU records comes in SC column will be null and vice versa 
# MAGIC - The script then joins these two DataFrames to create the final DataFrame, which is used to create the silver table.
# MAGIC - In this code, the descendant table will be created, containing parent and child codes with dimensions.

# COMMAND ----------

if process_descendant == "Y" and data_feed in ["master_data_business_unit_sc", "master_data_business_unit_mu"]:
    
    try:
        # Mapping data feeds to their respective processing functions
        data_feed_function_map = { "master_data_business_unit_mu": process_business_unit_mu,
                                   "master_data_business_unit_sc": process_business_unit_sc, }
        var_sk = "bu_sk"  

        # Verify existence of the bronze table
        if not delta_table_exists(spark, delta_path_staging):
            raise Exception(f"Bronze table does not exist at {delta_path_staging}. Please create the bronze table first.")

        # Load bronze table into a DataFrame
        bronze_df = spark.table(source_table)

        # Drop excluded columns if specified
        if exclude_columns: 
            bronze_df = bronze_df.drop(*exclude_columns_silver)

        # Process data based on the function mapping
        process_function = data_feed_function_map[data_feed]
        processed_df, dummy_df, transformed_df = process_function( bronze_df, data_feed, descendant_db, descendant_table,
            descendant_path, catalog_name, object_owner_spn, absolute_path,debug_flag  )

        # Filter out rows where key columns are null
        processed_df = processed_df.drop("dimension").filter(" OR ".join([f"{col} IS NOT NULL" for col in key_columns]))

        # Generate surrogate keys
        processed_df   = generate_surrogate_key(processed_df, key_columns, "surrogate_key")
        dummy_df       = generate_surrogate_key(dummy_df, key_columns, "surrogate_key")
        transformed_df = generate_surrogate_key(bronze_df, key_columns, "surrogate_key_der")

        # Cleanup surrogate keys
        processed_df   = process_surrogate_key_cleanup(processed_df, "surrogate_key")

        # Extract extra columns from transformed_df
        extra_columns  = [col for col in transformed_df.columns if col not in processed_df.columns]
        extra_data_df  = transformed_df.select(*extra_columns).distinct()

        # Join transformed data with processed data
        final_transformed_df = ( extra_data_df.join(processed_df, extra_data_df["surrogate_key_der"] == processed_df["temp_surrogate_key"], how="inner")
                                              .drop("surrogate_key_der", "temp_surrogate_key", "created_date", "log_id"))

        # Mark rows as dummy or not dummy
        dummy_df             = dummy_df.withColumn("dummy_flag", lit(1).cast("boolean"))
        final_transformed_df = final_transformed_df.withColumn("dummy_flag", lit(0).cast("boolean"))

        # Ensure missing columns in dummy_df
        for col in final_transformed_df.columns:
            if col not in dummy_df.columns:
                dummy_df = dummy_df.withColumn(col, lit(None).cast("string"))

        # Combine final DataFrames
        final_combined_df = dummy_df.unionByName(final_transformed_df)

        # Ensure key columns are not null
        key_columns = ["surrogate_key"]
        validate_key_columns_for_nulls(final_combined_df, key_columns)

        # Add metadata columns
        final_combined_df = final_combined_df.withColumns({ "is_active": lit(True).cast(BooleanType()),
                                                            var_sk: lit(None).cast(IntegerType()),
                                                            "updated_date": lit(current_timestamp()),
                                                            "created_date": lit(current_timestamp()),
                                                            "has_data": lit(0).cast(BooleanType()),
                                                            "log_id": lit(log_id).cast(LongType()), })

        # Rename columns based on configuration
        if rename: final_combined_df = final_combined_df.withColumnsRenamed(rename_columns_silver)
        print("Columns renamed using config JSON")

        # Add missing business unit columns to the DataFrame
        business_unit_columns = config_data.get("business_unit_columns", [])
        for col in business_unit_columns:
            if col not in final_combined_df.columns:
                final_combined_df = final_combined_df.withColumn(col, lit(None).cast("String"))

        # Select silver columns based on the data feed type
        silver_selected_columns = config_data.get("silver_selected_columns_mu" 
                if data_feed == "master_data_business_unit_mu" else "silver_selected_columns_sc", [] )

        # Prepare the final DataFrame for writing
        staging_df = final_combined_df.selectExpr(*silver_selected_columns).distinct()

        # Add the source column to the DataFrame
        bronze_df = spark.table(source_table)
        bronze_source_value_row = bronze_df.filter(bronze_df['source'].isNotNull()).select('source').first()[0]
        staging_df = staging_df.withColumn("source", lit(bronze_source_value_row)).drop("surrogate_key")

        # Set key columns
        key_columns = ['bu_code']

        if debug_flag == "1":
            staging_df.display()
            
    except Exception as e:
        error, error_code = str(e).replace("'", ""), type(e).__name__
        counter += 1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Failed in Descendant Dummy creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e
    else:
        counter += 1
        insert_job_detail_log( int(detail_log_value + counter), log_value, run_id, username, "Descendant Dummy Completed " + data_feed, datetime.now(),status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "" )


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Calculated Table 
# MAGIC - The below checks the data feed is part of the below block, if yes if will checks the target table and source table calculated exists
# MAGIC - It will generate the surrogate key for source table
# MAGIC - It will join target table with calculated tables using left anti join so unmatched reocrds will join.
# MAGIC - If any renaming and exclude is true it will be done
# MAGIC
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col, lower
try:
    if "calculated" in data_feed:
        # Load source and target tables
        staging_df      = spark.table(source_table)
        filtered_tgt_df = spark.table(target_table).filter( ~lower(col("source")).like("%calculated%") &  
                                                            ~lower(col("source")).like("%local%") &  
                                                            col("is_active") == True  )
        
        # Determine surrogate key column name based on data_feed
        if data_feed == "master_data_calculated_business_unit":
            var_sk = "bu_sk"
        elif data_feed in [ "master_data_calculated_brand", "master_data_calculated_brand_position", "master_data_calculated_business_unit", "master_data_calculated_company", 
                            "master_data_calculated_cont_disc_ops","master_data_calculated_customer","master_data_calculated_customer_channel" ,"master_data_calculated_product", ]:
            var_sk = delta_table_silver + "_sk"

        # Add required columns with default values
        if data_feed != "master_data_calculated_cont_disc_ops":

            staging_df = staging_df.withColumns({
                                                var_sk: lit(None).cast(IntegerType()),
                                                "dummy_flag": lit(0).cast(BooleanType()),
                                                "is_active": lit(True).cast(BooleanType()),
                                                "has_data": lit(0).cast(BooleanType()),
                                                "log_id": lit(log_id).cast(IntegerType()),
                                                "updated_date": lit(current_timestamp()),
                                                "created_date": lit(current_timestamp())
                                                })
        else:

            staging_df = staging_df.withColumns({
                                    var_sk: lit(None).cast(IntegerType()),
                                    "is_active": lit(True).cast(BooleanType()),
                                    "has_data": lit(0).cast(BooleanType()),
                                    "log_id": lit(log_id).cast(IntegerType()),
                                    "updated_date": lit(current_timestamp()),
                                    "created_date": lit(current_timestamp())
                                    })
        
        # Rename columns if rename flag is enabled
        if rename:
            staging_df = staging_df.withColumnsRenamed(rename_columns_silver)
            print("column rename using config json")
        
        # Drop excluded columns if specified
        if exclude_columns:
            staging_df = staging_df.drop(*exclude_columns_silver)
        
        # Set key columns for business unit
        key_columns = ["bu_code"] if data_feed == "master_data_calculated_business_unit" else key_columns
        
        # Generate surrogate key for specific data_feeds
        if data_feed not in ["master_data_calculated_cont_disc_ops",'master_data_calculated_business_unit'] and data_feed in [ "master_data_calculated_brand",
                            "master_data_calculated_brand_position", 
                            "master_data_calculated_company", "master_data_calculated_customer", 
                            "master_data_calculated_customer_channel" ,"master_data_calculated_product", ]:
            
            staging_df = generate_surrogate_key(staging_df, key_columns, "surrogate_key")
            key_columns = ["surrogate_key"]
            
        # Merge staging and filtered target data, removing duplicates
        staging_df = staging_df.unionByName(filtered_tgt_df).dropDuplicates()

    # Process non-calculated data feeds
    if data_feed in ["master_data_business_unit_mu", "master_data_business_unit_sc", "master_data_product",
                    "master_data_brand_position", "master_data_company", "master_data_customer", "master_data_company"]:

        # Check if silver table exists
        if spark.catalog.tableExists(f"{uc_catalog_name}.{delta_db_silver}.{delta_table_silver}"):
            
            # Filter calculated and local active records from target table
            filtered_calc_df = spark.table(target_table).filter(
                (lower(col("source")).like("%calculated%")) |
                ((lower(col("source")).like("%local%")) & (col("is_active") == True)))
            
            # If any calculated records exist, merge them into staging_df
            if filtered_calc_df.count() > 0:
                print("merging the calculated data")
                staging_df = staging_df.unionByName(filtered_calc_df).dropDuplicates()
        else:
            print(f"Table '{uc_catalog_name}.{delta_db_silver}.{delta_table_silver}' does not exist.")  

except Exception as e:
    # Capture and log the error
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Failed in calculated record processing", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e
else:
    # Log successful completion of calculated record processing
    counter += 1
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "calculated records joined silver table " + data_feed, datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Market 
# MAGIC
# MAGIC - The below code is for market stream, same product target table records will be laoded for product but it will load records based key column lowest code not on combination of surrogate key. 
# MAGIC - Same like `finance`key column checks and surrogate key logic will be created 

# COMMAND ----------

# MAGIC %md
# MAGIC Creating PCAT staging

# COMMAND ----------

try:
    if data_feed in ["master_data_pcat_hierarchy"]:

        # Check if the bronze table exists
        if not delta_table_exists(spark, delta_path_staging):
            raise Exception(f"Bronze table does not exist in the file location {delta_path_staging}. Please create the bronze table first.")

        # Load data from the bronze table and select specified columns
        staging_df = spark.table(source_table).select(select_col_silver.split(","))
        
        # Remove duplicate rows from the staging DataFrame
        staging_df = staging_df.dropDuplicates()
        
        # Filter out rows where product_form_code is "NA"
        staging_df = staging_df.filter(col("product_form_code") != "NA")

        ##################################################################################
        # ## ADDING change to replace _ to - in item codes

        hierarchy_list = ["total_global_category_code", "division_code", "category_group_code", "sub_division2code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]

        temp_staging = staging_df

        for hierarchy in hierarchy_list:
          temp_staging = temp_staging.withColumn(
           hierarchy,
          when(col(hierarchy).contains("_"), regexp_replace(col(hierarchy), "_", "-")).otherwise(col(hierarchy))
        )
         
        staging_df = temp_staging

        ##################################################################################

        # Debugging: Log if the bronze table exists
        if debug_flag == "1":
            print(f"Bronze table exists at {delta_path_staging}")

        # Define the surrogate key column name
        var_sk = delta_table_silver + "_sk"

        # Rename columns if renaming configuration is provided
        if rename:
            staging_df = staging_df.withColumnsRenamed(rename_columns_silver)
            print("column rename using config json")

        # Drop specified columns if exclusion is configured
        if exclude_columns:
            staging_df = staging_df.drop(*exclude_columns_silver)

        # Check if key_columns exist and validate for null or empty values
        if key_columns:
            null_key_columns = [ col for col in key_columns 
                                if staging_df.filter((staging_df[col].isNull()) | (trim(staging_df[col]) == "")).count() > 0 ]

            # Raise an exception if any key columns contain null or empty values
            if null_key_columns:
                raise Exception(f"Key columns contain null or empty values: {null_key_columns}")

            # Debugging: Log validation status of key columns
            if debug_flag == "1":
                print("key_columns does not have null values")
        else:
            # Raise an exception if key_columns list is empty
            raise Exception("key_columns is empty")

        # Generate surrogate keys for the staging DataFrame
        staging_df1 = generate_surrogate_key(staging_df, key_columns, "surrogate_key")

        # Add required metadata columns to the staging DataFrame
        staging_df = ( staging_df1.withColumn("is_active", lit(True).cast(BooleanType()))
                                    .withColumn(var_sk, lit(None).cast(IntegerType()))
                                    .withColumn("updated_date", lit(current_timestamp()))
                                    .withColumn("created_date", lit(current_timestamp()))
                                    .withColumn("has_data", lit(0).cast(BooleanType()))
                                    .withColumn("dummy_flag", lit(False).cast(BooleanType()))
                                    .withColumn("log_id", lit(log_id).cast(LongType()))
                                    .withColumn("source", lit("Market")))
        
        ## ADDING source logic

        staging_df = staging_df.withColumn("source", when(col('category_group_subscriber_name').like("%INANCE%MARKETING%"), lit("Finance, Market")).otherwise(lit("Market"))).drop('category_group_subscriber_name')


except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in silver pcat hierarchy", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Silver Table Creation
# MAGIC - Below code create the silver table as per the structing in dataframe but it will reorder the dataframe as per below format
# MAGIC - It wll create new dummy record `-1` if table is not created or if table doesnot have `-1` record

# COMMAND ----------

try:
    # Check if specific columns exist in the DataFrame
    surrogate_key_exists = 'surrogate_key' in staging_df.columns
    source_key_exists    = 'source' in staging_df.columns
    dummy_flag_exists    = 'dummy_flag' in staging_df.columns

    # Define the bronze columns, excluding specified columns
    bronze_columns = [ col for col in staging_df.columns
        if col not in [var_sk, 'log_id', 'created_date', 'is_active', 'has_data', 'updated_date', 'surrogate_key', 'dummy_flag', 'source']]

    # Define additional columns to include in the final DataFrame
    bronze_columns_temp = ['is_active', 'has_data', 'log_id', 'created_date', 'updated_date']

    # Add conditional columns to the temporary list if they exist
    if dummy_flag_exists:
        bronze_columns_temp = ['dummy_flag'] + bronze_columns_temp
    if surrogate_key_exists:
        bronze_columns_temp = ['surrogate_key'] + bronze_columns_temp
    if source_key_exists:
        bronze_columns_temp = ['source'] + bronze_columns_temp

    # Select the final set of columns for the staging DataFrame
    staging_df = staging_df.select([var_sk] + bronze_columns + bronze_columns_temp)

    # Capture columns and schema for SQL insert
    sql_insert_columns = staging_df.columns
    sql_insert_schema = staging_df.dtypes

    # Process the staging data for silver table updates
    process_staging_data( staging_df, var_sk, catalog_name, delta_db_silver, delta_table_silver, delta_path_silver, object_owner_spn, debug_flag )

    # Insert a dummy record if required
    insert_dummy_record_if_needed( spark, catalog_name, delta_db_silver, delta_table_silver, var_sk )

    # Debugging: Display columns, schema, and DataFrame in debug mode
    if debug_flag == "1":
        staging_df.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in silver table creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e


# COMMAND ----------

# MAGIC %md
# MAGIC #### Sk creation
# MAGIC - Below code checks any records in staging table is present in target table if not it will consider as new record, it will gemerate new sk for that records.
# MAGIC - SK creation starts from Max=0 if it is new table, else it will take max count of target table then it will increment by 1
# MAGIC - SK creation will skip records ==`-1`

# COMMAND ----------

try:
    # Define the target table and load it into a DataFrame
    df_target_table  = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"
    target_df        = spark.table(df_target_table)
    print("Target table existing record count:", target_df.count())

    # Identify new records from the source
    target_df_columns = target_df.columns
    new_record_df     = staging_df.join(target_df, on=key_columns, how='left_anti').select(*target_df_columns)
    print("New records from source count:", new_record_df.count())

    # Filter matching records from the source
    new_staging_columns  = new_record_df.columns
    new_staging          = staging_df.join(new_record_df, on=key_columns, how='left_anti').select(*new_staging_columns)
    print("Filtered matching records from source count with or without new values:", new_staging.count())
    
    # Get the maximum surrogate key value from the target table
    max_result = spark.sql(f"SELECT MAX({var_sk}) FROM {catalog_name}.{delta_db_silver}.{delta_table_silver} where {var_sk} <> -1").first()[0]

    # Set max_value to 0 if max_result is None
    max_value = 0 if max_result is None else max_result 
    print("Max value:", max_value)

    # Assign new surrogate keys to the new records
    window           = Window.orderBy(lit(1)).partitionBy(lit(1))
    new_record_df    = new_record_df.withColumn(var_sk, new_record_df[var_sk].cast(IntegerType()))
    new_record_df2   = new_record_df.withColumn(var_sk, row_number().over(window) + max_value)

    if debug_flag == "1":
        if new_record_df.count() > 0:
            print("printing new_record_df2")
            new_record_df2.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in filtering new records", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ###Write into Silver Delta Path
# MAGIC
# MAGIC - The below code insert data into silver table based on merge condition.
# MAGIC - If any new records comes in it will insert the record, new rcord will be decided based on surrogate key
# MAGIC - If any of the column value changes except key column it will update the record and change the updated date
# MAGIC - If any of the key column value missed in upcoming full loads, it will make active indicator as False
# MAGIC - For few data feeds merge condition on column will be different but process remain the same

# COMMAND ----------

try:
    # Construct the merge condition based on key columns
    merge_condition = " AND ".join( [f"target.{col} = source.{col}" for col in key_columns] )

    # Define the columns for different data feeds
    mu_columns = [  'bu_description', 'mu_code', 'mu_description', 'mu_hier_level_5_code','mu_hier_level_5_description',     
                    'mu_hier_level_4_code','mu_hier_level_4_description','mu_hier_level_3_code', 'mu_hier_level_3_description', 'mu_hier_level_2_code','mu_hier_level_2_description',
                    'mu_hier_level_1_code', 'mu_hier_level_1_description', 'mu_hier_level_0_code', 'mu_hier_level_0_description', 'mu_iso_country_code','mu_iso_country_description', 'source', 'dummy_flag', 'has_data', 'log_id', 'created_date'  ]
    
    sc_columns = [  'sc_mu_code', 'sc_mu_description', 'sc_level_6_code', 'sc_level_6_description', 'sc_level_5_code',               
                    'sc_level_5_description', 'sc_level_4_code', 'sc_level_4_description', 'sc_level_3_code', 'sc_level_3_description', 'sc_level_2_code', 'sc_level_2_description', 'sc_level_1_code', 'sc_level_1_description', 'sc_level_0_code', 'sc_level_0_description', 'source', 'dummy_flag', 'has_data', 'log_id', 'created_date' ]

    # Load the target Delta table and get the first column
    target_table = DeltaTable.forPath(spark, delta_path_silver)
    first_target_column = target_table.toDF().columns[0]  # First column assumed relevant for merge

    if data_feed == "master_data_business_unit_mu":
        new_columns = [col for col in mu_columns if col not in [var_sk, "is_active", "updated_date"]]
    elif data_feed == "master_data_business_unit_sc":
        new_columns = [col for col in sc_columns if col not in [var_sk, "is_active", "updated_date"]]
    elif data_feed == "master_data_pcat_hierarchy":
        new_columns = [col for col in sql_insert_columns if col == "source"]
        new_columns1 = [col for col in sql_insert_columns if col not in [var_sk, "is_active", "updated_date"]]
    elif data_feed == "master_data_product_category":
        new_columns = [col for col in sql_insert_columns if col not in [var_sk, "is_active", "updated_date","source"]]
    else:
        new_columns = [col for col in sql_insert_columns if col not in [var_sk, "is_active", "updated_date"]]

    # Ensure all necessary columns are present in the source DataFrame
    source_df = new_staging.unionByName(new_record_df2)

    for col in target_table.toDF().columns:
        if col not in source_df.columns:
            source_df = source_df.withColumn(col, lit(None).cast("String"))

    if data_feed == "master_data_business_unit_sc":
        check_condition = " OR ".join([
            f"(target.{col} != source.{col}) OR "
            f"(target.{col} IS NULL AND source.{col} IS NOT NULL) OR "
            f"(target.{col} IS NOT NULL AND source.{col} IS NULL)"
            for col in sc_columns
        ])
        check_condition_notMatchedBySource = f"target.sc_mu_code IS NOT NULL"
    elif data_feed == "master_data_business_unit_mu":
        check_condition = " OR ".join([
            f"(target.{col} != source.{col}) OR "
            f"(target.{col} IS NULL AND source.{col} IS NOT NULL) OR "
            f"(target.{col} IS NOT NULL AND source.{col} IS NULL)"
            for col in mu_columns
        ])
        check_condition_notMatchedBySource = f"target.mu_code IS NOT NULL"

    elif data_feed == "master_data_pcat_hierarchy":
        # Market Source Condition for specific data feed
        new_staging = new_staging.withColumn("source", lit("Finance, Market"))
        source_df = new_staging.unionByName(new_record_df2)
        check_condition = "target.source = 'Finance' OR target.source = 'Finance, Market'"
        check_condition1 = "target.source = 'Market'"
        check_condition_notMatchedBySource = False

    elif data_feed =="master_data_product_category": 
        check_condition = " OR ".join([ f"(target.{col} != source.{col}) OR "
                                        f"(target.{col} IS NULL AND source.{col} IS NOT NULL) OR "
                                        f"(target.{col} IS NOT NULL AND source.{col} IS NULL)"
                                        for col in sql_insert_columns
                                        if col not in ["log_id", "created_date", var_sk, "is_active", "updated_date","source"] + key_columns ])
        check_condition_notMatchedBySource = f"(target.source!='Market')"
    else:
        check_condition = " OR ".join([ f"(target.{col} != source.{col}) OR "
                                        f"(target.{col} IS NULL AND source.{col} IS NOT NULL) OR "
                                        f"(target.{col} IS NOT NULL AND source.{col} IS NULL)"
                                        for col in sql_insert_columns
                                        if col not in ["log_id", "created_date", var_sk, "is_active", "updated_date"] + key_columns ] )
        check_condition_notMatchedBySource = True

    # Perform the merge operation with the specified conditions
    target_table.alias("target").merge(
        source_df.alias("source"), merge_condition
    ).whenMatchedUpdate(
        condition=f"target.is_active = False AND target.{first_target_column} != -1",  
        set={**{f"{col}": f"source.{col}" for col in new_columns}, "is_active": "True", "updated_date": current_timestamp()},
    ).whenMatchedUpdate(
        condition=f"target.is_active = True AND ({check_condition}) AND target.{first_target_column} != -1",  
        set={**{f"{col}": f"source.{col}" for col in new_columns}, "updated_date": current_timestamp()},
    ).whenNotMatchedInsert(
        values={**{col: f"source.{col}" for col in sql_insert_columns}, "is_active": "True", "updated_date": current_timestamp()},
    ).whenNotMatchedBySourceUpdate(
        condition=f"target.is_active = True AND({check_condition_notMatchedBySource}) AND target.{first_target_column} != -1", 
        set={"is_active": "False", "updated_date": current_timestamp()},
    ).execute()

    print("Merge operation completed successfully")
    
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in silver merge operation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e
else:
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Silver merge operation completed"+ data_feed, datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "") 

# COMMAND ----------

# MAGIC %md
# MAGIC ####Creating Cross Functional Mapping Table

# COMMAND ----------

# MAGIC %md
# MAGIC Function for creating mapping table

# COMMAND ----------

def create_mapping_table(source_table, bronze_product):
    schema = StructType([
    StructField('pcat_pccode', StringType(), True),
    StructField('pcat_description', StringType(), True),
    StructField('pcat_level', IntegerType(), True)
    ])

    schema1 = StructType([
    StructField('gcad_pccode', StringType(), True),
    StructField('gcad_description', StringType(), True),
    StructField('gcad_level', IntegerType(), True)
    ])

    hierarchy_list_gcad_code = ["total_unilever_by_product_category_code", "legacy_division_code", "division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]

    hierarchy_list_gcad_description = ["total_unilever_by_product_category_description", "legacy_division_description", "division_description", "sub_division_2_description", "category_description", "market_description", "sector_description", "sub_sector_description", "segment_description", "product_form_description"]

    hierarchy_list_pcat_code = ["total_global_category_code", "division_code", "category_group_code", "sub_division2code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]

    hierarchy_list_pcat_description = ['total_global_category_name', 'division_name', 'category_group_name', 'sub_division2name', 'category_name', 'market_name', 'sector_name', 'sub_sector_name', 'segment_name', 'product_form_name']
                    
    df_pcat = spark.table(source_table).select(
        [x for x in hierarchy_list_pcat_code] + [x for x in hierarchy_list_pcat_description])

    df_gcad = spark.table(bronze_product).select(
        [x for x in hierarchy_list_gcad_code] + [x for x in hierarchy_list_gcad_description])

    df_pcat_target = spark.createDataFrame([], schema)
    df_gcad_target = spark.createDataFrame([], schema1)

    for i in range(0, len(hierarchy_list_pcat_code)) :
        df_pcat_union = df_pcat.select(df_pcat[hierarchy_list_pcat_code[i]].alias("pcat_pccode")
                                    , df_pcat[hierarchy_list_pcat_description[i]].alias("pcat_description")).dropDuplicates()
        df_pcat_union = df_pcat_union.withColumn("pcat_level", lit(i+1))
        df_pcat_target = df_pcat_target.union(df_pcat_union)
        
        df_gcad_union = df_gcad.select(df_gcad[hierarchy_list_gcad_code[i]].alias("gcad_pccode")
                                    , df_gcad[hierarchy_list_gcad_description[i]].alias("gcad_description")).dropDuplicates()
        df_gcad_union = df_gcad_union.withColumn("gcad_level", lit(i+1))
        df_gcad_target = df_gcad_target.union(df_gcad_union)
        
    df_final = df_gcad_target.join(df_pcat_target, df_gcad_target["gcad_pccode"] == df_pcat_target["pcat_pccode"], "inner")

    # Writing the mapping table to catalog

    cross_func_map_table = 'cross_functional_mapping_description'
    delta_path_cross_silver = delta_path_silver.replace("product_category", cross_func_map_table)
    concurrent_external_table_delta_write(
                    df_final, delta_path_cross_silver, delta_db_silver, cross_func_map_table, '', catalog_name,
                    object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full"
            )
    return df_final



# COMMAND ----------

# ## ADDING CODE to create mapping table

if data_feed in ["master_data_pcat_hierarchy","master_data_product_category"]:
    bronze_product = f"{catalog_name}.{delta_db_staging}.product"
    mapping_df = create_mapping_table(source_table, bronze_product)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Descendant Silver Master Data Transformation
# MAGIC - The below code joins with bronze descendant table child chode with silver table with lowest code to get `SK` for each child code. 
# MAGIC - Join only finance data not with any local or calculated data
# MAGIC - These codes will not work for all data feed only particular data feed

# COMMAND ----------

try:
    # Define the data_feed_mapping to map data_feed values to their respective dimensions
    data_feed_mapping = { "master_data_business_unit_mu": "mu", "master_data_business_unit_sc": "sc", "master_data_product_category": "pcat",
                          "master_data_brand_position": "brand_position", "master_data_brand": "brand",
                          "master_data_customer_channel": "customer_channel", "master_data_customer": "customer","master_data_company": "company" }

    # Define the target table path
    target_table = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"

    # Set key_column and query target table based on the specific data_feed
    if data_feed == "master_data_product_category":
        key_column = 'product_form_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE is_active='True' AND source LIKE '%Finance%'")

    elif data_feed == "master_data_customer":
        key_column = 'global_customer_finance_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE  is_active='True' and source IN ('Finance, Market')")

    elif data_feed == "master_data_customer_channel":
        key_column = 'sub_format_channel_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE is_active='True' and source IN ('Finance, Market')")

    elif data_feed == "master_data_brand":
        key_column = 'corporate_brand_code'
        tgt_df = spark.sql(f'SELECT * FROM {target_table}')

    elif data_feed == "master_data_brand_position":
        key_column = 'brand_position_default_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} where is_active='True' and source IN ('Finance, Market')")

    elif data_feed == "master_data_business_unit_mu":
        key_column = 'bu_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE is_active='True' and source IN ('Finance, Market') ")

    elif data_feed == "master_data_business_unit_sc":
        key_column = 'bu_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE is_active='True' and source IN ('Finance, Market') ")

    elif data_feed == "master_data_company":
        key_column = 'legal_entity_code'
        tgt_df = spark.sql(f"SELECT * FROM {target_table} WHERE is_active='True' and source IN ('Finance') ")
    
    # Check if the data_feed is in the mapping
    if data_feed in data_feed_mapping:
        # Get the corresponding dimension value from the mapping
        dimension_value = data_feed_mapping.get(data_feed)

        print(dimension_value)

        # Fetch the descendant_df for joining
        descendant_df = spark.sql(f"SELECT * FROM {catalog_name}.bronze_master_data.dim_descendant")

        # Get the first column name dynamically from target table
        first_target_column = tgt_df.columns[0]

        print(first_target_column)
        print(key_column)

        # Define the join condition based on descendant and target data
        join_condition = ( (descendant_df["descendant"].isNotNull() & (tgt_df[key_column] == descendant_df["descendant"])) |
                            (descendant_df["descendant"].isNull() & (tgt_df[key_column] == descendant_df["child_code"])))

        # Apply the 'dimension' filter from the mapping to the join condition
        joined_df = descendant_df.alias("d").join( tgt_df.alias("t"), join_condition & (descendant_df["dimension"] == dimension_value),'inner' )

        # Select the necessary columns for the result
        result_df = joined_df.select( joined_df[f"t.{first_target_column}"].alias("descendant_sk"), joined_df["d.child_code"],
                                      joined_df["d.parent_code"], joined_df["d.dimension"], joined_df["d.level_num"], joined_df["d.descendant"] )

        # Display the result dataframe
        result_df.display()
        print(result_df.count())

        # Write the final result dataframe to the destination table
        descentant_table_delta_write( result_df, descendant_path_silver, descendant_db_silver, descendant_table_silver, partition_columns=["dimension"], catalog_name=catalog_name, object_owner_spn=object_owner_spn, retry_count=0, overwriteSchema_flag="false", delta_overwrite_mode="full"  )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "silver descendant table write error", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    # Define common parameters
    common_params = {
        "data_feed": data_feed,
        "uc_catalog_name": uc_catalog_name,
        "external_location": external_location,
        "object_owner_spn": object_owner_spn,
        "debug_flag": debug_flag,
        "username": username,
        "run_id": int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get()),
        "job_id": int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    }

    if data_feed in[ "master_data_business_unit_mu","master_data_business_unit_sc","master_data_brand","master_data_brand_position","master_data_customer","master_data_product_category"]:
    
        print("Executing: Descendant child logic...")
        result = dbutils.notebook.run("/Workspace/data_engineering/gold/ifinance/nb_descendant_child_logic", -1, common_params)
 
except Exception as e:
    print(f"Error occurred: {str(e)}")
    raise Exception(f"Parent notebook failed due to child error: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Silver Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
