# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------- |
# MAGIC |   11 Sept 2024     |    Gokul Prasanth          |    Notebook Created |
# MAGIC |   28 Sept 2024     |    Vinod           | Additional function for fact   |
# MAGIC
# MAGIC ## Purpose
# MAGIC This notebook is responsible for doing all the bronze layer ingestion for both masterdata and fact files ingestions
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

import re
import time
import json
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
import pandas as pd
import pyspark.sql
from pyspark.sql import functions as F, Row, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import ( _parse_datatype_string, IntegerType, StringType, TimestampType, 
    FloatType, DoubleType, BooleanType, IntegralType, DateType, StructType, StructField,LongType,DecimalType)
from pyspark.sql.functions import ( col, lit, current_timestamp, desc, row_number, size, replace, to_date, month,  
                year, last, coalesce, trim, concat, regexp_replace, concat_ws, when, monotonically_increasing_id,split)
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

# Remove all widgets
dbutils.widgets.removeAll()

# Create widgets for various parameters
dbutils.widgets.text("data_feed", "")
dbutils.widgets.text("debug_flag", "")
dbutils.widgets.text("external_location", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("object_owner_spn", "")
dbutils.widgets.text("FilePath","")
dbutils.widgets.text("FileName","")
dbutils.widgets.text("etl_name","")
dbutils.widgets.text("user_name","")
dbutils.widgets.text("is_pcat","")
dbutils.widgets.text("log_id","")


# Get the values from the widgets
data_feed           = dbutils.widgets.get("data_feed")
debug_flag          = dbutils.widgets.get("debug_flag")
external_location   = dbutils.widgets.get("external_location")
uc_catalog_name     = dbutils.widgets.get("uc_catalog_name")
object_owner_spn    = dbutils.widgets.get("object_owner_spn")
file_path           = dbutils.widgets.get("FilePath")
file_name           = dbutils.widgets.get("FileName")
etl_name            = dbutils.widgets.get("etl_name")
username            = dbutils.widgets.get("user_name")
log_id              = dbutils.widgets.get("log_id")

# Set the task values for the job
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("file_path", file_path)
dbutils.jobs.taskValues.set("file_name", file_name)
dbutils.jobs.taskValues.set("etl_name", etl_name)
dbutils.jobs.taskValues.set("log_id", log_id)

if dbutils.widgets.get("is_pcat") == 'true':
    data_feed        = "master_data_pcat_hierarchy"

# Masters Feed
if not "_fact_" in data_feed:
    dbutils.widgets.text("processing_file_path", "")
    processing_file_path = dbutils.widgets.get("processing_file_path")
    dbutils.jobs.taskValues.set("processing_file_path", processing_file_path)
    dbutils.jobs.taskValues.set("username", username)

# Fact Feed
if "_fact_" in data_feed:
    dbutils.widgets.text("email_user","")
    username  = dbutils.widgets.get("email_user")
    dbutils.jobs.taskValues.set("username", username)

# COMMAND ----------

# MAGIC %md
# MAGIC **Check if needed to run**

# COMMAND ----------

if data_feed in ['market_fact_finance_actual','market_fact_bw_usg']:
    dbutils.notebook.exit("No bronze notebook for this feed") 

# COMMAND ----------

##Added only for PnL Manual file load
if data_feed in ['finance_fact_pnl','finance_fact_pnl_customer','finance_fact_offline_data','finance_fact_gmva_data','finance_fact_tax_actuals','finance_fact_tax_forecast','finance_fact_twc_data']:

    dbutils.widgets.text("processing_file_path", "")
    processing_file_path = dbutils.widgets.get("processing_file_path")

    import os
    file_name = os.path.basename(processing_file_path)
    directory = os.path.dirname(processing_file_path)

    file_path = 'unilever/' + directory.split('/', 3)[-1]

    if debug_flag == "1":
        print (f" file : {file_name}")
        print (f" directory : {directory}")
        print (f" file_path : {file_path}")



# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())

    run_id = int(log_id)

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# INSERT / UPDATE AUDIT LOG TABLES
counter = 1
log_value = run_id + 1
detail_log_value = (log_value * 10) 

insert_job(job_id, run_id, username, data_feed+' ingestion', datetime.now(), None, status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_log(log_value, job_id, run_id, username,"Ifinance bronze Ingestion", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, f"Raw to Bronze Staging layer ingestion for {data_feed}", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the bronze ingestion configurations data which are necessarry for ingestion by datafeed
# MAGIC - ingestion_configuration_sheet    - Excel data
# MAGIC - master_table_metadata_file       - Json data
# MAGIC - finance__table_metadata_file     - Json data

# COMMAND ----------

try:

    # Fetch parameters from the ingestion sheet
    param           = get_param_data(uc_catalog_name)

    # Fetch specific configurations for the given data feed
    process_feed_df = fetch_config(param, data_feed)

    # Display the filtered data for debugging purposes
    display(process_feed_df)

    if "_fact_" in data_feed and all(cond not in data_feed for cond in ["finance_fact_pnl","finance_fact_pnl_customer","finance_fact_offline_data","finance_fact_gmva_data","finance_fact_tax_actuals","finance_fact_tax_forecast","finance_fact_twc_data"]):
        processing_file_path = absolute_path + file_path + "/" + file_name

    processing_file_path     = processing_file_path.replace("unilever/", "")
    
    dbutils.jobs.taskValues.set("processing_file_path", processing_file_path)

    # Validates the file extension and assigns the source type accordingly.
    if processing_file_path.endswith(".xlsx"):
        source_type = "excel"
    elif processing_file_path.endswith(".csv"):
        source_type = "csv"
    else:
        # Raise an exception for unsupported file types
        raise Exception("File extension is invalid")
    
    # Extract configuration details from the process feed and Fetch specific configuration values
    catalog_name                                = uc_catalog_name
    cell_reference                              = process_feed_df.select("cell_reference").first()[0]
    dataqualityindicator                        = process_feed_df.select(col('data_quality_check')).collect()[0][0]
    delta_db_staging                            = process_feed_df.select("delta_db_staging").first()[0]
    delta_path_staging                          = absolute_path + process_feed_df.select("delta_path_staging").first()[0]
    delta_staging_partitionBy_value             = process_feed_df.select("delta_staging_partitionBy").first()[0]
    delta_table_staging                         = process_feed_df.select("delta_table_staging").first()[0]

    # Additional configurations based on source type
    if source_type == "csv":
        delimiter_type = process_feed_df.select("delimiter_type").first()[0]
    else:
        delimiter_type = None

    data_flatter            = process_feed_df.select("data_flatter").first()[0]
    header                  = process_feed_df.select("headers").first()[0]
    inferschema_indicator   = process_feed_df.select("inferschema").first()[0]
    ingestion_type          = process_feed_df.select("ingestion_type").first()[0]
    sheet_name              = process_feed_df.select("sheet_name").first()[0]
    source_dir_path         = absolute_path + process_feed_df.select("source_file_path").first()[0] + source_type + "/"
    stream                  = process_feed_df.select("stream").first()[0]

    # Initialize default value for duplicate flag
    duplicate_flag = 0

    # Parse partition columns for Delta table
    if delta_staging_partitionBy_value:
        delta_staging_partitionBy = [col.strip() for col in delta_staging_partitionBy_value.split(",")]
    else:
        delta_staging_partitionBy = []

    # Validate and transform 'header' flag
    if (header.lower() == "y") or (header.lower() == "yes"):
        header = "true"
    if (header.lower() == "n") or (header.lower() == "no"):
        header = "false"

    # Load schema from configuration
    config_data = get_config_data(data_feed, catalog_name, stream)

    if not config_data['schema'] and inferschema_indicator == 'Y':
        # Schema is not provided; use schema inference
        inferschema         = True
        schema_indicator    = False
        schemas             = ""
        print("Schema is blank; enabling schema inference.")
    else:
        # Schema is provided in the config JSON
        inferschema         = False
        schema_indicator    = True
        schema_dict         = config_data["schema"]
        schema_str          = ", ".join([f"`{col}` {dtype}" for col, dtype in schema_dict.items()])
        schemas             = _parse_datatype_string(schema_str)
        print("Schema is present in the config JSON.")

    # Retrieve additional column configurations
    key_columns             = config_data.get("key_columns", [])
    overwrite_column_schema = config_data.get("overwrite_column_schema", {})
    exclude_columns         = config_data.get("exclude_columns", "").strip()
    rename_columns          = config_data.get("rename_cols", {})

    # Determine whether column renaming is required
    rename                  = bool(rename_columns)

    # Debugging: Print key variables if debug_flag is enabled
    if debug_flag == "1":
        print(f"Bronze_table_name            : {uc_catalog_name}.{delta_db_staging}.{delta_table_staging}")
        print('data_feed                    :', data_feed)
        print('catalog_name                 :', catalog_name)
        print('cell_reference               :', cell_reference)
        print('dataqualityindicator         :', dataqualityindicator)
        print('delta_db_staging             :', delta_db_staging)
        print('delta_path_staging           :', delta_path_staging)
        print('delta_staging_partitionBy    :', delta_staging_partitionBy)
        print('delta_table_staging          :', delta_table_staging)
        print("delimiter_type               :", delimiter_type)
        print("data_flatter                 :", data_flatter)
        print("exclude_columns              :", exclude_columns)
        print('header                       :', header)
        print('inferschema                  :', inferschema_indicator)
        print('ingestion_type               :', ingestion_type)
        print('key_columns                  :', key_columns)
        print('overwrite_column_schema      :', overwrite_column_schema)
        print('processing_file_path         :', processing_file_path) 
        print('rename_columns               :', rename)
        print('schema_indicator             :', schema_indicator)
        print('sheet_name                   :', sheet_name)
        print('source_dir_path              :', source_dir_path)
        print('source_type                  :', source_type)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "failed in Fetching config file columns", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #####MAIN ORCHESTRATION - Data Processing [Actions & Transformations]
# MAGIC - File Reading
# MAGIC - Selecting Necessary Columns
# MAGIC - Renaming Columns
# MAGIC - Overwrite Schema for Columns
# MAGIC - Dropping Columns
# MAGIC - Dropping Null Rows
# MAGIC - Adding Source Column
# MAGIC - Adding Audit Columns
# MAGIC - Flatten Transformation
# MAGIC - Debugging Information
# MAGIC - Error Handling
# MAGIC
# MAGIC

# COMMAND ----------

try:
    if data_feed == "master_data_calendar":

        file_name   = processing_file_path.split('/')[-1]
        start_year  = int(file_name.split('_')[1])
        end_year    = int(file_name.split('_')[2].split('.')[0])

        start_date = f"{start_year}-01-01"
        end_date   = f"{end_year}-12-31"

        dbutils.jobs.taskValues.set("start_date", start_date)
        dbutils.jobs.taskValues.set("end_date", end_date)

        if debug_flag == "1":   
            print("start_date : ", start_date)
            print("end_date   : ", end_date)

        counter = counter + 1
        update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Ingestion passed to silver calendar Ingestion creation", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
        
        dbutils.notebook.exit("Execution stopped.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter+1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Failed in calendar table passing to silver", datetime.now(), status_failure_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e
    

# COMMAND ----------

#  ----------------------<< DATA PROCESSING [ACTION AND TRANSFORMATION] >>--------------------#
try:

    # FILE PROCESSING : Process the appropriate file type based on the file extension and reading as a dataframe
        
    processing_file_path, processing_file_name = processing_file_check_func(processing_file_path)
    if processing_file_path:
        if source_type == "excel":
            print(f'Processing XLSX file: {processing_file_name}')
            df_read     = read_excel_to_df(processing_file_path, sheet_name, cell_reference, header, schemas, maxByteArraySize='200000000')
        elif source_type == "csv":
            print(f'Processing CSV file: {processing_file_name}')
            df_read     = read_csv_to_df(processing_file_path, header, schemas, delimiter_type)

    # SELECT COLUMNS : selecting column based on config json
    
    if not config_data['select_col'].strip():
        selected_columns_in_df = [f"`{x}`" for x in df_read.columns]
        print("select column taken from df")
    else:
        select_columns = [x.strip() for x in config_data['select_col'].split(',')]
        selected_columns_in_df = [f"`{x}`" if any(c in x for c in [' ', '.', '&', '(', ')']) else x 
                                  for x in select_columns if x in df_read.columns ]

    df_select = df_read.select(*selected_columns_in_df)

    # SELECT COLUMNS: selecting column based on config json
    select_columns          = [x.strip() for x in config_data['select_col'].split(',')] if config_data['select_col'].strip() else df_read.columns
    selected_columns_in_df  = [f"`{x}`" if any(c in x for c in [' ', '.', '&', '(', ')']) else x for x in select_columns if x in df_read.columns]
    df_select               = df_read.select(*selected_columns_in_df)

    # RENAME COLUMNS : Clean and rename columns based on config
    
    if config_data['rename_cols']:
        df_select           = df_select.withColumnsRenamed(rename_columns)

    cleaned_columns_dict    = clean_column_names(df_select.columns)
    df_select               = df_select.withColumnsRenamed(cleaned_columns_dict)
        
    # OVERWRITE SCHEMA: if necessary - Apply the overwrite schema
    if overwrite_column_schema:

        print(f"Overwrite Schema Columns: {overwrite_column_schema}")

        if "_fact_" in data_feed:  # Check if data_feed matches the specified string
            for col_name in df_select.columns:
                if col_name not in overwrite_column_schema:
                    df_select = df_select.withColumn(col_name, col(col_name).cast(DecimalType(36,16)))
        else:
            type_mapping = { 'int': IntegerType(), 'string': StringType(), 'float': FloatType(),
                'timestamp': TimestampType(), 'double': DoubleType()  }
            for col_name, col_type in overwrite_column_schema.items():
                if col_type in type_mapping:
                    df_select = df_select.withColumn(col_name, col(col_name).cast(type_mapping[col_type]))

        print("Overwrite schema completed")
    else:
        print("No schema overwrite needed or overwrite_column_schema is empty")

    #DROP COLUMNS : if necessary
    if exclude_columns:
        exclude_columns = [col.strip() for col in config_data["exclude_columns"].split(",")]
        df_select = df_select.drop(*exclude_columns)
        print("column dropped according to the json")
    else:
        print("No columns dropped in the dataframe")

    #DROP : dropping the unnecassary null rows
    df_final = df_select.dropna(how='all')

    #SOURCE column adding 
    if data_feed in ["master_data_product_category","master_data_company"]:
        df_final = df_final.withColumn("source", lit("Finance"))
    elif 'Gcad' in processing_file_name:
        df_final = df_final.withColumn("source", lit("Finance, Market"))
    elif 'gmi' in processing_file_name:
        df_final = df_final.withColumn("source", lit("Market"))
    else:
        df_final=df_final
        
    df_final = df_final.withColumn("log_id", lit(run_id).cast(LongType())).withColumn("created_date", current_timestamp().cast(TimestampType()))
    

    # FLATTERN TRANFORMATION : if needed
    if data_flatter:
        recs        = process_flatter_transformation(data_feed, df_final)
        df_pandas   = pd.DataFrame.from_dict(recs)
        df_final    = spark.createDataFrame(df_pandas)

    if debug_flag == "1":
        print(f"Select_columns                  : {df_select.columns}")
        print(f"Overwrite_column_schema         : {overwrite_column_schema}")
        print(f"Column count with audit columns : {len(df_final.columns)}")
        print(f"Raw file count                  : {df_final.count()}")
        print(f"cleaned_columns_dict            : {cleaned_columns_dict}")
        display(df_final)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter+1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Failed in Fetching config file columns", datetime.now(), status_failure_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else:
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "File read and processing completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Data Quality
# MAGIC - Duplicate check 

# COMMAND ----------

#  DATA QUALITY CHECK [null and duplicate check]
if "_fact_" not in data_feed: 
    try:
        # Check For Row Level Duplicates
        if dataqualityindicator.lower() == 'y' or dataqualityindicator.lower() == 'yes':
            
            duplicates = df_final.groupBy(df_final.columns).agg(F.count("*").alias("count")).filter("count > 1").drop("count")

            if duplicates.count() > 0:
                duplicate_flag = 1
                print("Data Quality checks found duplicates at row level")
                raise Exception("Data Quality checks found duplicates at row level")
            else:
                print("No data quality issues found")

    except Exception as e:
        error = str(e).replace("'","")
        error_code = type(e).__name__
        counter = counter+1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
        update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Data duplication process check failed", datetime.now(), status_failure_id, feed_type_id, feed_id, module_id, 0, "duplication error",uc_catalog_name, error)
        raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write into Bronze Staging Delta path
# MAGIC This function responsible 
# MAGIC - Ingestion type
# MAGIC - Table creation for specific DB
# MAGIC - Concurrent delta write
# MAGIC - Table schema check and raise exception

# COMMAND ----------

try:
# Perform a concurrent write operation to the Delta table
    concurrent_external_table_delta_write( df_final, delta_path_staging,delta_db_staging, delta_table_staging, delta_staging_partitionBy, catalog_name, object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode=ingestion_type )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter+1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Failed in Bronze Delta write operation", datetime.now(), status_failure_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise error
else:
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Delta Write operation completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Moving the processed file to Archieve

# COMMAND ----------

try:
    archive_file_path = move_to_archive(processing_file_path, log_id, debug_flag, data_feed)

    dbutils.jobs.taskValues.set("archive_file_path", archive_file_path)

    # Print debug information if debug_flag is set
    if debug_flag == "1":
        print(f"File moved to archive path: {archive_file_path}\n")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Moved to archieve after completing delta write", datetime.now(), status_failure_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####Ingestion completed Audit Entry

# COMMAND ----------

counter = counter + 1
if "master_data" in data_feed:
    update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Bronze Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
