# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   10 FEB 2024     |    Gokul Prasanth          |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC This notebook is responsible for doing reconciliation for raw to bronze data
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - uc_catalog    : uc_Catalog_varies for environment to environment 
# MAGIC
# MAGIC ### Output
# MAGIC Data will be used to identity the difference between bronze and gold data
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import json
import re
from pyspark.sql.types import (DecimalType, _parse_datatype_string)
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

data_feed         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
external_location = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
object_owner_spn  = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
debug_flag        = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
username          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
archive_file_path = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="archive_file_path")
log_id            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("archive_file_path", archive_file_path)
dbutils.jobs.taskValues.set("log_id", log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = "nb_pmrs_common_bronze_Ingestion"

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    run_id = int(log_id)

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# INSERT / UPDATE AUDIT LOG TABLES
counter = 1
log_value = run_id + 1
detail_log_value = (log_value * 10) 

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, f"Raw and bronze recon for {data_feed}", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Read Config Metadata Params

# COMMAND ----------

try:
    # Fetch parameters from the ingestion sheet
    param = get_param_data(uc_catalog_name)
    process_feed_df = fetch_config(param, data_feed)

    # Extract configuration values efficiently
    config_row                      = process_feed_df.first()
    delta_db_staging                = config_row["delta_db_staging"]
    delta_path_staging              = absolute_path + config_row["delta_path_staging"]
    delta_staging_partitionBy_value = config_row["delta_staging_partitionBy"]
    delta_table_staging             = config_row["delta_table_staging"]
    stream                          = config_row["stream"]
    delimiter_type                  = config_row["delimiter_type"]
    header                          = bool(config_row["headers"])  # Convert to boolean directly
    inferschema_indicator           = config_row["inferschema"]

    config_data = get_config_data(data_feed, uc_catalog_name, stream)

    raw_select_columns      = config_data.get("select_col", "")
    rename_columns          = config_data.get("rename_cols", {})
    overwrite_schema        = set(config_data.get("overwrite_column_schema", []))

    # Print all fetched values
    print(f"delta_db_staging                 : {delta_db_staging}")
    print(f"delta_path_staging               : {delta_path_staging}")
    print(f"delta_staging_partitionBy_value  : {delta_staging_partitionBy_value}")
    print(f"delta_table_staging              : {delta_table_staging}")
    print(f"stream                           : {stream}")
    print(f"delimiter_type                   : {delimiter_type}")
    print(f"header                           : {header}")
    print(f"inferschema_indicator            : {inferschema_indicator}")
    print(f"raw_select_columns               : {raw_select_columns}")
    print(f"rename_columns                   : {rename_columns}")
    print(f"overwrite_schema                 : {overwrite_schema}")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "failed while reading data from bronze", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####Raw file check

# COMMAND ----------

# Validates the file extension and assigns the source type accordingly.
if archive_file_path.endswith(".xlsx"):
    source_type = "excel"
elif archive_file_path.endswith(".csv"):
    source_type = "csv"
else:
    # Raise an exception for unsupported file types
    raise Exception("File extension is invalid")

# COMMAND ----------

try:
    if source_type == "csv":
        # Read raw CSV file
        df_raw_file       = spark.read.csv(archive_file_path, header=header, sep=delimiter_type, inferSchema=True)

    if source_type == "excel":

        #data_flatter            = process_feed_df.select("data_flatter").first()[0]
        catalog_name            = uc_catalog_name
        cell_reference          = process_feed_df.select("cell_reference").first()[0]
        header                  = process_feed_df.select("headers").first()[0]
        inferschema_indicator   = process_feed_df.select("inferschema").first()[0]
        ingestion_type          = process_feed_df.select("ingestion_type").first()[0]
        sheet_name              = process_feed_df.select("sheet_name").first()[0]
        stream                  = process_feed_df.select("stream").first()[0]

        # Validate and transform 'header' flag
        if (header.lower() == "y") or (header.lower() == "yes"):
            header = "true"
        if (header.lower() == "n") or (header.lower() == "no"):
            header = "false"

        # Load schema from configuration
        config_data = get_config_data(data_feed, catalog_name, stream)

        if not config_data['schema'] and inferschema_indicator == 'Y':
        # Schema is not provided; use schema inference
            inferschema         = True
            schema_indicator    = False
            schemas             = ""
            print("Schema is blank; enabling schema inference.")
        else:
            # Schema is provided in the config JSON
            inferschema         = False
            schema_indicator    = True
            schema_dict         = config_data["schema"]
            schema_str          = ", ".join([f"`{col}` {dtype}" for col, dtype in schema_dict.items()])
            schemas             = _parse_datatype_string(schema_str)
            print("Schema is present in the config JSON.")

        df_raw_file     = read_excel_to_df(archive_file_path, sheet_name, cell_reference, header, schemas, maxByteArraySize='200000000')

    display(df_raw_file)

    # Select relevant columns, handling spaces & special characters
    select_columns         = [x.strip() for x in raw_select_columns.split(',')] if raw_select_columns.strip() else df_raw_file.columns
    selected_columns_in_df = [f"`{x}`" if any(c in x for c in [' ', '.', '&', '(', ')']) else x for x in select_columns if x in df_raw_file.columns]

    df_select = df_raw_file.select(*selected_columns_in_df)
    
    # Apply renaming efficiently
    df_select             = df_select.withColumnsRenamed(rename_columns)
    cleaned_columns_dict  = clean_column_names(df_select.columns)
    df_select             = df_select.withColumnsRenamed(cleaned_columns_dict)

    # Apply type casting only where needed
    for col_name in df_select.columns:
        if col_name not in overwrite_schema:
            df_select = df_select.withColumn(col_name, col(col_name).cast(DecimalType(38, 16)))

    # Drop empty rows and order
    if data_feed in ['finance_fact_tax_actuals','finance_fact_tax_forecast']:
        df_raw_final = df_select.dropna(how='all').orderBy("company")
    else:
        df_raw_final = df_select.dropna(how='all').orderBy("flow", "product_category")

    if debug_flag == "1":
        # Print the number of columns
        num_columns = len(df_raw_final.columns)
        print(f"Number of columns in df_raw_final: {num_columns}")

        # Print the number of rows
        num_rows   = df_raw_final.count()
        print(f"Number of rows in df_raw_final: {num_rows}")

        df_raw_final.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "failed while reading data from bronze", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####Bronze table check

# COMMAND ----------

try:
    # Read the table
    df_table_read = spark.read.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")

    # Filter the DataFrame using the widget_log_id and drop specified columns
    if data_feed in ['finance_fact_tax_actuals','finance_fact_tax_forecast']:
        df_table_read_final = df_table_read.filter(col("log_id") == log_id).drop('log_id', 'created_date').orderBy("company")

    else:
        df_table_read_final = df_table_read.filter(col("log_id") == log_id).drop('log_id', 'created_date').orderBy("flow", "product_category")

    if debug_flag == "1":
        # Print the number of columns
        num_columns = len(df_table_read_final.columns)
        print(f"Number of columns in df_table_read_final: {num_columns}")

        # Print the number of rows
        df_table_read_final_count = df_table_read_final.count()
        print(f"Number of rows in df_table_read_final: {df_table_read_final_count}")

        df_table_read_final.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "failed in reading and processing the Bronze table", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Raw to Bronze data check and validation

# COMMAND ----------

try:
    mismatch_found = False  # Initialize the flag

    # Validate column count
    if len(df_raw_final.columns) != len(df_table_read_final.columns):
        error_msg = f" Column counts do not match.\n df_raw_file columns: {len(df_raw_final.columns)}\n df_table_read columns: {len(df_table_read_final.columns)}"
        print(error_msg)
        mismatch_found = True

    # Validate row count
    if df_raw_final.count() != df_table_read_final.count():
        error_msg = f" Row counts do not match.\n df_raw_file rows: {df_raw_final.count()}\n df_table_read rows: {df_table_read_final.count()}"
        print(error_msg)
        mismatch_found = True

    # Validate data
    diff1 = df_raw_final.subtract(df_table_read_final)
    diff2 = df_table_read_final.subtract(df_raw_final)

    if diff1.count() > 0 or diff2.count() > 0:
        print(" DataFrames do not match.")
        mismatch_found = True

        if debug_flag == "1":
            print("Rows in df_raw_file not in df_table_read:")
            diff1.display()

            print("Rows in df_table_read not in df_raw_file:")
            diff2.display()

        # Create a combined difference DataFrame
        diff_table_raw = df_raw_final.exceptAll(df_table_read_final).withColumn("Difference", lit("Only in df_raw_file"))
        diff_raw_table = df_table_read_final.exceptAll(df_raw_final).withColumn("Difference", lit("Only in df_table_read"))
        diff_combined  = diff_raw_table.union(diff_table_raw)

        # Show mismatched data if it exists
        if diff_combined.count() > 0:
            print("There is a clear mismatch between source and bronze tables.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    print(f"ERROR: {error}")
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Failed in comparing DataFrames", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e
else:
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Bronze to raw data match successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "Success", uc_catalog_name, "All checks passed.")

    if not mismatch_found:  # Print success message only if no mismatch is found
        print(f"Validation successful: Both DataFrames are identical.")
        print(f"Column Count     : {len(df_raw_final.columns)}     (Matching)")
        print(f"Row Count        : {df_raw_final.count()}     (Matching)")
        print(f"All records match between RAW file and Bronze table.")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Ingestion completed Audit Entry

# COMMAND ----------

counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Bronze Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
