# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 6 Sept 2024        |    Vinod               |    Created View .        |
# MAGIC
# MAGIC ## Purpose
# MAGIC The Purpose of this notebook is to create View for PBI.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Necessory Functions

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, DoubleType
import json

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

debug_flag          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
external_location   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
username            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
file_name           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
log_id              = int(dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id"))


dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = log_id


    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 4
detail_log_value = (log_value * 10) 

insert_job_log(log_value, job_id, run_id, username,"Ifinance view creation", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Gold to view creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### catalog details

# COMMAND ----------

# Using the specified catalog
spark.sql(f"USE CATALOG {uc_catalog_name}")

# Creating the schema if it does not exist
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `gold_finance`;")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Reading the view creation configurations data 
# MAGIC - view creation configuration

# COMMAND ----------

try:

    if 'market' not in data_feed:
        # ------------------Reading the Ingestion_Configuration_sheet-------------------#
        hbu_code = file_name.split('#')[2]
        if "HBU1" in hbu_code:
            dimension_code, fact_type = "mu", "dimension_mu"
        elif "HBU3" in hbu_code:
            dimension_code, fact_type = "sc", "dimension_sc"
        print(f"Dimension Code: {dimension_code}, Fact Type: {fact_type}")
    
    param                     = get_param_data(uc_catalog_name)
    process_feed_df           = fetch_config(param, data_feed)

    gold_db_name                      = process_feed_df.select("delta_db_gold").first()[0]
    if 'market' not in data_feed:
        gold_table_name                   = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'", '"')).get(fact_type)
    else:
        gold_table_name                   = process_feed_df.select("delta_table_gold").first()[0]
    view_name                         = process_feed_df.select("view_name").first()[0]

    if debug_flag == "1":

        print('uc_catalog_name            :', uc_catalog_name)
        print('gold_db_name               :', gold_db_name)
        print('gold_table_name            :', gold_table_name)
        print('view_name                  :', view_name)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the view creation failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md 
# MAGIC ####Delta table check

# COMMAND ----------

def check_table_exists(uc_catalog_name, schema_name, table_name):
    table_exists = spark.catalog.tableExists(f"{uc_catalog_name}.{schema_name}.{table_name}")
    if table_exists:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} exists.")
    else:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")
        raise Exception(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fact **Views**

# COMMAND ----------

try:
    if data_feed == "market_fact_gmi_snapshot" :

        gold_db_name_dict = json.loads(gold_db_name.replace("'",'"'))
        gold_table_name_dict = json.loads(gold_table_name.replace("'",'"'))
        gold_db_name_gmi = gold_db_name_dict[list(gold_db_name_dict.keys())[0]]
        check_table_exists(uc_catalog_name, gold_db_name_gmi, list(gold_table_name_dict.keys())[0])
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name_gmi}.{view_name} AS
                    SELECT
                    bu.DSTCode as `BU SK`,
                    PC.Code as `Source SK`,
                    PC.DstCode as `Product SK`,
                    F.brand_sk as `Brand SK`,
                    F.brand_position_sk as `Brand Position SK`,
                    F.flow_sk as `Flow SK`,
                    F.month_sk as `Month SK`,
                    F.measure_sk as `Measure SK`,
                    F.geography_sk as `Geography SK`,
                    F.manufacturer_sk as `Manufacturer SK`,
                    CAST(CAST(PC.PCFactor AS DECIMAL(38,26)) * 
                    CAST(BU.BUFactor AS DECIMAL(38,26)) * 
                    CAST(F.value AS DECIMAL(38,26)) AS DECIMAL(38,26)) as `Value`,
                    CAST(F.created_date AS TIMESTAMP) AS `Created Date`
                    from
                    {uc_catalog_name}.gold_market.{list(gold_table_name_dict.keys())[0]} as F
                        inner join {uc_catalog_name}.gold_master_data.vw_country_bu_map cbm on F.geography_sk = cbm.`Geography SK`
                    inner join(
                            select 
                            case when mp.source_code_sk is null then BU.bu_sk  else mp.source_code_sk end as Code, 
                            CASE WHEN mp.source_code_sk IS NULL THEN BU.bu_sk  ELSE mp.destination_code_sk END AS DSTCode,
                            CASE WHEN mp.source_code_sk IS NULL THEN 1 ELSE mp.Factor END AS BUFactor
                            from  {uc_catalog_name}.gold_master_data.business_unit BU 
                            left join {uc_catalog_name}.gold_master_data.map_hierarchy mp on BU.bu_sk  = mp.destination_code_sk and mp.dimension in ('mu','sc')
                        ) bu
                        on bu.Code = cbm.`BU SK`

                        inner join(
                            SELECT 
                            CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.source_code_sk END AS Code,
                            CASE WHEN Map.source_code_sk IS NULL THEN PC.product_sk ELSE Map.destination_code_sk END AS DstCode,
                            CASE WHEN Map.source_code_sk IS NULL THEN 1 ELSE MAP.Factor END AS PCFactor
                            FROM {uc_catalog_name}.gold_master_data.product PC
                            LEFT JOIN {uc_catalog_name}.gold_master_data.map_hierarchy MAP 
                            ON PC.product_sk = MAP.destination_code_sk AND MAP.Dimension = 'pcat'
                            where PC.is_active is true 
                        ) AS PC ON PC.Code = F.product_sk
                    """)
        
        print(f"{uc_catalog_name}.{gold_db_name_gmi}.{view_name} view created successfully.")

        # Creating Manufacturer View

        gold_db_name_dict = json.loads(gold_db_name.replace("'",'"'))
        gold_table_name_dict = json.loads(gold_table_name.replace("'",'"'))
        gold_db_name = gold_db_name_dict[list(gold_db_name_dict.keys())[2]]
        gold_table_name = list(gold_table_name_dict.keys())[2]
        view_name_manu = f"vw_{gold_table_name}"
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name_manu} AS
                    SELECT
                        manufacturer_sk AS `Manufacturer SK`,
                        local_manufacturer_code AS `Local Manufacturer Code`,
                        local_manufacturer_name AS `Local Manufacturer Name`,
                        global_manufacturer_code AS `Global Manufacturer Code`,
                        global_manufacturer_name AS `Global Manufacturer Name`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name_manu} view created successfully.")

        # Creating view for pivoted table (measures on column)
        gmi_pivot_table        = list(gold_table_name_dict.keys())[0] + "_pivot"
        gmi_pivot_view         = view_name + "_pivot"
        check_table_exists(uc_catalog_name, gold_db_name_gmi, gmi_pivot_table)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name_gmi}.{gmi_pivot_view} AS
                    SELECT
                    cbm.`BU SK` as `BU SK`,
                    F.product_sk as `Product SK`,
                    F.brand_sk as `Brand SK`,
                    F.brand_position_sk as `Brand Position SK`,
                    F.flow_sk as `Flow SK`,
                    F.month_sk as `Month SK`,
                    F.geography_sk as `Geography SK`,
                    F.manufacturer_sk as `Manufacturer SK`,
                    F.Value as `Value`,
                    F.Volume as `Volume`,
                    CAST(F.created_date AS TIMESTAMP) AS `Created Date`
                    from
                    {uc_catalog_name}.{gold_db_name_gmi}.{gmi_pivot_table} as F
                        inner join {uc_catalog_name}.gold_master_data.vw_country_bu_map cbm on F.geography_sk = cbm.`Geography SK`
                    """)


except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "market_fact_business_winning" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
					SELECT
					cbm.`BU SK` as `BU SK`,
					f.geography_sk as `Geography SK`,
					f.flow_sk as `Flow SK`,
					cast(f.month_sk as int) as `Month SK`,
					f.product_sk as `Product SK`,
					f.turnover as `Turnover`,
					f.Value_gaining_turnover as `Value Gaining Turnover`,
     				f.Volume_gaining_turnover as `Volume Gaining Turnover`,
					f.Value_gaining_turnover_cell as `Gaining Turnover Cell`,
					f.Value_losing_turnover_cell as `Losing Turnover Cell`,
					f.gmi_nongmi_turnover as `Gmi Nongmi`,
					f.gmi_nongmi_gaining_turnover as `Gmi Nongmi Gaining Turnover`,
					f.gmi_nongmi_gaining_turnover_cell as `Gmi Nongmi Gaining Turnover Cell`,
					f.gmi_nongmi_losing_turnover_cell as `Gmi Nongmi Losing Turnover Cell`,
					f.Value_alternative_bps as `Value Alternative Bps`,
					f.Value_mkt_growth as `Value Market Growth`,
     				f.Volume_alternative_bps as `Volume Alternative Bps`,
					f.Volume_mkt_growth as `Volume Market Growth`,
					(cast(f.turnover as DOUBLE) * cast(f.Value_alternative_bps as DOUBLE)) as `Value Turnover Weighted Numerator`,
					(
						cast(f.turnover as DOUBLE) * cast(f.Value_mkt_growth as DOUBLE)
					) as `Value Turnover Weighted Growth Numerator`,
					(cast(f.turnover as DOUBLE) * cast(f.Volume_alternative_bps as DOUBLE)) as `Volume Turnover Weighted Numerator`,
					(
						cast(f.turnover as DOUBLE) * cast(f.Volume_mkt_growth as DOUBLE)
					) as `Volume Turnover Weighted Growth Numerator`,
					f.No_of_cells_gaining As `No Of Cells Gaining`,
					f.No_of_cells_losing As `No Of Cells Losing`,
					(f.No_of_cells_gaining) + (f.No_of_cells_losing) as `Total No of Cells`,
					f.Vol_No_of_cells_gaining As `Vol No Of Cells Gaining`,
					f.Vol_No_of_cells_losing As `Vol No Of Cells Losing`,
					CAST(f.created_date AS TIMESTAMP) AS `Created Date`
					From
						{uc_catalog_name}.{gold_db_name}.{gold_table_name} as f
							inner join {uc_catalog_name}.gold_master_data.vw_country_bu_map cbm
							on F.geography_sk = cbm.`Geography SK`
					Where
						f.month_sk = (
							SELECT
							MAX(month_sk)
							FROM
							{uc_catalog_name}.{gold_db_name}.{gold_table_name}
						)""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "market_fact_bw_usg" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                    f.geography_sk As `Geography SK`,
                    f.product_sk As `Product SK`,
                    f.month_sk As `Month SK`,
                    f.measure_sk As `Measure SK`,
                    f.flow_sk As `Flow SK`,
                    f.value As `Value`,
                    CAST(f.created_date AS TIMESTAMP) AS `Created Date`
					From
					{uc_catalog_name}.{gold_db_name}.{gold_table_name} as f
                    """)
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####View creation completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job(job_id,run_id, module_id, feed_type_id, feed_id, status_success_id,uc_catalog_name)
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact view creation completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
