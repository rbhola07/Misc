# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Market Recon Notebook: Business Winning**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   18 March 2025     |    Ashwini ,Aditya    |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC This notebook is responsible for doing reconciliation for bronze to gold data
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - uc_catalog    : uc_Catalog_varies for environment to environment 
# MAGIC
# MAGIC ### Output
# MAGIC Data will be used to identity the difference between bronze and gold data
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

from pyspark.sql.functions import sum, col, lower, regexp_replace, trim, expr, first, when, format_number,round,instr, lit, regexp_extract
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType, DecimalType, LongType
from pyspark.sql.functions import when, col, concat_ws

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

# getting from parent notebook
external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
username                = dbutils.widgets.get("username")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("run_id")
job_id                  = dbutils.widgets.get("job_id")

# Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]
    if data_feed       == 'market_fact_business_winning':
        current_nb_name = "nb_pmrs_fact_business_winning"
    else:
        print(f"data_feed doesn't exists : {data_feed}")
    
    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fetching the configuration parameters and inputs

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    # Get the ingestion sheet data
    param           = get_param_data(uc_catalog_name)

    # Fetch specific configurations for the given data feed
    process_feed_df = fetch_config(param, data_feed)

    stream = process_feed_df.select("stream").first()[0]

    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    # config_data     = get_config_data(data_feed, uc_catalog_name, 'finance')

    process_feed_df                 = fetch_config(param, data_feed)

        # Display the filtered data
    display(process_feed_df)

    # Extract configuration details from the dataframes
    catalog_name                  = uc_catalog_name
    delta_db_staging              = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging           = process_feed_df.select("delta_table_staging").first()[0]
    delta_db_gold                 = process_feed_df.select("delta_db_gold").first()[0]
    delta_table_gold              = process_feed_df.select("delta_table_gold").first()[0]
    if debug_flag == "1":
        print('data_feed                      :', data_feed)
        print('catalog_name                   :', catalog_name)
        print('delta_db_staging               :', delta_db_staging)
        print('delta_table_staging            :', delta_table_staging)
        print('delta_table_gold               :', delta_table_gold)
        print('delta_db_gold                  :', delta_db_gold)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    raise e


# COMMAND ----------

# Check if required tables exist.
try: 
    tables = {
        "df_descendant" :f"{uc_catalog_name}.gold_master_data.dim_descendant",
        "df_country_bu_map" :f"{uc_catalog_name}.gold_market.vw_country_bu_map",
        "df_flow" : f"{uc_catalog_name}.gold_master_data.flow",
        "df_measure" : f"{uc_catalog_name}.gold_master_data.measure",
        "df_calendar" : f"{uc_catalog_name}.gold_master_data.calendar",
        "df_product" : f"{uc_catalog_name}.gold_master_data.product",
        "df_fact_bronze" : f"{uc_catalog_name}.bronze_market.{delta_table_staging}",
        "df_fact_gold" : f"{uc_catalog_name}.gold_market.{delta_table_staging}",
        "df_master_data_map_cross_pcat": f"{catalog_name}.gold_master_data.vw_cross_functional_mapping_description"}

    for df_name, table in tables.items():
        table_exists =(spark.sql(f"SHOW TABLES IN {catalog_name}.{delta_db_staging}").filter(f"tableName = '{table}'").count() > 0)
        if spark.catalog.tableExists(table):
            globals()[df_name] = spark.table(table) 
            row_count = globals()[df_name].count()
            print(f"Table {table.split('.')[-1]} exists, count: {row_count}")
        else:
            print(f"Table {table.split('.')[-1]} does not exist")

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e



# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

try:

    if  data_feed in ["market_fact_business_winning"]:
        # Step 1: Load the data (assuming DataFrame 'df' is already loaded from the source table)

        df_master_data_map_cross_pcat = df_master_data_map_cross_pcat.withColumn('modified_lookup_description', lower(col('PCAT Description'))).withColumn('description', lower(col('GCAD Description'))).select("description", "modified_lookup_description")

        df_temp_fact = df_fact_bronze.join(df_master_data_map_cross_pcat, df_fact_bronze.category_hierarchy == df_master_data_map_cross_pcat.modified_lookup_description, "left")
    
        df_temp_fact = df_temp_fact.withColumn('category_hierarchy', 
                                           when(col('description').isNull(), 
                                                col('category_hierarchy'))
                                           .otherwise(col('description')))

        df_fact = df_temp_fact.drop("description", "modified_lookup_description")
       
        # Perform aggregation and grouping as done in the BRONZE CTE
        df_bronze = (
            df_fact.filter(col('measure_type')=='value').groupBy(
                concat_ws("_", "country", "category_hierarchy", "period").alias("bw_key1")
            )
            .agg(
                sum("total_turnover").alias("turnover"),
                sum("mat_gaining_turnover").alias("gaining_turnover")
            )
            .orderBy("bw_key1")
        )

    if data_feed in ["market_fact_bw_usg"]:
        df= f"{catalog_name}.{fact_actuals_delta_db_gold}.{fact_actuals_view}"
        
except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

        

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold

# COMMAND ----------

#reverse engineering to extract division description,market description,category description,sector description from the gold table to perform comparison with the bronze table
try:
    if  data_feed in ["market_fact_business_winning"]:

        df_country_bu_map=df_country_bu_map.withColumnRenamed('Geography SK','Geography_SK')

        df_test1=df_fact_gold.join(df_country_bu_map,df_fact_gold.geography_sk==df_country_bu_map.Geography_SK,"inner")\
                            .join(df_flow,df_fact_gold.flow_sk==df_flow.flow_sk,"inner")\
                            .join(df_calendar,df_fact_gold.month_sk==df_calendar.month_sk,"inner")\
                            .join(df_descendant,df_fact_gold.product_sk==df_descendant.descendant_sk,"inner")\
                                
        df_test_div=df_test1.join(df_product,df_test1.child_code==df_product.division_code,"left")\
                            .select(
                                df_test1["*"],
                                df_product.division_description,
                                df_product.division_code
                                ).distinct()\

        df_mark=df_test_div.join(df_product,df_test1.child_code==df_product.market_code,"left")\
                            .select(
                                df_test_div["*"],
                                df_product.market_description,
                                df_product.market_code
                                ).distinct()\
    
        df_cat=df_mark.join(df_product,df_test1.child_code==df_product.category_code,"left")\
                            .select(
                                df_mark["*"],
                                df_product.category_description,
                                df_product.category_code
                                ).distinct()\
                                    
        df_sector=df_cat.join(df_product,df_test1.child_code==df_product.sector_code,"left")\
                            .select(
                                df_cat["*"],
                                df_product.sector_description,
                                df_product.sector_code
                                ).distinct()   


        df_sector = df_sector.withColumn('cat_desc',coalesce(df_sector.division_description,df_sector.market_description,df_sector.category_description,df_sector.sector_description))
            # Perform aggregation and grouping as done in the BRONZE CTE
        df_gold = (
                df_sector.filter(col("flow_description")=='MAT').groupBy(
                    concat_ws("_", "Country Description","cat_desc", "month_short_description").alias("bw_key")
                )
                .agg(
                    sum("turnover").alias("turnover"),
                    sum("Value_gaining_turnover").alias("gaining_turnover")
                )
                .orderBy("bw_key")
            )    

        df_test = df_bronze.join(df_gold, df_gold.bw_key == df_bronze.bw_key1, "inner") \
            .select(df_bronze.bw_key1, df_bronze.turnover.alias("Bronze_Turnover"), df_bronze.gaining_turnover.alias("Bronze_Gaining_Turnover"), df_gold.turnover.alias("Gold_Turnover"), df_gold.gaining_turnover.alias("Gold_Gaining_Turnover"))
        
        df_test = df_test.withColumn("test_validation_turnover", when(df_test.Bronze_Turnover == df_test.Gold_Turnover, 1).otherwise(0))
        df_test = df_test.withColumn("test_validation_gaining_turnover", when(df_test.Bronze_Gaining_Turnover == df_test.Gold_Gaining_Turnover, 1).otherwise(0))
        
        mismatches = df_test.filter((col("test_validation_turnover") == 0)|(col("test_validation_gaining_turnover") == 0))      

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e


# COMMAND ----------

# MAGIC %md
# MAGIC ## Compare Bronze Vs Gold

# COMMAND ----------


# Match key between Bronze and Gold tables and compare the values for turnover and gaining turnover
try:
    
    mismatch_found = False  # Initialize the flag
    
    if mismatches.count() > 0:
        print(f"Mismatch Found for Bronze Vs Gold Layer:")
        mismatches.display()
        mismatch_found = True  # Set flag if mismatch is found
    else:
        print(f"No Mismatch for Bronze Vs Gold Layer:")
        print(f"Recon Successful")
    
    # Raise exception if any mismatch was found
    if mismatch_found:
        raise Exception("Recon Failed")

except Exception as e:
    print(f"An error occurred: {type(e).__name__}: {str(e)}")
    raise e

