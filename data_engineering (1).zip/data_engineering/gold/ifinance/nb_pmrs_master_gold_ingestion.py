# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 08 Nov 2024        |    Gokul / Aurav       |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Ingestion Notebook to ingest the data from silver table and to create the Gold table
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and Gold delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC workflow trigger from webapp
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql import functions as F, Row, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType,LongType
from pyspark.sql.functions import (col, lit, lower, regexp_replace, regexp_extract, trim,current_timestamp, desc, row_number, size, replace, to_date, month,when,year, last, coalesce,expr)
from delta.tables import DeltaTable
import datetime
start_time = datetime.datetime.now()


# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/silver/ifinance/nb_pmrs_common_function"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

#Initialising the values
debug_flag           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
external_location    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
uc_catalog_name      = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
username             = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
log_id               = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

if '_fact_' in data_feed:
    if 'market' in data_feed or data_feed == 'master_data_pcat_hierarchy':
        print('Currently not applicable for Market Stream')
    else:
        key_value    = dbutils.jobs.taskValues.get(taskKey="Bronze_staging_to_silver_ingestion", key="key_value")
        dbutils.jobs.taskValues.set("key_value", key_value)
        print('key_value', key_value)
        print(type(key_value))

dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("log_id", log_id)

dbutils.widgets.text("forecast_data_feed", "master_data_forecast_level")
forecast_data_feed = dbutils.widgets.get("forecast_data_feed")

dbutils.widgets.text("is_pcat","")
if dbutils.widgets.get("is_pcat") == 'true':
    data_feed        = "master_data_pcat_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    # run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = int(log_id)

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 3
detail_log_value = (log_value * 10) 

insert_job_log(log_value, job_id, run_id, username,"Ifinance Gold Master Ingestion", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)


insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Silver to Gold ingestion for "+data_feed, datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the Gold ingestion configurations data which are necessarry for ingestion by datafeed
# MAGIC - ingestion_configuration_sheet    - Excel data
# MAGIC - master_table_metadata_file       - Json data
# MAGIC - finance__table_metadata_file     - Json data

# COMMAND ----------

try:

    # ------------------Reading the Ingestion_Configuration_sheet-------------------#
    param                              = get_param_data(uc_catalog_name)
    process_feed_df                    = fetch_config(param, data_feed)
    forecast_process_feed_df           = fetch_config(param, forecast_data_feed)

    if data_feed == "market_fact_gmi_snapshot":
        catalog_name              = uc_catalog_name
        delta_db_silver           = json.loads(process_feed_df.select("delta_db_silver").first()[0].replace("'",'"'))
        delta_path_silver         = json.loads(process_feed_df.select("delta_path_silver").first()[0].replace("'",'"'))
        delta_table_silver        = json.loads(process_feed_df.select("delta_table_silver").first()[0].replace("'",'"'))
        delta_path_gold           = json.loads(process_feed_df.select("delta_path_gold").first()[0].replace("'",'"'))
        delta_db_gold             = json.loads(process_feed_df.select("delta_db_gold").first()[0].replace("'",'"'))
        delta_table_gold          = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'",'"'))

        delta_db_staging          = process_feed_df.select("delta_db_staging").first()[0]
        delta_path_staging        = process_feed_df.select("delta_path_staging").first()[0]
        delta_table_staging       = process_feed_df.select("delta_table_staging").first()[0]
        source_dir_path           = absolute_path + process_feed_df.select("source_file_path").first()[0]
        delta_gold_partitionBy       = process_feed_df.select("delta_gold_partitionBy").first()[0]
        view_name                 = process_feed_df.select("view_name").first()[0]
        stream                    = process_feed_df.select("stream").first()[0]
        source_table              = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"
        target_table              = f"{catalog_name}.{delta_db_gold}.{delta_table_gold}"
        forecast_delta_db_gold    = '' 
        forecast_delta_table_gold = ''
    else:
        catalog_name                 = uc_catalog_name
        delta_db_silver              = process_feed_df.select("delta_db_silver").first()[0]
        delta_db_staging             = process_feed_df.select("delta_db_staging").first()[0]
        delta_path_silver            = absolute_path + process_feed_df.select("delta_path_silver").first()[0]
        delta_path_staging           = process_feed_df.select("delta_path_staging").first()[0]
        delta_table_silver           = process_feed_df.select("delta_table_silver").first()[0]
        delta_table_staging          = process_feed_df.select("delta_table_staging").first()[0]
        source_dir_path              = absolute_path + process_feed_df.select("source_file_path").first()[0]
        delta_gold_partitionBy       = process_feed_df.select("delta_gold_partitionBy").first()[0]
        delta_path_gold              = absolute_path + process_feed_df.select("delta_path_gold").first()[0]
        delta_db_gold                = process_feed_df.select("delta_db_gold").first()[0]
        delta_table_gold             = process_feed_df.select("delta_table_gold").first()[0]
        forecast_delta_db_gold       = forecast_process_feed_df.select("delta_db_gold").first()[0]
        forecast_delta_table_gold    = forecast_process_feed_df.select("delta_table_gold").first()[0]
        view_name                    = process_feed_df.select("view_name").first()[0]
        stream                       = process_feed_df.select("stream").first()[0]

        source_table                 = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"
        target_table                 = f"{catalog_name}.{delta_db_gold}.{delta_table_gold}"

    if delta_gold_partitionBy:
        delta_gold_partitionBy = [col.strip() for col in delta_gold_partitionBy.split(",")]
    else:
        delta_gold_partitionBy = []

    # ------------------Reading the Table Metadata Json File -----------------------#
    config_data = get_config_data(data_feed,uc_catalog_name,stream)

    key_columns      = config_data.get("key_columns",[])
    overwrite_schema = config_data.get("overwrite_schema",{})
    exclude_columns  = config_data.get("exclude_columns","").strip()

    if debug_flag == "1":

        print('catalog_name                 :', catalog_name)
        print('delta_db_gold                :', delta_db_gold)
        print('delta_db_silver              :', delta_db_silver)
        print('delta_db_staging             :', delta_db_staging)
        print('delta_path_gold              :', delta_path_gold)
        print('delta_path_silver            :', delta_path_silver)
        print('delta_path_staging           :', delta_path_staging)
        print('delta_gold_partitionBy       :', delta_gold_partitionBy)
        print('forecast_delta_db_gold       :', forecast_delta_db_gold)
        print('forecast_delta_table_gold    :', forecast_delta_table_gold)
        print('delta_table_gold             :', delta_table_gold)
        print('delta_table_silver           :', delta_table_silver)
        print('delta_table_staging          :', delta_table_staging)
        print('key_columns                  :', key_columns)
        print('source_dir_path              :', source_dir_path)
        print('source_table                 :', source_table)
        print('target_table                 :', target_table)
        print('view_name                    :', view_name)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the gold ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ##### if datafeed matches silver calendar table creation begins

# COMMAND ----------

from datetime import datetime
try:
    if data_feed == "master_data_calendar":

        # Retrieve start and end date from previous task
        start_date = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="start_date")
        dbutils.jobs.taskValues.set("start_date", start_date)

        end_date = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="end_date")
        dbutils.jobs.taskValues.set("end_date", end_date)
    
        # Call the function to create the silver calendar
        calendar_dim_df = create_gold_calendar(start_date, end_date,log_id)

        # Write the DataFrame to Delta table
        concurrent_external_table_delta_write(
            calendar_dim_df, delta_path_gold, delta_db_gold, delta_table_gold, '', catalog_name,
            object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full"
        )

        counter = counter + 1
        update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "gold calendar Ingestion completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
        
        dbutils.notebook.exit("")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "gold calendar table creation error", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Unpivoting the map forecast columns to the forecast_level_sk  and simple read for others

# COMMAND ----------

try:
    # Unpivoting the map forecast columns to the forecast_level_sk
    if data_feed == 'master_data_map_forecast':

        silver_df_forecast = spark.read.format("delta").table(source_table)
        df_forecast = spark.table(f"{catalog_name}.{forecast_delta_db_gold}.{forecast_delta_table_gold}")
        
        # Getting the columns to unpivot
        columns_to_unpivot = [col for col in silver_df_forecast.columns if col in ["monthly_forecast", "quarterly_forecast", "yearly_forecast","gmva_quarterly_forecast","gmva_yearly_forecast","twc_monthly_forecast","twc_quarterly_forecast","twc_yearly_forecast"]]
        num_columns = len(columns_to_unpivot)

        unpivoted_df = silver_df_forecast.select(
            silver_df_forecast.load_month, silver_df_forecast.reporting_month, silver_df_forecast.forecast_version, 
            silver_df_forecast.last_actuals_month, silver_df_forecast.is_active, silver_df_forecast.has_data, 
            silver_df_forecast.log_id, silver_df_forecast.created_date,silver_df_forecast.gmva_fc_version,silver_df_forecast.gmva_last_actuals_month,silver_df_forecast.twc_fc_version,silver_df_forecast.twc_last_actuals_month,
            expr(f"stack({num_columns}, " + ", ".join([f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (forecast_type_description, first_forecast_month)")
        )
        
        unpivoted_df = unpivoted_df.withColumn('previous_forecast_version', 
                       when(col('forecast_version') == 601, 612)
                       .otherwise(col('forecast_version') - 1))

        # Renaming the unpivoted records to match with forecast table
        joined_df = unpivoted_df.withColumn(
            "forecast_type_description_cleaned",
            when(lower(col("forecast_type_description")).contains("monthly"), "Month Forecast")
            .when(lower(col("forecast_type_description")).contains("quarterly"), "Quarter Forecast")
            .when(lower(col("forecast_type_description")).contains("yearly"), "Year Forecast")
        )

        joined_df = joined_df.withColumn(
            "forecast_type_description_keyword",
            trim(lower(regexp_extract(col("forecast_type_description_cleaned"), r"(Quarter|Month|Year)", 0)))
        )

        df_forecast = df_forecast.withColumn("forecast_cleaned", trim(lower(col("forecast_level_description"))))
        
        silver_df = joined_df.join(
            df_forecast, 
            joined_df["forecast_type_description_keyword"] == df_forecast["forecast_cleaned"], 
            "left"
        ).select(
            df_forecast["forecast_level_sk"], joined_df["load_month"], joined_df["reporting_month"].cast("int"), 
            joined_df["forecast_version"].cast("int"), joined_df["last_actuals_month"].cast("int"), 
            joined_df["forecast_type_description"], joined_df["first_forecast_month"].cast("int"), 
            joined_df["previous_forecast_version"],joined_df["gmva_fc_version"],joined_df["gmva_last_actuals_month"],joined_df["twc_fc_version"],joined_df["twc_last_actuals_month"], joined_df["is_active"], joined_df["has_data"], 
            joined_df["log_id"], joined_df["created_date"]
        )
    elif data_feed == 'market_fact_gmi_snapshot':
        df_dict = dict()
        key_list = delta_db_silver.keys()
        for key in key_list:
            source_table = f"{catalog_name}.{delta_db_silver[key]}.{delta_table_silver[key]}"
            silver_df = spark.read.format("delta").table(source_table)
            df_dict.update({key: silver_df}) 

    elif data_feed in ['finance_fact_bex_actuals','finance_fact_bex_brand','finance_fact_bex_brand_position',
                       'finance_fact_bex_customer']: 
        silver_df = spark.read.format("delta").table(source_table).filter(col("month_sk") == key_value) 

    elif data_feed == 'finance_fact_bex_forecast': 
        silver_df = spark.read.format("delta").table(source_table).filter(col("version_sk") == key_value) 

    elif data_feed in [ 'finance_fact_bex_forecast','finanvce_fact_bex_gmva_forecast']: 
        silver_df = spark.read.format("delta").table(source_table).filter(col("version_sk") == key_value) 
    
    elif data_feed in ["finance_fact_bex_gmva_actuals"]:
        key_value = key_value.split(",")
        key_value_1 = key_value[0]
        key_value_2 = key_value[1]
        silver_df = spark.read.format("delta").table(source_table).filter((col("flow_sk") == key_value_1) & (col("month_sk") == key_value_2))

    elif data_feed in ['master_data_dimension_alternate_description']:

        silver_df = spark.read.format("delta").table(source_table)

        bu_flat(silver_df,catalog_name,object_owner_spn,absolute_path)
        pcat_flat(silver_df,catalog_name,object_owner_spn,absolute_path)
        brand_flat(silver_df,catalog_name,object_owner_spn,absolute_path)

    # Reading the silver table
    else:
        silver_df = spark.read.format("delta").table(source_table)

    # Display the final DataFrame
    silver_df.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(
        int(detail_log_value + counter), log_value, run_id, username, 
        "Unpivoting map forecast columns for the gold ingestion failure", datetime.now(), 
        status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error
    )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write into Gold Staging Delta path
# MAGIC This function responsible 
# MAGIC - Ingestion type
# MAGIC - Table creation for specific DB
# MAGIC - concurent delta write
# MAGIC - Table schema check and raise

# COMMAND ----------

try:
    # Creating the CROSS Func MAPPING TABLE

    if data_feed == 'master_data_pcat_hierarchy':

        cross_func_map_table = 'cross_functional_mapping_description'
        df_final = spark.table(f"{catalog_name}.{delta_db_silver}.{cross_func_map_table}")
        delta_path_cross_gold = delta_path_gold.replace("product_category", cross_func_map_table)
        concurrent_external_table_delta_write(
                            df_final, delta_path_cross_gold, delta_db_gold, cross_func_map_table, '', catalog_name,
                            object_owner_spn, retry_count=0, max_retries=10, mergeSchema_flag=False, delta_overwrite_mode="full"
                    )

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to gold delta failed for mapping table", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    # Write the silver DataFrame to the gold Delta table with concurrent external table delta write
    if data_feed == 'market_fact_gmi_snapshot':
        for key in key_list:
            concurrent_external_table_delta_write(df_dict[key], absolute_path + delta_path_gold[key], delta_db_gold[key], delta_table_gold[key], "", catalog_name, object_owner_spn, retry_count=0, mergeSchema_flag = False, delta_overwrite_mode = "full" )
    elif '_fact_' in data_feed:
        concurrent_external_table_delta_write(silver_df, delta_path_gold, delta_db_gold, delta_table_gold,delta_gold_partitionBy, catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )

    else:    
        concurrent_external_table_delta_write(silver_df, delta_path_gold, delta_db_gold, delta_table_gold, "", catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )       

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to gold delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "gold delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Gold Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
