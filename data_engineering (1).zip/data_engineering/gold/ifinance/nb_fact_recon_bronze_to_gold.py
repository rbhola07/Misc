# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Recon Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   10 FEB 2024     |    Gokul Prasanth  /Vinod        |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC This notebook is responsible for doing reconciliation for bronze to gold data
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - uc_catalog    : uc_Catalog_varies for environment to environment 
# MAGIC
# MAGIC ### Output
# MAGIC Data will be used to identity the difference between bronze and gold data
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import sum, col, lower, regexp_replace, trim, expr, first, when, format_number,round,instr, lit, regexp_extract
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType, DecimalType, LongType

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

data_feed         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
external_location = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
debug_flag        = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
username          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
file_name         = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
object_owner_spn  = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
log_id            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("log_id", log_id)

job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
#run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
log_id = int(log_id)
print(f"log_id             : {log_id}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]
    if data_feed       == 'finance_fact_bex_actuals':
        current_nb_name = "nb_pmrs_fact_actuals"
        
    elif data_feed      == 'finance_fact_bex_forecast':
        current_nb_name = "nb_pmrs_fact_forecast"

    elif data_feed      == 'finance_fact_bex_brand':
        current_nb_name = "nb_pmrs_fact_brand"

    elif data_feed      == 'finance_fact_bex_brand_position':
        current_nb_name = "nb_pmrs_fact_brand_position" 

    elif data_feed      == 'finance_fact_bex_customer':
        current_nb_name = "nb_pmrs_fact_customer"

    elif data_feed      == 'finance_fact_bex_gmva_actuals':
        current_nb_name = "nb_pmrs_fact_gmva_actuals" 

    elif data_feed      == 'finance_fact_bex_gmva_forecast':
        current_nb_name = "nb_pmrs_fact_gmva_forecast"

    elif data_feed      == 'finance_fact_bex_twc_actuals':
        current_nb_name = "nb_pmrs_fact_twc_actuals"
        
    elif data_feed      == 'finance_fact_bex_twc_forecast':
        current_nb_name = "nb_pmrs_fact_twc_forecast"
    else:
        print(f"data_feed doesn't exists : {data_feed}")
    
    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    run_id = log_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fetching the configuration parameters and inputs

# COMMAND ----------

try:
    # ------------------Reading the Ingestion_Configuration_sheet-------------------#

    hbu_code = file_name.split('#')[2]
    if "HBU1" in hbu_code:
        dimension_code, fact_type = "mu", "dimension_mu"
    elif "HBU3" in hbu_code:
        dimension_code, fact_type = "sc", "dimension_sc"
    print(f"Dimension Code: {dimension_code}, Fact Type: {fact_type}")

    # Get the ingestion sheet data
    param           = get_param_data(uc_catalog_name)

    # Fetch specific configurations for the given data feed
    process_feed_df = fetch_config(param, data_feed)

    config_data     = get_config_data(data_feed, uc_catalog_name, 'finance')

    process_feed_df                 = fetch_config(param, data_feed)

        # Display the filtered data
    display(process_feed_df)

    # Extract configuration details from the dataframes
    catalog_name                    = uc_catalog_name
    delta_db_staging                = process_feed_df.select("delta_db_staging").first()[0]
    delta_table_staging             = process_feed_df.select("delta_table_staging").first()[0]
    delta_db_gold                   = process_feed_df.select("delta_db_gold").first()[0]
    delta_table_gold                = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'", '"')).get(fact_type)

    if debug_flag == "1":
        print('data_feed                      :', data_feed)
        print('catalog_name                   :', catalog_name)
        print('delta_db_staging               :', delta_db_staging)
        print('delta_table_staging            :', delta_table_staging)
        print('delta_table_gold               :', delta_table_gold)
        print('delta_db_gold                  :', delta_db_gold)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    raise e


# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

try:
    hbu_code = file_name.split('#')[2]

    if "HBU1" in hbu_code:
        dimension_code = "mu"
    elif "HBU3" in hbu_code:
        dimension_code = "sc"

    print(f"Dimension Code: {dimension_code}")

    # Read descendant business unit data
    df_des_bu = (spark.table(f"{uc_catalog_name}.silver_master_data.dim_descendant")
                      .filter(col("dimension") == dimension_code))

    # Read descendant product category data
    df_des_pcat = (spark.table(f"{uc_catalog_name}.silver_master_data.dim_descendant")
                        .filter(col("dimension") == "pcat"))

    # Read fact data from Bronze based on data feed conditions
    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position","finance_fact_bex_twc_actuals"]:
        df_fact_bronze = spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")\
                              .filter(~col("flow").like("%QTD%"))\
                              .filter(~col("flow").like("%YTD%"))\
                              .filter(col("log_id") == log_id)

    elif data_feed in ['finance_fact_bex_actuals','finance_fact_bex_customer']:
        df_fact_bronze = spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")\
                              .filter((col("flow").like("%Month%")) & (col("log_id") == log_id))

    elif data_feed in ['finance_fact_bex_forecast']:    
        columns_to_drop = [
            "overheads", "otis", "overheads_percent_turnover_cy", "allocated_charges_overheads_total",
            "operating_profit", "restructuring_total", "allocated_charges_restructuring_total",
            "underlying_operating_profit", "underlying_operating_margin", "overheads_under_control"]
        
        df_fact_bronze = (spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")
                        .filter(col("log_id") == log_id)  
                        .drop(*columns_to_drop)) 
        
        df_fact_bronze = df_fact_bronze.withColumn("flow_flag",
                                                                when(df_fact_bronze["flow"].like("Q%"), "Quarter")
                                                                .when(df_fact_bronze["flow"].like("Full Year%"), "Year")
                                                                .otherwise("Month"))
    
    elif data_feed == "finance_fact_bex_gmva_actuals":
        df_fact_bronze = spark.read.table(f"{catalog_name}.{delta_db_staging}.{delta_table_staging}") \
                                   .filter((col("log_id") == log_id) & (instr(col("flow"), "QTD") > 0))
    
    elif data_feed == "finance_fact_bex_gmva_forecast":
        df_fact_bronze = (spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")
                               .filter((col("log_id") == log_id)))
    
    elif data_feed == "finance_fact_bex_twc_forecast":
        df_fact_bronze = (spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}" )
                                .filter((col("log_id") == log_id)).distinct())

    # Determine dimension code based on data feed
    if data_feed == "finance_fact_bex_brand":
        code='brand'
    elif data_feed =='finance_fact_bex_customer':
        code='customer'
    else:
        code='brand_position'

    # Read descendant brand data
    df_des_brand = spark.table(f"{uc_catalog_name}.silver_master_data.dim_descendant").filter(col("dimension") == code)

    # Display data for debugging
    if debug_flag=="1":
        df_fact_bronze.display()

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e


# COMMAND ----------

try:
    # Perform joins based on data feed type
    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position"]:
        df_joined = df_fact_bronze.join(df_des_bu, df_fact_bronze.business_unit == df_des_bu.child_code, "inner")\
                                  .join(df_des_pcat, df_fact_bronze.product_category == df_des_pcat.child_code, "inner")\
                                  .join(df_des_brand, df_fact_bronze.brand == df_des_brand.child_code, "inner")\
                                  .select(  df_des_bu['level_num'].alias('bu_level'),
                                            df_des_pcat['level_num'].alias('pcat_level'),
                                            df_des_brand['level_num'].alias('brand_level'),
                                            df_des_pcat['descendant_sk'].alias('pcat_sk'),
                                            df_des_bu['descendant_sk'].alias('bu_sk'),
                                            df_des_brand['descendant_sk'].alias('brand_sk'),
                                            *df_fact_bronze.columns )\
                                  .drop("log_id", "created_date")
    
    elif data_feed in ["finance_fact_bex_customer"]:
        df_joined = df_fact_bronze.join(df_des_bu, df_fact_bronze.business_unit == df_des_bu.child_code, "inner")\
                                  .join(df_des_pcat, df_fact_bronze.product_category == df_des_pcat.child_code, "inner")\
                                  .join(df_des_brand, df_fact_bronze.customer == df_des_brand.child_code, "inner")\
                                  .select(  df_des_bu['level_num'].alias('bu_level'),
                                            df_des_pcat['level_num'].alias('pcat_level'),
                                            df_des_brand['level_num'].alias('customer_level'),
                                            df_des_pcat['descendant_sk'].alias('pcat_sk'),
                                            df_des_bu['descendant_sk'].alias('bu_sk'),
                                            df_des_brand['descendant_sk'].alias('customer_sk'),
                                            *df_fact_bronze.columns )\
                                  .drop("log_id", "created_date")
    else:       
        df_joined = df_fact_bronze.join(df_des_bu, df_fact_bronze.business_unit == df_des_bu.child_code, "inner")\
                            .join(df_des_pcat, df_fact_bronze.product_category == df_des_pcat.child_code, "inner")\
                            .select(df_des_bu['level_num'].alias('bu_level'),
                                    df_des_pcat['level_num'].alias('pcat_level'),
                                    df_des_pcat['descendant_sk'].alias('pcat_sk'),
                                    df_des_bu['descendant_sk'].alias('bu_sk'),
                                    *df_fact_bronze.columns)\
                            .drop("log_id", "created_date")
    
    # Grouping and aggregation
    df_joined.display()

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position"]:
        exclude_columns = ['company', 'bu_level', 'pcat_level', 'brand_level', 'pcat_sk', 'bu_sk', 'brand_sk', 
                           'business_unit', 'product_category', 'contdiscops_code','flow', 'version', 'brand']
        columns_to_sum  = [c for c in df_joined.columns if c not in exclude_columns]

        grouped_df      =  df_joined.groupBy('bu_level', 'pcat_level', 'brand_level', 'brand', 'product_category', 'business_unit')\
                                .agg(*[sum(col(c)).alias(c) for c in columns_to_sum])\
                                .orderBy("bu_level", "pcat_level", "brand_level")

    elif data_feed in ["finance_fact_bex_customer"]:
        exclude_columns = ['bu_level', 'pcat_level', 'customer_level', 'pcat_sk', 'bu_sk', 'customer_sk', 
                           'business_unit', 'product_category','customer', 'contdiscops_code','flow', 'customer_channel']
        columns_to_sum  = [c for c in df_joined.columns if c not in exclude_columns]

        grouped_df      =  df_joined.groupBy('bu_level', 'pcat_level', 'customer_level', 'customer', 'product_category', 'business_unit')\
                                .agg(*[sum(col(c)).alias(c) for c in columns_to_sum])\
                                .orderBy("bu_level", "pcat_level", "customer_level")
    
    elif data_feed in ["finance_fact_bex_twc_forecast"]:
        exclude_columns  = ['company', 'bu_level', 'pcat_level', 'pcat_sk', 'bu_sk', 'business_unit', 'product_category','version','brand','contdiscops_code','flow','flow_flag']
        columns_to_sum   = [col for col in df_joined.columns if col not in exclude_columns]

        grouped_df       = df_joined.groupBy('bu_level', 'pcat_level', 'product_category', 'business_unit','flow') \
                                .agg(*[sum(col).alias(col) for col in columns_to_sum]) \
                                .orderBy("bu_level","pcat_level")
    
    elif data_feed in ["finance_fact_bex_forecast"]:
        df_joined = df_joined.filter(~((df_joined["flow_flag"] == "Month") & (df_joined["pcat_level"] >= 4)))
        exclude_columns  = ['company', 'bu_level', 'pcat_level', 'pcat_sk', 'bu_sk', 'business_unit', 'product_category','version','brand','contdiscops_code','flow','flow_flag']
        columns_to_sum   = [col for col in df_joined.columns if col not in exclude_columns]

        grouped_df       = df_joined.groupBy('bu_level', 'pcat_level', 'product_category', 'business_unit','flow') \
                                .agg(*[sum(col).alias(col) for col in columns_to_sum]) \
                                .orderBy("bu_level","pcat_level")

    else:
        exclude_columns  = ['company', 'bu_level', 'pcat_level', 'pcat_sk', 'bu_sk', 'business_unit', 'product_category', 'flow','version','brand','contdiscops_code','cont_disc_ops_code']
        columns_to_sum   = [col for col in df_joined.columns if col not in exclude_columns]

        grouped_df       = df_joined.groupBy('bu_level', 'pcat_level', 'product_category', 'business_unit') \
                                .agg(*[sum(col).alias(col) for col in columns_to_sum]) \
                                .orderBy("bu_level","pcat_level")

    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position"]:
        columns_to_unpivot = [col for col in grouped_df.columns if col not in ["bu_level", "pcat_level", "brand_level" ,"business_unit", "product_category","brand"]]
        num_columns = len(columns_to_unpivot)

        unpivoted_df = grouped_df.select("bu_level", "pcat_level", "brand_level" ,"business_unit", "product_category","brand",
            expr(f"stack({num_columns}, " + ", ".join([f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure_description, value)"))
        
        unpivoted_df   =  unpivoted_df.withColumn("value", unpivoted_df["value"].cast(DecimalType(36, 16)))

        unpivoted_df.display()

    elif data_feed in ["finance_fact_bex_customer"]:
        columns_to_unpivot = [col for col in grouped_df.columns if col not in ["bu_level", "pcat_level", "customer_level" ,"business_unit", "product_category","customer","customer_channel"]]
        num_columns = len(columns_to_unpivot)

        unpivoted_df = grouped_df.select("bu_level", "pcat_level", "customer_level" ,"business_unit", "product_category","customer",
            expr(f"stack({num_columns}, " + ", ".join([f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure_description, value)"))
        
        unpivoted_df   =  unpivoted_df.withColumn("value", unpivoted_df["value"].cast(DecimalType(36, 16)))

        unpivoted_df.display()
    
    elif data_feed in ["finance_fact_bex_forecast","finance_fact_bex_twc_forecast"]:
        columns_to_unpivot = [col for col in grouped_df.columns if col not in ["bu_level", "pcat_level", "business_unit", "product_category","flow",'flow_flag']]
        num_columns        = len(columns_to_unpivot)

        unpivoted_df   = grouped_df.select( "bu_level", "pcat_level", "business_unit", "product_category",'flow',
                            expr(f"stack({num_columns}, " + ", ".join(
                                [f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure_description, value)"))
        unpivoted_df   = unpivoted_df.withColumn("value", unpivoted_df["value"].cast(DecimalType(36, 16)))

    else:
        columns_to_unpivot = [col for col in grouped_df.columns if col not in ["bu_level", "pcat_level", "business_unit", "product_category"]]
        num_columns        = len(columns_to_unpivot)

        unpivoted_df   = grouped_df.select( "bu_level", "pcat_level", "business_unit", "product_category",
                            expr(f"stack({num_columns}, " + ", ".join(
                                [f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure_description, value)"))
        unpivoted_df   = unpivoted_df.withColumn("value", unpivoted_df["value"].cast(DecimalType(36, 16)))

        unpivoted_df.display()

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

if data_feed in  ['finance_fact_bex_forecast','finance_fact_bex_twc_forecast']:
    unpivoted_df = unpivoted_df.withColumn(
                            "flow_converted",
                            when(unpivoted_df["flow"].contains("Full Year"),
                                concat(lit("Dec "), unpivoted_df["flow"].substr(-4, 4))
                            ).otherwise(
                                when(unpivoted_df["flow"].rlike(r"\w{3}-\d{2}"),
                                    concat(unpivoted_df["flow"].substr(1, 3), lit(" 20"), unpivoted_df["flow"].substr(5, 2))
                                ).otherwise(
                                    when(unpivoted_df["flow"].contains("Q1"), concat(lit("Mar "), unpivoted_df["flow"].substr(-4, 4)))
                                    .when(unpivoted_df["flow"].contains("Q2"), concat(lit("Jun "), unpivoted_df["flow"].substr(-4, 4)))
                                    .when(unpivoted_df["flow"].contains("Q3"), concat(lit("Sep "), unpivoted_df["flow"].substr(-4, 4)))
                                    .when(unpivoted_df["flow"].contains("Q4"), concat(lit("Dec "), unpivoted_df["flow"].substr(-4, 4)))
                                    .otherwise(unpivoted_df["flow"])
                                )))
    
    unpivoted_df = unpivoted_df.withColumn("flow_formatted",
                        when(unpivoted_df["flow"].like("Q%"), "Quarter")
                        .when(unpivoted_df["flow"].like("Full Year%"), "Year")
                        .otherwise("Month"))
    
    df_calendar   = spark.table(f"{uc_catalog_name}.gold_master_data.calendar")

    unpivoted_df  = unpivoted_df.join(df_calendar, unpivoted_df.flow_converted == df_calendar.month_short_description, "inner")

    df_forecast_level   = spark.table(f"{uc_catalog_name}.gold_master_data.forecast_level")
    unpivoted_df         = unpivoted_df.join(df_forecast_level, unpivoted_df.flow_formatted == df_forecast_level.forecast_level_description, "inner")
    unpivoted_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Measure 
# MAGIC

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_twc_actuals"]: 
        replacements = [(r'[%٪]', '_percent_'),(r'\.(?=[a-z])', '_'),(r"[',.]", ''),(r'[ \u00A0,;{}()\n\t&=–/-]', '_'), 
        (r'([a-z])([A-Z])', r'\1_\2'),(r'__+', '_'),(r'^_|_$', ''),(r'__+', '_'),(r'_n_', '_')  ]
    
    elif data_feed  == "finance_fact_bex_twc_forecast": 
        replacements = [  (r'[%٪]', '_percent_'), (r'\.(?=[a-z])', '_'), (r"[',.]", ''), (r'[ \u00A0,;{}()\n\t&=–/-]', '_'), 
                        (r'([a-z])([A-Z])', r'\1_\2'), (r'__+', '_'), (r'^_|_$', ''), (r'__+', '_'), (r'_n_', '_')   ]
    
    else:
        replacements = [("%", "percent"),("٪", "percent"),("[- ]", "_"),("_+", "_"),("–", " "),("[^a-zA-Z0-9_]", ""),(r"^_|_$", ""),("pm", "p_m")]

    df_measure = spark.table(f"{uc_catalog_name}.silver_master_data.measure")
    df_measure = df_measure.filter(df_measure["is_active"] == True)
    
    for pattern, replacement in replacements:
        df_measure = df_measure.withColumn("measure_description", regexp_replace(lower(df_measure["measure_description"]), pattern, replacement))

    df_measure = df_measure.withColumn("measure_description", trim(df_measure["measure_description"]))
    
    df_measure = df_measure.withColumns({
        "measure_description": when(col("measure_description") == "promotional_to_percent", "promotional_percent_t_o")
            .when(col("measure_description") == "pbo_perc_to", "pbopercent_to")
            .when(col("measure_description") == "tts_perc", "tts_percent")
            .when(col("measure_description") == "ad_related_costs", "a_d_related_costs")
            .when(col("measure_description") == "overheads_perc_turnover_cy", "overheads_percent_turnover_cy")
            .when(col("measure_description") == "brand_and_marketing_investment_perc", "brand_and_marketing_investment_percent")
            .when(col("measure_description") == "adv_to_percent", "adv_percent_t_o")
            .when(col("measure_description") == "business_waste_fixed_assets_woff_r2", "business_waste_fixed_assets_w_off_r2")
            .when(col("measure_description") == "adjusted_cy_to", "adjusted_cy_t_o")
            .when(col("measure_description") == "adjusted_usg", "adjusted_usgpercent")
            .when(col("measure_description") == "adjusted_uvg", "adjusted_uvgpercent")
            .when(col("measure_description") == "customer_sales_equip_ment", "customer_sales_equipment")
            .when(col("measure_description") == "marketing_develop_ment", "marketing_development")
            .when(col("measure_description") == "product_develop_ment", "product_development")
            .when(col("measure_description") == "bw_material_w_off_rm_p_m_semi_fg", "bw_material_w_off_rm_pm_semi_fg")
            .when(col("measure_description") == "p_m_bip_adjustment_p_m_costs", "p_m_bip_adjustment_pm_costs")
            .otherwise(col("measure_description"))
    })

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold

# COMMAND ----------

from pyspark.sql.functions import col
try:
        
    # Load necessary tables
    active_filter = col("is_active") == True

    # Load fact table from the gold layer based on log_id
    df_fact = spark.table(f"{uc_catalog_name}.gold_finance.{delta_table_gold}").filter(col("log_id") == log_id)

    # Load master data tables with an active filter
    df_bu = spark.table(f"{uc_catalog_name}.gold_master_data.business_unit").filter(active_filter)
    df_pcat = spark.table(f"{uc_catalog_name}.gold_master_data.product").filter(active_filter)

    # Define common filters to avoid repetition
    measure_filter = ((col('measure_type') == 'PnL Direct Measures') & 
            (~col('measure_description').isin('uvg_as_reported', 'underlying_operating_margin')))
    base_filter = (df_bu.bu_sk != -1) & (df_pcat.product_sk != -1)

    # Process data based on the data feed type
    if data_feed == "finance_fact_bex_brand":
        # Load brand data
        df_brand = spark.table(f"{uc_catalog_name}.gold_master_data.brand").filter(active_filter)

        # Perform necessary joins and apply filters
        df_joined = df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                        .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                        .join(df_brand, df_fact.brand_sk == df_brand.brand_sk, "inner")\
                        .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                        .filter(base_filter & (df_brand.brand_sk != -1) & measure_filter)

    elif data_feed == "finance_fact_bex_brand_position":
        # Load brand position and forecast level data
        df_brand_position = spark.table(f"{uc_catalog_name}.gold_master_data.brand_position").filter(active_filter)

        # Perform necessary joins and apply filters
        df_joined = df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                        .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                        .join(df_brand_position, df_fact.brand_position_sk == df_brand_position.brand_position_sk, "inner")\
                        .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                        .filter(base_filter & 
                                (df_brand_position.brand_position_sk != -1) & 
                                measure_filter)

    elif data_feed == "finance_fact_bex_customer":
        # Load customer data
        df_customer = spark.table(f"{uc_catalog_name}.gold_master_data.customer").filter(active_filter)

        # Perform necessary joins and apply filters
        df_joined =  df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                            .join(df_customer, df_fact.customer_sk == df_customer.customer_sk, "inner")\
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                            .filter(base_filter & (df_customer.customer_sk != -1) & measure_filter)

    elif data_feed in [ "finance_fact_bex_gmva_forecast"]:
        # Join with GMVA measures
        df_joined =  df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                            .filter(base_filter & (col('measure_type') == 'GMVA Direct Measures'))
                            
    elif data_feed in ["finance_fact_bex_gmva_actuals"]:
        qtr_sk_value = spark.table(f"{uc_catalog_name}.gold_master_data.flow") \
                            .filter(col("flow_description") == "QTD") \
                            .select("flow_sk") \
                            .first()["flow_sk"] 
        print(qtr_sk_value)

        # Join with GMVA measures
        df_joined =  df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                            .filter(base_filter & (col('measure_type') == 'GMVA Direct Measures'))\
                            .filter(df_fact.flow_sk == qtr_sk_value)
    
    elif data_feed in ["finance_fact_bex_forecast"]:
        df_forecast_level = spark.table(f"{uc_catalog_name}.gold_master_data.forecast_level").filter(active_filter)
        df_joined = df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                        .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                        .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                        .join(df_forecast_level, df_fact.forecast_level_sk == df_forecast_level.forecast_level_sk, "inner")\
                        .filter(base_filter & measure_filter).drop(df_fact.forecast_level_sk)
    
    elif data_feed == 'finance_fact_bex_twc_actuals':
        df_joined =  df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                            .filter(base_filter & (col('measure_type') == 'WC Direct Measures'))
                            
    elif data_feed in ["finance_fact_bex_twc_forecast"]:
        df_forecast_level = spark.table(f"{uc_catalog_name}.gold_master_data.forecast_level").filter(active_filter)
        df_joined = df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner") \
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner") \
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "left") \
                            .join(df_forecast_level, df_fact.forecast_level_sk == df_forecast_level.forecast_level_sk, "inner") \
                            .filter(base_filter & (col('measure_type') == 'WC Direct Measures')) \
                            .drop(df_fact.forecast_level_sk) \
                            .filter(df_pcat['source'].like("%Finance%"))

    else:
        df_joined =  df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")\
                            .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")\
                            .join(df_measure, df_fact.measure_sk == df_measure.measure_sk, "inner")\
                            .filter(base_filter & measure_filter)

    # Display the final joined DataFrame
    df_fact.display()
    df_joined.display()

except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

try:
        # Define hierarchy mappings
    pcat_levels  = [ "total_unilever_by_product_category_code", "legacy_division_code", "division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", 
                    "segment_code","product_form_code" ]

    if code == 'brand':
        brand_levels = [ "total_by_finance_code", "corporate_parent_finance_code", "corporate_brand_code"]

    elif code == 'customer':
        customer_levels =["total_customer_code", "customer_importance_code", "global_customer_group_finance_code", "global_customer_finance_code"]
    else:
        brand_levels = [ "brand_position_level_0_code", "brand_position_level_1_code", "brand_position_level_2_code", "brand_position_level_3_code", "brand_position_default_code"]

    if  dimension_code == 'mu':
        bu_levels = ["mu_hier_level_0_code","mu_hier_level_1_code","mu_hier_level_2_code","mu_hier_level_3_code","mu_hier_level_4_code","mu_hier_level_5_code","mu_code","bu_code"]

    elif dimension_code == 'sc':
        bu_levels = ["sc_level_0_code","sc_level_1_code","sc_level_2_code","sc_level_3_code","sc_level_4_code","sc_level_5_code","sc_level_6_code","sc_mu_code","bu_code"]

    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position"]:
        pairs_list = unpivoted_df.select("bu_level", "pcat_level","brand_level").distinct().collect()
        pairs_list = [(row["bu_level"], row["pcat_level"], row["brand_level"]) for row in pairs_list]
        print(pairs_list)
    elif data_feed in ["finance_fact_bex_customer"]:
        pairs_list = unpivoted_df.select("bu_level", "pcat_level","customer_level").distinct().collect()
        pairs_list = [(row["bu_level"], row["pcat_level"], row["customer_level"]) for row in pairs_list]
        print(pairs_list)
    else:
        pairs_list = unpivoted_df.select("bu_level", "pcat_level").distinct().collect()
        pairs_list = [(row["bu_level"], row["pcat_level"]) for row in pairs_list]
        print(pairs_list)
        
except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

try:
    # Aggregate Bronze and Gold measures
    bronze_measures = unpivoted_df.select("measure_description").distinct()
    gold_measures   = df_joined.select("measure_description").distinct()

    bronze_not_in_gold = bronze_measures.join(gold_measures, "measure_description", "left_anti")
    gold_not_in_bronze = gold_measures.join(bronze_measures, "measure_description", "left_anti")

    if bronze_not_in_gold.count() == 0 and gold_not_in_bronze.count() == 0:
        print("All measures are matching.")
    else:
        print("Unmatched measures found:")
        bronze_not_in_gold.display()
        gold_not_in_bronze.display()
        
except Exception as e:
    print(f"An error occurred: {str(e)}")
    raise e

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_actuals", "finance_fact_bex_gmva_actuals", "finance_fact_bex_gmva_forecast","finance_fact_bex_twc_actuals"]:
        mismatch_found = False 

        # Iterate over each (bu_level, pcat_level) pair
        for bu_level, pcat_level in pairs_list:
            selected_bu_column = bu_levels[bu_level]  
            selected_pcat_column = pcat_levels[pcat_level]  
            print(f"\nProcessing (bu_level={bu_level}, pcat_level={pcat_level}) → {selected_bu_column}, {selected_pcat_column}")

            # Aggregate Bronze
            df_bronze_agg = (unpivoted_df.filter((col("bu_level") == bu_level) & (col("pcat_level") == pcat_level))
                                        .groupBy("business_unit", "product_category", "measure_description")
                                        .agg(sum("value").alias("bronze_total")))

            # Aggregate Gold
            df_gold_agg = (df_joined.groupBy("measure_description", selected_bu_column, selected_pcat_column)
                                     .agg(sum("value").alias("gold_total")))

            df_comparison = (df_bronze_agg.join(df_gold_agg,
                    (df_bronze_agg["business_unit"] == df_gold_agg[selected_bu_column]) &
                    (df_bronze_agg["product_category"] == df_gold_agg[selected_pcat_column]) &
                    (df_bronze_agg["measure_description"] == df_gold_agg["measure_description"]),
                                            "inner")
                .select(
                        df_bronze_agg["business_unit"],
                        df_bronze_agg["product_category"],
                        df_bronze_agg["measure_description"],
                        df_bronze_agg["bronze_total"],
                        df_gold_agg["gold_total"])
                .fillna(0, subset=["bronze_total", "gold_total"])
                .withColumn("difference", col("bronze_total") - col("gold_total"))
                .withColumn("difference", format_number(col("difference"), 5)))

            # Print Mismatches
            mismatches = df_comparison.filter(col("difference") != 0)
            matches = df_comparison.filter(col("difference") == 0).withColumn("log_id", lit(log_id))

            if mismatches.count() > 0:
                print(f"Mismatch found for (bu_level={bu_level}, pcat_level={pcat_level}):")
                mismatches.display()
                mismatch_found = True  # Set flag if mismatch is found
            else:
                print(f"No mismatch for (bu_level={bu_level}, pcat_level={pcat_level}).")

        # Raise exception if any mismatch was found
        if mismatch_found:
            raise Exception("Mismatch found in one or more (bu_level, pcat_level) pairs.")

except Exception as e:
    print(f"An error occurred: {type(e).__name__}: {str(e)}")
    raise e

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_forecast","finance_fact_bex_twc_forecast"]:

        mismatch_found = False 

        # Iterate over each (bu_level, pcat_level) pair
        for bu_level, pcat_level in pairs_list:

            selected_bu_column = bu_levels[bu_level]  
            selected_pcat_column = pcat_levels[pcat_level]  
            print(f"\nProcessing (bu_level={bu_level}, pcat_level={pcat_level}) → {selected_bu_column}, {selected_pcat_column}")

            # Aggregate Bronze
            df_bronze_agg  = unpivoted_df.filter((col("bu_level") == bu_level) & (col("pcat_level") == pcat_level)) \
                                        .groupBy("business_unit", "product_category", "measure_description",'month_sk','forecast_level_sk') \
                                        .agg((sum("value")).alias("bronze_total"))

            # Aggregate Gold
            df_gold_agg = df_joined.groupBy("measure_description", selected_bu_column, selected_pcat_column,col('month_sk'),col('forecast_level_sk'))\
                                    .agg((sum("value")).alias("gold_total"))

            df_comparison = df_bronze_agg.join(
                        df_gold_agg,
                        (df_bronze_agg["business_unit"] == df_gold_agg[selected_bu_column]) &
                        (df_bronze_agg["product_category"] == df_gold_agg[selected_pcat_column]) &
                        (df_bronze_agg["measure_description"] == df_gold_agg["measure_description"]) &
                        (df_bronze_agg["forecast_level_sk"] == df_gold_agg["forecast_level_sk"]) &
                        (df_bronze_agg["month_sk"] == df_gold_agg["month_sk"]),
                        "inner"
                    ).select(
                        df_bronze_agg["business_unit"], df_bronze_agg["product_category"],
                        df_bronze_agg["measure_description"], df_bronze_agg["bronze_total"],
                        df_gold_agg["gold_total"], df_gold_agg["month_sk"]
                    ).fillna(0, subset=["bronze_total", "gold_total"]) \
                    .withColumn("difference", col("bronze_total") - col("gold_total")) \
                    .withColumn("difference", format_number(col("difference"), 5))

            # Print Mismatches
            mismatches = df_comparison.filter(col("difference") != 0)
            matches = df_comparison.filter(col("difference") == 0).withColumn("log_id", lit(log_id))
            matches.display()
            if mismatches.count() > 0:
                print(f"Mismatch found for (bu_level={bu_level}, pcat_level={pcat_level}):")
                mismatches.display()
                mismatch_found = True  # Set flag if mismatch is found
            else:
                print(f"No mismatch for (bu_level={bu_level}, pcat_level={pcat_level}).")

        # Raise exception if any mismatch was found
        if mismatch_found:
            raise Exception("Mismatch found in one or more (bu_level, pcat_level) pairs.")

except Exception as e:
    print(f"An error occurred: {type(e).__name__}: {str(e)}")
    raise e

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_brand", "finance_fact_bex_brand_position"]:

        mismatch_found = False 

        # Iterate over each (bu_level, pcat_level, brand_level) pair
        for bu_level, pcat_level, brand_level in pairs_list:

            selected_bu_column = bu_levels[bu_level]  
            selected_pcat_column = pcat_levels[pcat_level]  
            selected_brand_column = brand_levels[brand_level]

            print(f"\nProcessing (bu_level={bu_level}, pcat_level={pcat_level}, brand_level={brand_level}) → {selected_bu_column}, {selected_pcat_column} → {selected_brand_column}")

            # Aggregate Bronze
            df_bronze_agg = (
                unpivoted_df.filter(
                    (col("bu_level") == bu_level) & 
                    (col("pcat_level") == pcat_level) & 
                    (col("brand_level") == brand_level)
                )
                .groupBy("business_unit", "product_category", "brand", "measure_description")
                .agg(sum("value").alias("bronze_total"))
            )

            # Aggregate Gold
            df_gold_agg = (
                df_joined.groupBy("measure_description", selected_bu_column, selected_pcat_column, selected_brand_column)
                .agg(sum("value").alias("gold_total"))
            )

            # Perform Comparison
            df_comparison = (
                df_bronze_agg.join(
                    df_gold_agg,
                    (df_bronze_agg["business_unit"] == df_gold_agg[selected_bu_column]) &
                    (df_bronze_agg["product_category"] == df_gold_agg[selected_pcat_column]) &
                    (df_bronze_agg["brand"] == df_gold_agg[selected_brand_column]) &
                    (df_bronze_agg["measure_description"] == df_gold_agg["measure_description"]),
                    "inner",
                )
                .select(
                    df_bronze_agg["business_unit"],
                    df_bronze_agg["product_category"],
                    df_bronze_agg["brand"],
                    df_bronze_agg["measure_description"],
                    df_bronze_agg["bronze_total"],
                    df_gold_agg["gold_total"],
                )
                .fillna(0, subset=["bronze_total", "gold_total"])
                .withColumn("difference", col("bronze_total") - col("gold_total"))
                .withColumn("difference", format_number(col("difference"), 5))
            )

            # Check for Mismatches
            mismatches = df_comparison.filter(col("difference") != 0)
            matches = df_comparison.filter(col("difference") == 0)

            if mismatches.count() > 0:
                print(f"Mismatch found for (bu_level={bu_level}, pcat_level={pcat_level}, brand_level={brand_level}):")
                mismatches.display()
                mismatch_found = True  # Set flag if mismatch is found
            else:
                print(f"No mismatch for (bu_level={bu_level}, pcat_level={pcat_level}, brand_level={brand_level}).")

        # Raise exception if any mismatch was found
        if mismatch_found:
            raise Exception("Mismatch found in one or more (bu_level, pcat_level, brand_level) pairs.")

except Exception as e:
    print(f"An error occurred: {type(e).__name__}: {str(e)}")
    raise e

# COMMAND ----------

try:
    if data_feed in ["finance_fact_bex_customer"]:

        mismatch_found = False 

        # Iterate over each (bu_level, pcat_level, customer_level) pair
        for bu_level, pcat_level, customer_level in pairs_list:

            selected_bu_column = bu_levels[bu_level]  
            selected_pcat_column = pcat_levels[pcat_level]  
            selected_customer_column = customer_levels[customer_level]

            print(f"\nProcessing (bu_level={bu_level}, pcat_level={pcat_level}, customer_level={customer_level}) → {selected_bu_column}, {selected_pcat_column} → {selected_customer_column}")

            # Aggregate Bronze
            df_bronze_agg = (
                unpivoted_df.filter(
                    (col("bu_level") == bu_level) & 
                    (col("pcat_level") == pcat_level) & 
                    (col("customer_level") == customer_level)
                )
                .groupBy("business_unit", "product_category", "customer", "measure_description")
                .agg(sum("value").alias("bronze_total"))
            )

            # Aggregate Gold
            df_gold_agg = (
                df_joined.groupBy("measure_description", selected_bu_column, selected_pcat_column, selected_customer_column)
                .agg(sum("value").alias("gold_total"))
            )

            # Perform Comparison
            df_comparison = (
                df_bronze_agg.join(
                    df_gold_agg,
                    (df_bronze_agg["business_unit"] == df_gold_agg[selected_bu_column]) &
                    (df_bronze_agg["product_category"] == df_gold_agg[selected_pcat_column]) &
                    (df_bronze_agg["customer"] == df_gold_agg[selected_customer_column]) &
                    (df_bronze_agg["measure_description"] == df_gold_agg["measure_description"]),
                    "inner",
                )
                .select(
                    df_bronze_agg["business_unit"],
                    df_bronze_agg["product_category"],
                    df_bronze_agg["customer"],
                    df_bronze_agg["measure_description"],
                    df_bronze_agg["bronze_total"],
                    df_gold_agg["gold_total"],
                )
                .fillna(0, subset=["bronze_total", "gold_total"])
                .withColumn("difference", col("bronze_total") - col("gold_total"))
                .withColumn("difference", format_number(col("difference"), 5))
            )

            # Check for Mismatches
            mismatches = df_comparison.filter(col("difference") != 0)
            matches = df_comparison.filter(col("difference") == 0)

            if mismatches.count() > 0:
                print(f"Mismatch found for (bu_level={bu_level}, pcat_level={pcat_level}, customer_level={customer_level}):")
                mismatches.display()
                mismatch_found = True  # Set flag if mismatch is found
            else:
                print(f"No mismatch for (bu_level={bu_level}, pcat_level={pcat_level}, customer_level={customer_level}).")

        # Raise exception if any mismatch was found
        if mismatch_found:
            raise Exception("Mismatch found in one or more (bu_level, pcat_level, customer_level) pairs.")

except Exception as e:
    print(f"An error occurred: {type(e).__name__}: {str(e)}")
    raise e
