# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 08 Nov 2024        |    Gokul Prasanth      |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Ingestion Notebook to ingest the data from silver table and to create the Gold table
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and Gold delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC workflow trigger from webapp
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

import time
import json
import traceback
from datetime import datetime, date, timedelta
from pyspark.sql import functions as F
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType,LongType
from pyspark.sql.functions import col, lit, lower, trim,current_timestamp, desc, expr
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

# === EXTRACT CONFIGURATION VALUES ===
debug_flag           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
external_location    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
uc_catalog_name      = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
username             = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
file_name            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
log_id               = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

# === SET TASK VALUES FOR DOWNSTREAM USE ===
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("file_name", file_name)
dbutils.jobs.taskValues.set("log_id", log_id)

# === EXTRACT & SET KEY VALUE FOR NEXT STAGE ===
key_value  = dbutils.jobs.taskValues.get(taskKey="Bronze_staging_to_silver_ingestion", key="key_value")
dbutils.jobs.taskValues.set("key_value", key_value)
print(f"key_value: {key_value}, type: {type(key_value)}")

# === DEBUG LOGGING ===
if debug_flag == "1":
    print(f"data_feed            : {data_feed}")
    print(f"debug_flag           : {debug_flag}")
    print(f"external_location    : {external_location}")
    print(f"uc_catalog_name      : {uc_catalog_name}")
    print(f"object_owner_spn     : {object_owner_spn}")
    print(f"username             : {username}")
    print(f"file_name            : {file_name}")
    print(f"log_id               : {log_id}")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # === GET ABSOLUTE PATH ===
    absolute_path = return_absolute_path(external_location)

    # === GET CURRENT NOTEBOOK NAME ===
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # === GET AUDIT INFORMATION ===
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # === GET STATUS IDs ===
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # === GET RUN AND JOB IDs ===
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = int(log_id)
    
    # === DEBUG LOGGING ===
    if debug_flag == "1":
        print(f"run_id               : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"notebook_name        : {current_nb_name}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"[AUDIT INITIALIZATION ERROR] {error}")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# === INSERT JOB LOG & JOB DETAIL LOG ENTRY ===
counter = 1
log_value = run_id + 3
detail_log_value = (log_value * 10) 

insert_job_log(log_value, job_id, run_id, username,"Ifinance Gold Fact Ingestion", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Silver to Gold ingestion for "+data_feed, datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the Gold ingestion configurations data which are necessarry for ingestion by datafeed
# MAGIC - ingestion_configuration_sheet    - Excel data
# MAGIC - master_table_metadata_file       - Json data
# MAGIC - finance__table_metadata_file     - Json data

# COMMAND ----------

try:
    if data_feed not in [ 'finance_fact_offline_data']:

        # === READING INGESTION CONFIGURATION ===

        # Determine dimension code from file name
        hbu_code = file_name.split('#')[2]
        if "HBU1" in hbu_code:
            dimension_code, fact_type = "mu", "dimension_mu"
        elif "HBU3" in hbu_code:
            dimension_code, fact_type = "sc", "dimension_sc"
        print(f"Dimension Code: {dimension_code}")

        # Read Ingestion configuration sheet
        param                  = get_param_data(uc_catalog_name)
        process_feed_df        = fetch_config(param, data_feed)

        catalog_name           = uc_catalog_name
        delta_db_silver        = process_feed_df.select("delta_db_silver").first()[0]
        delta_db_gold          = process_feed_df.select("delta_db_gold").first()[0]
        delta_db_staging       = process_feed_df.select("delta_db_staging").first()[0]
        delta_path_staging     = process_feed_df.select("delta_path_staging").first()[0]
        delta_table_staging    = process_feed_df.select("delta_table_staging").first()[0]
        source_dir_path        = process_feed_df.select("source_file_path").first()[0]
        delta_gold_partitionBy = process_feed_df.select("delta_gold_partitionBy").first()[0]
        view_name              = process_feed_df.select("view_name").first()[0]
        stream                 = process_feed_df.select("stream").first()[0]

        # parse json fields from config
        delta_path_silver     = absolute_path+json.loads(process_feed_df.select("delta_path_silver").first()[0].replace("'", '"')).get(fact_type)
        delta_table_silver    = json.loads(process_feed_df.select("delta_table_silver").first()[0].replace("'", '"')).get(fact_type)
        delta_path_gold       = absolute_path+json.loads(process_feed_df.select("delta_path_gold").first()[0].replace("'", '"')).get(fact_type)
        delta_table_gold      = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'", '"')).get(fact_type)

        # construct table names
        source_table          = f"{catalog_name}.{delta_db_silver}.{delta_table_silver}"
        target_table          = f"{catalog_name}.{delta_db_gold}.{delta_table_gold}"

        delta_gold_partitionBy = [col.strip() for col in delta_gold_partitionBy.split(",")] if delta_gold_partitionBy else []

        # Reading fact metadata json file
        config_data        = get_config_data(data_feed, uc_catalog_name, stream)
        key_columns        = config_data.get("key_columns", [])
        overwrite_schema   = config_data.get("overwrite_schema", {})
        exclude_columns    = config_data.get("exclude_columns", "").strip()

        if debug_flag == "1":
            print(f"absolute_path                : {absolute_path}")
            print(f"catalog_name                 : {catalog_name}")
            print(f"delta_db_staging             : {delta_db_staging}")
            print(f"delta_db_silver              : {delta_db_silver}")
            print(f"delta_db_gold                : {delta_db_gold}")
            print(f"delta_path_staging           : {delta_path_staging}")
            print(f"delta_path_silver            : {delta_path_silver}")
            print(f"delta_path_gold              : {delta_path_gold}")
            print(f"delta_table_staging          : {delta_table_staging}")
            print(f"delta_table_silver           : {delta_table_silver}")
            print(f"delta_table_gold             : {delta_table_gold}")
            print(f"delta_gold_partitionBy       : {delta_gold_partitionBy}")
            print(f"key_columns                  : {key_columns}")
            print(f"source_dir_path              : {source_dir_path}")
            print(f"source_table                 : {source_table}")
            print(f"target_table                 : {target_table}")
            print(f"view_name                    : {view_name}")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Fetching config file columns for the gold ingestion failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e


# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformations and Executions

# COMMAND ----------

try:
    # === READING THE SILVER TABLE AS PER THE KEY VALUE ===

    if data_feed in ['finance_fact_bex_actuals','finance_fact_bex_brand','finance_fact_bex_brand_position', 'finance_fact_bex_customer','finance_fact_twc_actuals', 
                     'finance_fact_gmva_actuals']: 
        silver_df = spark.read.format("delta").table(source_table).filter(col("month_sk") == key_value) 

    elif data_feed in [ 'finance_fact_bex_forecast','finanvce_fact_bex_gmva_forecast','finanvce_fact_bex_twc_forecast']: 
        silver_df = spark.read.format("delta").table(source_table).filter(col("version_sk") == key_value)

    elif data_feed in [ 'finance_fact_offline_data']: 
        
        # Read Ingestion configuration sheet
        param                  = get_param_data(uc_catalog_name)
        process_feed_df        = fetch_config(param, data_feed)
        catalog_name           = uc_catalog_name
        stream                 = process_feed_df.select("stream").first()[0]
        delta_db_silver        = process_feed_df.select("delta_db_silver").first()[0]
        delta_db_gold          = process_feed_df.select("delta_db_gold").first()[0]
        delta_gold_partitionBy = process_feed_df.select("delta_gold_partitionBy").first()[0]
        delta_table_silver     = json.loads(process_feed_df.select("delta_table_silver").first()[0].replace("'",'"'))
        delta_path_gold        = json.loads(process_feed_df.select("delta_path_gold").first()[0].replace("'",'"'))
        delta_table_gold       = json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'",'"'))
        

        delta_gold_partitionBy = [col.strip() for col in delta_gold_partitionBy.split(",")] if delta_gold_partitionBy else []

        # Reading fact metadata json file
        config_data        = get_config_data(data_feed, uc_catalog_name, stream)
        key_columns        = config_data.get("key_columns", [])
        overwrite_schema   = config_data.get("overwrite_schema", {})
        exclude_columns    = config_data.get("exclude_columns", "").strip()

        #Assign table values from ingestion config file based on key
        df_dict = dict()
        key_list = delta_table_silver.keys()
        for key in key_list:
            if key == "actuals":
                delta_table_silver_act = delta_table_silver[key]
            elif key == "forecast":
                delta_table_silver_fct = delta_table_silver[key]

        #Assign path values from ingestion config file based on key
        df1_dict = dict()
        key_list = delta_path_gold.keys()
        for key in key_list:
            if key == "actuals":
                actuals_delta_path_gold = absolute_path+ delta_path_gold[key]
            elif key == "forecast":
                forecast_delta_path_gold = absolute_path+ delta_path_gold[key]        

                
        #Assign table values from ingestion config file based on key
        df_dict = dict()
        key_list = delta_table_gold.keys()
        for key in key_list:
            if key == "actuals":
                delta_table_gold_act = delta_table_gold[key]
            elif key == "forecast":
                delta_table_gold_fct = delta_table_gold[key]
        
        if debug_flag == "1":
            print(f"absolute_path                : {absolute_path}")
            print(f"catalog_name                 : {catalog_name}")
            print(f"delta_db_silver              : {delta_db_silver}")
            print(f"delta_table_silver_actuals   : {delta_table_silver_act}")
            print(f"delta_table_silver_forecast  : {delta_table_silver_fct}")
            print(f"delta_path_gold_actuals      : {actuals_delta_path_gold}")
            print(f"delta_path_gold_actuals      : {forecast_delta_path_gold}")
            print(f"delta_db_gold                : {delta_db_gold}")
            print(f"delta_table_gold_actuals     : {delta_table_gold_act}")
            print(f"delta_table_gold_forecast    : {delta_table_gold_fct}")
            print(f"delta_gold_partitionBy       : {delta_gold_partitionBy}")
            print(f"key_columns                  : {key_columns}")
            
    else:
        silver_df = spark.read.format("delta").table(source_table)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log( int(detail_log_value + counter), log_value, run_id, username, "Unpivoting map forecast columns for the gold ingestion failure", datetime.now(), 
        status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write into Gold Staging Delta path
# MAGIC This function responsible 
# MAGIC - Ingestion type
# MAGIC - Table creation for specific DB
# MAGIC - concurent delta write
# MAGIC - Table schema check and raise

# COMMAND ----------

try:
    if data_feed in [ 'finance_fact_offline_data']:
        
        #Actuals

        # construct table names
        source_table        = f"{catalog_name}.{delta_db_silver}.{delta_table_silver_act}"
        silver_df           = spark.read.format("delta").table(source_table)

        partition_columns=['month_sk']

        # === WRITING THE DATAFRAME TO GOLD TABLE USING CONCURRENT EXTERNAL TABLE DELTA WRITE ===
        concurrent_external_table_delta_write(silver_df, actuals_delta_path_gold, delta_db_gold, delta_table_gold_act, partition_columns, catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )


        #Forecast

        # construct table names
        source_table          = f"{catalog_name}.{delta_db_silver}.{delta_table_silver_fct}"
        silver_df             = spark.read.format("delta").table(source_table)

        partition_columns=['version_sk']

        # === WRITING THE DATAFRAME TO GOLD TABLE USING CONCURRENT EXTERNAL TABLE DELTA WRITE ===
        concurrent_external_table_delta_write(silver_df, forecast_delta_path_gold, delta_db_gold, delta_table_gold_fct, partition_columns, catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )
    
    else:

        # === WRITING THE DATAFRAME TO GOLD TABLE USING CONCURRENT EXTERNAL TABLE DELTA WRITE ===
        concurrent_external_table_delta_write(silver_df, delta_path_gold, delta_db_gold, delta_table_gold,delta_gold_partitionBy, catalog_name, object_owner_spn, retry_count=0,  mergeSchema_flag = False , delta_overwrite_mode = "full" )

except Exception as e:
    error      = str(e).replace("'", "")
    error_code = type(e).__name__
    counter   += 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Writing to gold delta failed", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e
else :
    counter = counter+1
    insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "gold delta table write completed", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

# COMMAND ----------

try:
    if data_feed in [ 'finance_fact_offline_data']:

        #Define Parameters
        actual_params = {
        "fact_table"    : delta_table_gold_act,
        "uc_catalog_name": uc_catalog_name,
        "external_location": external_location,
        "object_owner_spn": object_owner_spn,
        "debug_flag": debug_flag
        }

        print("Executing: nb_pmrs_fact_measures_to_columns_reporting for Actuals...")
        result = dbutils.notebook.run("/Workspace/data_engineering/gold/ifinance/nb_pmrs_fact_measures_to_columns_reporting", -1, actual_params)
        print("Notebook execution completed successfully!")

        #Define Parameters
        forecast_params = {
        "fact_table"    : delta_table_gold_fct,
        "uc_catalog_name": uc_catalog_name,
        "external_location": external_location,
        "object_owner_spn": object_owner_spn,
        "debug_flag": debug_flag
        }

        print("Executing: nb_pmrs_fact_measures_to_columns_reporting for Forecast...")
        result = dbutils.notebook.run("/Workspace/data_engineering/gold/ifinance/nb_pmrs_fact_measures_to_columns_reporting", -1, forecast_params)
        print("Notebook execution completed successfully!")

except Exception as e:
    print(f"Error occurred: {str(e)}")
    raise Exception(f"Parent notebook failed due to child error: {str(e)}")

# COMMAND ----------

# === INSERT JOB LOG AND JOB DETAIL LOG ENTRY ===
counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, f"Gold Ingestion completed for {data_feed}", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
