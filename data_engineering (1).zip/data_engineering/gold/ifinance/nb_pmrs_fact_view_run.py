# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Job Logging Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 6 Sept 2024        |    Vinod               |    Created View .        |
# MAGIC | 22 April 2025      |    Gokul Prasanth       |   additional fact func  |
# MAGIC
# MAGIC ## Purpose
# MAGIC The Purpose of this notebook is to create View for PBI.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks, Functions and Library

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, DoubleType
import json

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

debug_flag          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
external_location   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
username            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
file_name           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="file_name")
log_id              = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")

dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("file_name", file_name)
dbutils.jobs.taskValues.set("log_id", log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    #run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    
    log_id = int(log_id)
    run_id = log_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 4
detail_log_value = (log_value * 10) 

insert_job_log(log_value, job_id, run_id, username,"Ifinance view creation", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Gold to view creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### catalog details

# COMMAND ----------

# Using the specified catalog
spark.sql(f"USE CATALOG {uc_catalog_name}")

# Creating the schema if it does not exist
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `gold_finance`;")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Reading the view creation configurations data 
# MAGIC - view creation configuration

# COMMAND ----------

try:
    if data_feed not in ["finance_fact_offline_data"]:

        # ------------------Reading the Ingestion_Configuration_sheet-------------------#
        if data_feed not in ["market_fact_gmi_snapshot", "market_fact_business_winning"]:
            hbu_code = file_name.split('#')[2]
            if "HBU1" in hbu_code:
                dimension_code, fact_type = "mu", "dimension_mu"
            elif "HBU3" in hbu_code:
                dimension_code, fact_type = "sc", "dimension_sc"
            print(f"Dimension Code: {dimension_code}, Fact Type: {fact_type}")
    
        param              =   get_param_data(uc_catalog_name)
        process_feed_df    =   fetch_config(param, data_feed)
        gold_db_name       =   process_feed_df.select("delta_db_gold").first()[0]
        gold_table_name    =   json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'", '"')).get(fact_type)
        view_name          =   json.loads(process_feed_df.select("view_name").first()[0].replace("'", '"')).get(fact_type)

        if debug_flag == "1":
            print('uc_catalog_name      :', uc_catalog_name)
            print('gold_db_name         :', gold_db_name)
            print('gold_table_name      :', gold_table_name)
            print('view_name            :', view_name)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the view creation failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md 
# MAGIC ####Delta table check

# COMMAND ----------

def check_table_exists(uc_catalog_name, schema_name, table_name):
    table_exists = spark.catalog.tableExists(f"{uc_catalog_name}.{schema_name}.{table_name}")
    if table_exists:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} exists.")
    else:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")
        raise Exception(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fact **Views**

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_actuals" and dimension_code == "mu" and fact_type == "dimension_mu":
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS INT) AS `BU SK`,
                        CAST(f.product_sk AS INT) AS `Product SK`,
                        CAST(f.product_sk * 10000 + f.bu_sk AS INT) as `Cell SK`,
                        CAST(f.month_sk AS INT) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS INT) AS `Currency SK`,
                        CAST(f.version_sk AS INT) AS `Version SK`,
                        CAST(f.flow_sk AS INT) AS `Flow SK`,
                        CAST(f.measure_sk AS INT) AS `Measure SK`,
                        CONCAT(bu.mu_hier_level_5_description, ' ', prod.`Category Cell`) AS `Cell`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                        FROM
                            {uc_catalog_name}.gold_finance.fact_actuals_map f
                        INNER JOIN
                            ( SELECT *
                                FROM
                            {uc_catalog_name}.gold_master_data.business_unit ) bu
                            ON f.bu_sk = bu.bu_sk
                        INNER JOIN
                            ( SELECT *
                                FROM
                            {uc_catalog_name}.gold_master_data.vw_product_extended) prod
                            ON prod.`Product SK` = f.product_sk
                                INNER JOIN
                            {uc_catalog_name}.gold_master_data.measure m
                            ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
                        where f.bu_sk != -1 and f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_actuals" and dimension_code == "sc" and fact_type == "dimension_sc":
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS INT) AS `BU SK`,
                        CAST(f.product_sk AS INT) AS `Product SK`,
                        CAST(f.product_sk * 10000 + f.bu_sk AS INT) as `Cell SK`,
                        CAST(f.month_sk AS INT) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS INT) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS INT) AS `Currency SK`,
                        CAST(f.version_sk AS INT) AS `Version SK`,
                        CAST(f.flow_sk AS INT) AS `Flow SK`,
                        CAST(f.measure_sk AS INT) AS `Measure SK`,
                        CONCAT(bu.mu_hier_level_5_description, ' ', prod.`Category Cell`) AS `Cell`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                        FROM
                            {uc_catalog_name}.gold_finance.fact_actuals_sc_map f
                        INNER JOIN
                            ( SELECT *
                                FROM
                            {uc_catalog_name}.gold_master_data.business_unit ) bu
                            ON f.bu_sk = bu.bu_sk
                        INNER JOIN
                            ( SELECT *
                                FROM
                            {uc_catalog_name}.gold_master_data.vw_product_extended) prod
                            ON prod.`Product SK` = f.product_sk
                                INNER JOIN
                            {uc_catalog_name}.gold_master_data.measure m
                            ON f.measure_sk = m.measure_sk AND m.measure_type = 'PnL Direct Measures'
                        where f.bu_sk != -1 and f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_forecast" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.forecast_level_sk AS int) AS `Forecast Level SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.gold_finance.fact_forecast_map f
                    inner join {uc_catalog_name}.gold_master_data.measure m 
                        ON f.measure_sk = m.measure_sk and m.measure_type='PnL Direct Measures' 
                    where f.bu_sk !=-1 and f.product_sk!=-1""")
            
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_brand" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.brand_sk AS int) AS `Brand SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM 
                        {uc_catalog_name}.gold_finance.fact_brand f 
                    where f.bu_sk !=-1 and f.product_sk!=-1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_brand_position" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                SELECT
                    f.bu_sk AS `BU SK`,
                    f.product_sk AS `Product SK`,
                    f.brand_position_sk AS `Brand Position SK`,
                    f.month_sk AS `Month SK`,
                    f.cont_disc_ops_sk AS `Cont Discont Ops SK`,
                    f.currency_sk AS `Currency SK`,
                    f.version_sk AS `Version SK`,
                    f.flow_sk AS `Flow SK`,
                    f.measure_sk AS `Measure SK`,
                    CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                    CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                CASE
                    WHEN p.division_code = 'CF1159'
                    THEN bp.brand_position_level_2_code
                    ELSE bp.brand_position_finance_code
                END AS `Brand Position Code`,
                CASE
                    WHEN p.division_code = 'CF1159'
                    THEN bp.brand_position_level_2_description
                    ELSE bp.brand_position_description
                END AS `Brand Position Description`
                FROM {uc_catalog_name}.silver_finance.fact_brand_position f
                LEFT JOIN {uc_catalog_name}.gold_master_data.brand_position bp
                    ON f.brand_position_sk = bp.brand_position_sk
                LEFT JOIN {uc_catalog_name}.gold_master_data.product p
                    ON f.product_sk = p.product_sk
                WHERE f.bu_sk != -1 AND f.product_sk != -1 """)
 
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_customer" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.customer_sk AS int) AS `Customer SK`,
                        CAST(f.channel_sk AS int) AS `Customer Channel SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.gold_finance.fact_customer f
                    where f.bu_sk !=-1 and f.product_sk!=-1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_twc_actuals":
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.company_sk AS int) AS `Company SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.gold_finance.fact_twc_actuals f
                    WHERE
                        f.bu_sk != -1 AND f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_gmva_actuals":
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.company_sk AS int) AS `Company SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.gold_finance.fact_gmva_actuals f
                    WHERE
                        f.bu_sk != -1 AND f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_bex_gmva_forecast" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.company_sk AS int) AS `Company SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.forecast_level_sk AS int) AS `Forecast Level SK`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.gold_finance.fact_gmva_forecast f
                    where
                        f.bu_sk != -1  and f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "market_fact_gmi_snapshot" :

        gold_db_name_dict = json.loads(gold_db_name.replace("'",'"'))
        gold_table_name_dict = json.loads(gold_table_name.replace("'",'"'))
        gold_db_name_gmi = gold_db_name_dict[list(gold_db_name_dict.keys())[0]]
        check_table_exists(uc_catalog_name, gold_db_name_gmi, list(gold_table_name_dict.keys())[0])
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name_gmi}.{view_name} AS
                    SELECT
                    cbm.`BU SK` as `BU SK`,
                    F.product_sk as `Product SK`,
                    F.brand_sk as `Brand SK`,
                    F.brand_position_sk as `Brand Position SK`,
                    F.flow_sk as `Flow SK`,
                    F.month_sk as `Month SK`,
                    F.measure_sk as `Measure SK`,
                    F.geography_sk as `Geography SK`,
                    F.manufacturer_sk as `Manufacturer SK`,
                    F.value as `Value`,
                    CAST(F.created_date AS TIMESTAMP) AS `Created Date`
                    from
                    {uc_catalog_name}.gold_market.{list(gold_table_name_dict.keys())[0]} as F
                        inner join {uc_catalog_name}.gold_master_data.vw_country_bu_map cbm on F.geography_sk = cbm.`Geography SK`
                    """)
        
        print(f"{uc_catalog_name}.{gold_db_name_gmi}.{view_name} view created successfully.")

        # Creating Manufacturer View

        gold_db_name_dict = json.loads(gold_db_name.replace("'",'"'))
        gold_table_name_dict = json.loads(gold_table_name.replace("'",'"'))
        gold_db_name = gold_db_name_dict[list(gold_db_name_dict.keys())[2]]
        gold_table_name = list(gold_table_name_dict.keys())[2]
        view_name_manu = f"vw_{gold_table_name}"
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name_manu} AS
                    SELECT
                        manufacturer_sk AS `Manufacturer SK`,
                        local_manufacturer_code AS `Local Manufacturer Code`,
                        local_manufacturer_name AS `Local Manufacturer Name`,
                        global_manufacturer_code AS `Global Manufacturer Code`,
                        global_manufacturer_name AS `Global Manufacturer Name`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name_manu} view created successfully.")


except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "market_fact_bw_usg" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                    f.geography_sk As `Geography SK`,
                    f.product_sk As `Product SK`,
                    f.month_sk As `Month SK`,
                    f.measure_sk As `Measure SK`,
                    f.flow_sk As `Flow SK`,
                    f.value As `Value`,
                    CAST(f.created_date AS TIMESTAMP) AS `Created Date`
					From
					{uc_catalog_name}.{gold_db_name}.{gold_table_name} as f
                    """)
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "market_fact_bw_usg" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                    f.geography_sk As `Geography SK`,
                    f.product_sk As `Product SK`,
                    f.month_sk As `Month SK`,
                    f.measure_sk As `Measure SK`,
                    f.flow_sk As `Flow SK`,
                    f.value As `Value`,
                    CAST(f.created_date AS TIMESTAMP) AS `Created Date`
					From
					{uc_catalog_name}.{gold_db_name}.{gold_table_name} as f
                    """)
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "finance_fact_offline_data" :
    
        param              =   get_param_data(uc_catalog_name)
        process_feed_df    =   fetch_config(param, data_feed)
        gold_db_name       =   process_feed_df.select("delta_db_gold").first()[0]
        delta_table_gold   =   json.loads(process_feed_df.select("delta_table_gold").first()[0].replace("'",'"'))
        view_name          =   json.loads(process_feed_df.select("view_name").first()[0].replace("'",'"'))
               
        #Assign table values from ingestion config file based on key
        df_dict = dict()
        key_list = delta_table_gold.keys()
        for key in key_list:
            if key == "actuals":
                delta_table_gold_act = delta_table_gold[key]
            elif key == "forecast":
                delta_table_gold_fct = delta_table_gold[key]

        #Assign table values from ingestion config file based on key
        df_dict = dict()
        key_list = view_name.keys()
        for key in key_list:
            if key == "actuals":
                view_act = view_name[key]
            elif key == "forecast":
                view_fct = view_name[key]

        if debug_flag == "1":
        
            print('uc_catalog_name          :', uc_catalog_name)
            print('gold_db_name             :', gold_db_name)
            print('actuals_gold_table_name  :', delta_table_gold_act)
            print('forecast_gold_table_name :', delta_table_gold_fct)
            print('actuals_view_name        :', view_act)
            print('forecast_view_name       :', view_fct)

        #Actuals
        check_table_exists(uc_catalog_name, gold_db_name, delta_table_gold_act)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_act} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.brand_sk AS int) AS `Brand SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.customer_sk AS int) AS `Customer SK`,
                        CAST(f.company_sk AS int) AS `Company SK`,
                        CAST(f.customer_channel_sk AS int) AS `Customer Channel SK`,
                        CAST(f.data_source AS string) AS `Data Source`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,                        
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{delta_table_gold_act} f
                    WHERE
                        f.bu_sk != -1 AND f.product_sk != -1""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_act} view created successfully.")


        #Forecast
        check_table_exists(uc_catalog_name, gold_db_name, delta_table_gold_fct)
        spark.sql(f""" 
                  CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_fct} AS
                    SELECT
                        CAST(f.bu_sk AS int) AS `BU SK`,
                        CAST(f.product_sk AS int) AS `Product SK`,
                        CAST(f.month_sk AS int) AS `Month SK`,
                        CAST(f.brand_sk AS int) AS `Brand SK`,
                        CAST(f.cont_disc_ops_sk AS int) AS `Cont Discont Ops SK`,
                        CAST(f.currency_sk AS int) AS `Currency SK`,
                        CAST(f.version_sk AS int) AS `Version SK`,
                        CAST(f.flow_sk AS int) AS `Flow SK`,
                        CAST(f.customer_sk AS int) AS `Customer SK`,
                        CAST(f.company_sk AS int) AS `Company SK`,
                        CAST(f.customer_channel_sk AS int) AS `Customer Channel SK`,
                        CAST(f.data_source AS string) AS `Data Source`,
                        CAST(f.measure_sk AS int) AS `Measure SK`,                        
                        CAST(f.value AS DECIMAL(36,16)) AS `Value`,
                        CAST(f.created_date AS TIMESTAMP) AS `Created Date`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{delta_table_gold_fct} f
                    WHERE
                        f.bu_sk != -1 AND f.product_sk != -1""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_fct} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating Offline data view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####View creation completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job(job_id,run_id, module_id, feed_type_id, feed_id, status_success_id,uc_catalog_name)
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Fact view creation completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
