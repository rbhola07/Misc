# Databricks notebook source
from pyspark.sql.functions import *
from functools import reduce as red_func

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config" 

# COMMAND ----------

dbutils.widgets.removeAll()

external_location                 = dbutils.widgets.text("external_location","")
uc_catalog_name                   = dbutils.widgets.text("uc_catalog_name","")
object_owner_spn                  = dbutils.widgets.text("object_owner_spn","")
debug_flag                        = dbutils.widgets.text("debug_flag","")
data_feed                         = dbutils.widgets.text("data_feed","")

external_location                 = dbutils.widgets.get("external_location")
uc_catalog_name                   = dbutils.widgets.get("uc_catalog_name")
object_owner_spn                  = dbutils.widgets.get("object_owner_spn")
debug_flag                        = dbutils.widgets.get("debug_flag")
data_feed                         = dbutils.widgets.get("data_feed")

# COMMAND ----------

absolute_path                   = return_absolute_path(external_location)

print('absolute_path            :', absolute_path)
print('uc_catalog_name          :', uc_catalog_name)
print('object_owner_spn         :', object_owner_spn)
print('debug_flag               :', debug_flag)
print('external_location        :', external_location)
print('data_feed                :', data_feed)

# COMMAND ----------

# MAGIC %md
# MAGIC ## BU Hierarcy Extended

# COMMAND ----------

if "bu_hierarchies" in data_feed:

   print("1st Condition Passed")
   
   bu    = spark.table(f"{uc_catalog_name}.gold_master_data.business_unit").filter(col("is_active")==True)
   buh   = spark.table(f"{uc_catalog_name}.gold_master_data.bu_hierarchies").filter(col("is_active")==True)

   conditions = (

      ((buh.level_5_code.isNotNull()) & (buh.level_4_code.isNotNull()) & 
      (buh.level_3_code.isNotNull()) & (buh.level_2_code.isNotNull()) & 
      (buh.level_1_code.isNotNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_5_code == bu.mu_hier_level_5_code) & 
      (buh.level_4_code == bu.mu_hier_level_4_code) & 
      (buh.level_3_code == bu.mu_hier_level_3_code) & 
      (buh.level_2_code == bu.mu_hier_level_2_code) & 
      (buh.level_1_code == bu.mu_hier_level_1_code) & 
      (buh.level_0_code == bu.mu_hier_level_0_code)) |

      ((buh.level_5_code.isNull()) & (buh.level_4_code.isNotNull()) &
      (buh.level_3_code.isNotNull()) & (buh.level_2_code.isNotNull()) & 
      (buh.level_1_code.isNotNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_4_code == bu.mu_hier_level_4_code) &
      (buh.level_3_code == bu.mu_hier_level_3_code) &
      (buh.level_2_code == bu.mu_hier_level_2_code) &
      (buh.level_1_code == bu.mu_hier_level_1_code) &
      (buh.level_0_code == bu.mu_hier_level_0_code)) |

      ((buh.level_5_code.isNull()) & (buh.level_4_code.isNull()) &
      (buh.level_3_code.isNotNull()) & (buh.level_2_code.isNotNull()) &
      (buh.level_1_code.isNotNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_3_code == bu.mu_hier_level_3_code) &
      (buh.level_2_code == bu.mu_hier_level_2_code) &
      (buh.level_1_code == bu.mu_hier_level_1_code) &
      (buh.level_0_code == bu.mu_hier_level_0_code)) |

      
      ((buh.level_5_code.isNull()) & (buh.level_4_code.isNull()) & 
      (buh.level_3_code.isNull()) & (buh.level_2_code.isNotNull()) & 
      (buh.level_1_code.isNotNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_2_code == bu.mu_hier_level_2_code) &
      (buh.level_1_code == bu.mu_hier_level_1_code) &
      (buh.level_0_code == bu.mu_hier_level_0_code)) |
      
      ((buh.level_5_code.isNull()) & (buh.level_4_code.isNull()) & 
      (buh.level_3_code.isNull()) & (buh.level_2_code.isNull()) &
      (buh.level_1_code.isNotNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_1_code == bu.mu_hier_level_1_code) &
      (buh.level_0_code == bu.mu_hier_level_0_code)) |

      ((buh.level_5_code.isNull()) & (buh.level_4_code.isNull()) & 
      (buh.level_3_code.isNull()) & (buh.level_2_code.isNull()) &
      (buh.level_1_code.isNull()) & (buh.level_0_code.isNotNull()) &
      (buh.level_0_code == bu.mu_hier_level_0_code)))

   result = bu.alias('a').join(buh.alias('b'), conditions, how="inner").select("b.*", "a.bu_sk")
   
   result.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("2nd Condition Passed")

    df          = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.bu_hierarchies").filter(col("is_active")==True)

    columns     = ["level_0_code","level_1_code","level_2_code","level_3_code","level_4_code","level_5_code"]

    distinct_df = df.select(col(columns[0]).alias("code")).distinct()

    for col_name in columns[1:]:

        distinct_df = distinct_df.union(
            df.select(col(col_name).alias("code")).distinct()
        )

    distinct_without_dl_df  = distinct_df.distinct().filter(~col("code").like("%DL_-%"))

    sort_order_df = (
        df.select(
            col("level_0_code").alias("code"),
            col("level_0_sort_order"),
            lit(None).alias("level_1_sort_order"),
            lit(None).alias("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct()

        .unionByName(df.select(
            col("level_1_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            lit(None).alias("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_2_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_3_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_4_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            col("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_5_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            col("level_4_sort_order"),
            col("level_5_sort_order")
        ).distinct())
    ).filter(col("code").isNotNull())

    sort_order_df.display()
    distinct_without_dl_df.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:
    
    print("3rd Condition Passed")
    
    distinct_values   = [row['code'] for row in distinct_without_dl_df.filter(col("code").isNotNull()).collect()]

    # like_clause       = " OR ".join([f"bu_code LIKE '%DL_-{val}%'" for val in distinct_values] + [f"bu_code LIKE '%CBU-{val}%'" for val in distinct_values])

    like_clause       = " OR ".join([f"bu_code LIKE '%DL_-{val}%'" for val in distinct_values])

    query             = f""" SELECT  *  FROM {uc_catalog_name}.silver_master_data.business_unit WHERE {like_clause} and is_active is True and source not in ("calculated","local finance")"""

    dummy_df = spark.sql(query)

    dummy_df = dummy_df.join(sort_order_df, sort_order_df.code == substring(dummy_df.bu_code,5,100) , how="left") \
    .withColumn("level_0_sort_order", col("level_0_sort_order")).drop("code") \
    .select(
    col("bu_sk").alias("bu_sk"),
    col("mu_hier_level_5_code").alias("level_5_code"),
    col("mu_hier_level_5_description").alias("level_5_description"),
    col("mu_hier_level_4_code").alias("level_4_code"),
    col("mu_hier_level_4_description").alias("level_4_description"),
    col("mu_hier_level_3_code").alias("level_3_code"),
    col("mu_hier_level_3_description").alias("level_3_description"),
    col("mu_hier_level_2_code").alias("level_2_code"),
    col("mu_hier_level_2_description").alias("level_2_description"),
    col("mu_hier_level_1_code").alias("level_1_code"),
    col("mu_hier_level_1_description").alias("level_1_description"),
    col("mu_hier_level_0_code").alias("level_0_code"),
    col("mu_hier_level_0_description").alias("level_0_description"),
    col("level_0_sort_order").alias("level_0_sort_order"),
    col("level_1_sort_order").alias("level_1_sort_order"),
    col("level_2_sort_order").alias("level_2_sort_order"),
    col("level_3_sort_order").alias("level_3_sort_order"),
    col("level_4_sort_order").alias("level_4_sort_order"),
    col("level_5_sort_order").alias("level_5_sort_order")) \
    .withColumn("dashboard_type",lit("BUBG")) \
    .filter(col("level_0_code").isNotNull())

    dummy_df.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("4th Condition Passed")
    
    dummies_cols        = set(dummy_df.columns)

    view_cols           = set(result.drop("log_id","created_date").columns)

    missing_cols        = view_cols - dummies_cols

    print(missing_cols)

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("5th Condition Passed")
    
    for col_name in missing_cols:

        dummy_df        = dummy_df.withColumn(col_name, lit(None).cast(result.schema[col_name].dataType))

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("6th Condition Passed")
    
    dummy_keys      = dummy_df.select("bu_sk").distinct()

    result_filtered = result.join(dummy_keys, on="bu_sk", how="left_anti").drop("log_id", "created_date")

    combined_df     = dummy_df.unionByName(result_filtered)

    combined_df.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("7th Condition Passed")
    
    view_df         = combined_df

    renamed_columns = {col: col.replace(" ", "_").lower() for col in view_df.columns}

    view_df         = view_df.select([col(c).alias(f"hier_{c}") for c in view_df.columns])

    dim_df          = spark.table(f"{uc_catalog_name}.silver_master_data.business_unit ").alias("a") \
                        .join(spark.table(f"{uc_catalog_name}.gold_master_data.geography").alias("b"),on="mu_iso_country_code",how="left") \
                        .drop(col("b.mu_iso_country_code"),col("b.source"),col("b.is_active"),col("b.has_data"),col("b.log_id"),col("b.created_date"),col("b.updated_date"))

    dim_df          =   dim_df.select([col(c).alias(f"dim_{c}") for c in dim_df.columns])

    join_df         = dim_df.join(view_df, col("`dim_bu_sk`") == col("hier_bu_sk"), "left") \
                        .select(
                        "dim_bu_sk",
                        "dim_bu_code",
                        "dim_bu_description",
                        "dim_mu_code",
                        "dim_mu_description",
                        "dim_mu_hier_level_5_code",
                        "dim_mu_hier_level_5_description",
                        "dim_mu_hier_level_4_code",
                        "dim_mu_hier_level_4_description",
                        "dim_mu_hier_level_3_code",
                        "dim_mu_hier_level_3_description",
                        "dim_mu_hier_level_2_code",
                        "dim_mu_hier_level_2_description",
                        "dim_mu_hier_level_1_code",
                        "dim_mu_hier_level_1_description",
                        "dim_mu_hier_level_0_code",
                        "dim_mu_hier_level_0_description",
                        "dim_mu_iso_country_code",
                        "dim_mu_iso_country_description",
                        "dim_sc_mu_code",
                        "dim_sc_mu_description",
                        "dim_sc_level_6_code",
                        "dim_sc_level_6_description",
                        "dim_sc_level_5_code",
                        "dim_sc_level_5_description",
                        "dim_sc_level_4_code",
                        "dim_sc_level_4_description",
                        "dim_sc_level_3_code",
                        "dim_sc_level_3_description",
                        "dim_sc_level_2_code",
                        "dim_sc_level_2_description",
                        "dim_sc_level_1_code",
                        "dim_sc_level_1_description",
                        "dim_sc_level_0_code",
                        "dim_sc_level_0_description",
                        "dim_sc_mu_iso_country_code",
                        "dim_sc_mu_iso_country_description",
                        "dim_source",
                        "dim_world_description",
                        "dim_world_code",
                        "dim_region_description",
                        "dim_region_code",
                        "dim_unilever_pmu_description",
                        "dim_unilever_pmu_code",
                        "dim_country_cluster_description",
                        "dim_country_cluster_code",
                        "dim_country_group_description",
                        "dim_country_group_code",
                        "dim_country_sub_group_description",
                        "dim_country_sub_group_code",
                        "dim_market_type_description",
                        "dim_market_type_code",
                        "dim_iso_country_dependency_code",
                        "dim_is_active",
                        "dim_dummy_flag",
                        "dim_has_data",
                        "hier_level_5_code",
                        "hier_level_5_description",
                        "hier_level_4_code",
                        "hier_level_4_description",
                        "hier_level_3_code",
                        "hier_level_3_description",
                        "hier_level_2_code",
                        "hier_level_2_description",
                        "hier_level_1_code",
                        "hier_level_1_description",
                        "hier_level_0_code",
                        "hier_level_0_description",
                        "hier_dashboard_type",
                        "hier_level_1_sort_order",
                        "hier_level_4_sort_order",
                        "hier_level_2_sort_order",
                        "hier_level_3_sort_order",
                        "hier_level_5_sort_order",
                        "hier_level_0_sort_order"
                        )

    join_df.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("8th Condition Passed")
    
    columns_to_rename=[]

    type_prefixes = [
                    row["hier_dashboard_type"]
                    for row in join_df.select("hier_dashboard_type")
                    .filter(col("hier_dashboard_type").isNotNull())
                    .distinct()
                    .collect()
                    ]

    print(type_prefixes)

    cols = [
    "hier_level_5_code",
    "hier_level_5_description",
    "hier_level_4_code",
    "hier_level_4_description",
    "hier_level_3_code",
    "hier_level_3_description",
    "hier_level_2_code",
    "hier_level_2_description",
    "hier_level_1_code",
    "hier_level_1_description",
    "hier_level_0_code",
    "hier_level_0_description",
    "hier_dashboard_type",
    "hier_level_1_sort_order",
    "hier_level_4_sort_order",
    "hier_level_2_sort_order",
    "hier_level_3_sort_order",
    "hier_level_5_sort_order",
    "hier_level_0_sort_order"
    ]

    columns_to_rename  = ["hier_dashboard_type"]

    columns_to_rename += [c for c in join_df.select(*cols).columns if c.startswith("hier_level_")]

    print(columns_to_rename,len(columns_to_rename))

# COMMAND ----------

if "bu_hierarchies" in data_feed:
    
    print("9th Condition Passed")

    renamed_exprs = []

    for prefix in type_prefixes:
        for c in columns_to_rename:
            if c.startswith("hier_level_"):
                new_c = c.replace("hier_", "")
                renamed_exprs.append(f"`{c}` as {prefix}_{new_c}")
            elif c == "hier_dashboard_type":
                new_c = c.replace("hier", "")
                renamed_exprs.append(f"`{c}` as {prefix}{new_c}")

    base_columns = [f"`{c}`" for c in join_df.columns if c not in columns_to_rename]

    final_expr = base_columns + renamed_exprs

    final_df = join_df.selectExpr(*final_expr)

    final_df.display()

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("10th Condition Passed")
    
    full_path = absolute_path + "data_engineering/gold/master_data/business_unit_extended"

    spark.sql(f"""DROP TABLE   IF EXISTS {uc_catalog_name}.gold_master_data.business_unit_extended""")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_master_data.business_unit_extended USING DELTA LOCATION '{full_path}'""")

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("11th Condition Passed")
    
    final_df.drop("hier_bu_sk").write.mode("overwrite").option("overwriteSchema", "true").save(full_path)

# COMMAND ----------

if "bu_hierarchies" in data_feed:

    print("12th Condition Passed")
    
    spark.sql(f"""
    create or replace view {uc_catalog_name}.gold_master_data.vw_business_unit_extended 
    as
    select 
    dim_bu_sk       as `BU SK`,
    dim_bu_code as `BU Code`,
    dim_bu_description as `BU Description`,
    dim_mu_code as `MU Code`,
    dim_mu_description              as `MU Description`,
    dim_mu_hier_level_5_code        as  `MU Hier Level 5 Code`,
    dim_mu_hier_level_5_description as `MU Hier Level 5 Description`,
    dim_mu_hier_level_4_code        as `MU Hier Level 4 Code`,
    dim_mu_hier_level_5_description as `MU Hier Level 4 Description`,
    dim_mu_hier_level_3_code        as `MU Hier Level 3 Code`,
    dim_mu_hier_level_3_description as `MU Hier Level 3 Description`,
    dim_mu_hier_level_2_code        as  `MU Hier Level 2 Code`,
    dim_mu_hier_level_2_description as `MU Hier Level 2 Description`,
    dim_mu_hier_level_1_code as `MU Hier Level 1 Code`,
    dim_mu_hier_level_1_description as `MU Hier Level 1 Description`,
    dim_mu_hier_level_0_code as `MU Hier Level 0 Code`,
    dim_mu_hier_level_5_description as `MU Hier Level 0 Description`,
    dim_mu_iso_country_code as `MU ISO Country Code`,
    dim_mu_iso_country_description as `MU ISO Country Description`,
    dim_sc_mu_code as `SC MU Code`,
    dim_sc_mu_description as `SC MU Description`,
    dim_sc_level_6_code as `SC Level 6 Code`,
    dim_sc_level_6_description as `SC Level 6 Description`,
    dim_sc_level_5_code as `SC Level 5 Code`,
    dim_sc_level_5_description as `SC Level 5 Description`,
    dim_sc_level_4_code as `SC Level 4 Code`,
    dim_sc_level_4_description as `SC Level 4 Description`,
    dim_sc_level_3_code as `SC Level 3 Code`,
    dim_sc_level_3_description as `SC Level 3 Description`,
    dim_sc_level_2_code as `SC Level 2 Code`,
    dim_sc_level_2_description as `SC Level 2 Description`,
    dim_sc_level_1_code as `SC Level 1 Code`,
    dim_sc_level_1_description as `SC Level 1 Description`,
    dim_sc_level_0_code as `SC Level 0 Code`,
    dim_sc_level_0_description as `SC Level 0 Description`,
    dim_sc_mu_iso_country_code as `SC MU ISO Country Code`,
    dim_sc_mu_iso_country_description as `SC MU ISO Country Description`,
    dim_source as `Source`,
    dim_is_active AS `Is Active`,
    dim_has_data AS `Has Data`,
    dim_dummy_flag AS `Dummy Flag`,
    dim_world_description AS `World Description`,
    dim_world_code AS `World Code`,
    dim_region_description AS `Region Description`,
    dim_region_code AS `Region Code`,
    dim_unilever_pmu_description AS `Unilever PMU Description`,
    dim_unilever_pmu_code AS `Unilever PMU Code`,
    dim_country_cluster_description AS `Country Cluster Description`,
    dim_country_cluster_code AS `Country Cluster Code`,
    dim_country_group_description AS `Country Group Description`,
    dim_country_group_code AS `Country Group Code`,
    dim_country_sub_group_description AS `Country Sub Group Description`,
    dim_country_sub_group_code AS `Country Sub Group Code`,
    dim_market_type_description AS `Market Type Description`,
    dim_market_type_code AS `Market Type Code`,
    bubg_level_0_code           AS `BUBG Level 0 Code`,
    bubg_level_0_description AS `BUBG Level 0 Description`,
    cast(bubg_level_0_sort_order as INT) AS `BUBG Level 0 Sort Order`,
    bubg_level_1_code AS `BUBG Level 1 Code`,
    bubg_level_1_description AS `BUBG Level 1 Description`,
    cast(bubg_level_1_sort_order as INT) AS `BUBG Level 1 Sort Order`,
    bubg_level_2_code AS `BUBG Level 2 Code`,
    bubg_level_2_description AS `BUBG Level 2 Description`,
    cast(bubg_level_2_sort_order AS INT) AS `BUBG Level 2 Sort Order`,
    bubg_level_3_code AS `BUBG Level 3 Code`,
    bubg_level_3_description AS `BUBG Level 3 Description`,
    cast(bubg_level_3_sort_order AS INT) AS `BUBG Level 3 Sort Order`,
    bubg_level_4_code  AS `BUBG Level 4 Code`,
    bubg_level_4_description AS `BUBG Level 4 Description`,
    cast(bubg_level_4_sort_order AS INT) AS `BUBG Level 4 Sort Order`,
    bubg_level_5_code AS `BUBG Level 5 Code`,
    bubg_level_5_description AS `BUBG Level 5 Description`,
    cast(bubg_level_5_sort_order AS INT) AS `BUBG Level 5 Sort Order`,
    bubg_dashboard_type AS `BUBG Dashboard Type`,
    CAST(
    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_3_sort_order
        ELSE 10*bubg_level_2_sort_order
    END AS INT
    ) AS `BUBG Level 1 HC Sort Order`,
    CAST(
    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_4_sort_order
        ELSE 10*bubg_level_3_sort_order
    END AS INT
    ) AS `BUBG Level 2 HC Sort Order`,
    CAST(BUBG_level_5_sort_order AS INT) AS `BUBG Level 3 HC Sort Order`,

    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_3_code
        ELSE bubg_level_2_code
    END AS `BUBG Level 1 HC Code`,
    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_3_description
        ELSE bubg_level_2_description
    END AS `BUBG Level 1 HC Description`,
    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_4_code
        ELSE bubg_level_3_code
    END AS `BUBG Level 2 HC Code`,
    CASE
        WHEN bubg_level_1_code = 'MH006664' THEN bubg_level_4_description
        ELSE bubg_level_3_description
    END AS `BUBG Level 2 HC Description`,
    BUBG_level_5_description AS `BUBG Level 3 HC Description`
    from {uc_catalog_name}.gold_master_data.business_unit_extended""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## PCAT Hierarcy Extended

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("1st Condition Passed")

    pc  = spark.table(f"{uc_catalog_name}.gold_master_data.product").alias("pc")
    pch = spark.table(f"{uc_catalog_name}.gold_master_data.pc_hierarchies").alias("pch").drop("log_id", "created_date","has_data","is_active","dummy_flag","updated_date")

    pc_filtered = pc.filter((col("pc.is_active") == True))

    conditions = []

    conditions.append(
        (col("pch.level_5_code").isNotNull()) &
        (col("pch.level_4_code").isNotNull()) &
        (col("pch.level_3_code").isNotNull()) &
        (col("pch.level_2_code").isNotNull()) &
        (col("pch.level_1_code").isNotNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_5_code") == col("pc.market_code")) &
        (col("pch.level_4_code") == col("pc.category_code")) &
        (col("pch.level_3_code") == col("pc.sub_division_2_code")) &
        (col("pch.level_2_code") == col("pc.division_code")) &
        (col("pch.level_1_code") == col("pc.legacy_division_code")) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    conditions.append(
        (col("pch.level_5_code").isNull()) &
        (col("pch.level_4_code").isNotNull()) &
        (col("pch.level_3_code").isNotNull()) &
        (col("pch.level_2_code").isNotNull()) &
        (col("pch.level_1_code").isNotNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_4_code") == col("pc.category_code")) &
        (col("pch.level_3_code") == col("pc.sub_division_2_code")) &
        (col("pch.level_2_code") == col("pc.division_code")) &
        (col("pch.level_1_code") == col("pc.legacy_division_code")) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    conditions.append(
        (col("pch.level_5_code").isNull()) &
        (col("pch.level_4_code").isNull()) &
        (col("pch.level_3_code").isNotNull()) &
        (col("pch.level_2_code").isNotNull()) &
        (col("pch.level_1_code").isNotNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_3_code") == col("pc.sub_division_2_code")) &
        (col("pch.level_2_code") == col("pc.division_code")) &
        (col("pch.level_1_code") == col("pc.legacy_division_code")) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    conditions.append(
        (col("pch.level_5_code").isNull()) &
        (col("pch.level_4_code").isNull()) &
        (col("pch.level_3_code").isNull()) &
        (col("pch.level_2_code").isNotNull()) &
        (col("pch.level_1_code").isNotNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_2_code") == col("pc.division_code")) &
        (col("pch.level_1_code") == col("pc.legacy_division_code")) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    conditions.append(
        (col("pch.level_5_code").isNull()) &
        (col("pch.level_4_code").isNull()) &
        (col("pch.level_3_code").isNull()) &
        (col("pch.level_2_code").isNull()) &
        (col("pch.level_1_code").isNotNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_1_code") == col("pc.legacy_division_code")) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    conditions.append(
        (col("pch.level_5_code").isNull()) &
        (col("pch.level_4_code").isNull()) &
        (col("pch.level_3_code").isNull()) &
        (col("pch.level_2_code").isNull()) &
        (col("pch.level_1_code").isNull()) &
        (col("pch.level_0_code").isNotNull()) &
        (col("pch.level_0_code") == col("pc.total_unilever_by_product_category_code"))
    )

    final_condition = red_func(lambda x, y: x | y, conditions)

    result          = pc_filtered.join(pch, final_condition, "inner")

    result.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("2nd Condition Passed")

    df          = spark.sql(f"select * from {uc_catalog_name}.gold_master_data.pc_hierarchies").filter(col("is_active")==True)

    columns     = ["level_0_code","level_1_code","level_2_code","level_3_code","level_4_code","level_5_code"]

    distinct_df = df.select(col(columns[0]).alias("code")).distinct()

    for col_name in columns[1:]:

        distinct_df = distinct_df.union(
            df.select(col(col_name).alias("code")).distinct()
        )

    distinct_without_dl_df  = distinct_df.distinct().filter(~col("code").like("%DL_-%"))

    sort_order_df = (
        df.select(
            col("level_0_code").alias("code"),
            col("level_0_sort_order"),
            lit(None).alias("level_1_sort_order"),
            lit(None).alias("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct()

        .unionByName(df.select(
            col("level_1_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            lit(None).alias("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_2_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            lit(None).alias("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_3_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            lit(None).alias("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_4_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            col("level_4_sort_order"),
            lit(None).alias("level_5_sort_order")
        ).distinct())

        .unionByName(df.select(
            col("level_5_code").alias("code"),
            col("level_0_sort_order"),
            col("level_1_sort_order"),
            col("level_2_sort_order"),
            col("level_3_sort_order"),
            col("level_4_sort_order"),
            col("level_5_sort_order")
        ).distinct())
    ).filter(col("code").isNotNull())

    sort_order_df.display()

    distinct_without_dl_df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select * from pds_pmrs_930972_dev.gold_master_data.product where product_form_code like "%MSP0006%"
# MAGIC -- select * from pds_pmrs_930972_dev.gold_master_data.vw_product_extended where `Product SK` = 5516

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("3rd Condition Passed")

    distinct_values   = [row['code'] for row in distinct_without_dl_df.filter(col("code").isNotNull()).collect()]

    # like_clause       = " OR ".join([f"product_form_code LIKE '%DL_-{val}%'" for val in distinct_values] + [f"product_form_code LIKE '%LV9-{val}%'" for val in distinct_values])

    like_clause       = " OR ".join([f"product_form_code LIKE '%DL_-{val}%'" for val in distinct_values])

    query             = f""" SELECT  *  FROM {uc_catalog_name}.silver_master_data.product WHERE {like_clause} and is_active is True and source not in ("calculated","local finance") """

    dummy_df          = spark.sql(query)

    dummy_df = dummy_df.join(sort_order_df, sort_order_df.code == substring(dummy_df.product_form_code,5,100) , how="left") \
                .withColumn("level_0_sort_order", col("level_0_sort_order")).drop("code") \
                .select(
                col("product_sk").alias("product_sk"),
                col("market_code").alias("level_5_code"),
                col("market_description").alias("level_5_description"),
                col("category_code").alias("level_4_code"),
                col("category_description").alias("level_4_description"),
                col("sub_division_2_code").alias("level_3_code"),
                col("sub_division_2_description").alias("level_3_description"),
                col("division_code").alias("level_2_code"),
                col("division_description").alias("level_2_description"),
                col("legacy_division_code").alias("level_1_code"),
                col("legacy_division_description").alias("level_1_description"),
                col("total_unilever_by_product_category_code").alias("level_0_code"),
                col("total_unilever_by_product_category_description").alias("level_0_description"),
                col("level_0_sort_order").alias("level_0_sort_order"),
                col("level_1_sort_order").alias("level_1_sort_order"),
                col("level_2_sort_order").alias("level_2_sort_order"),
                col("level_3_sort_order").alias("level_3_sort_order"),
                col("level_4_sort_order").alias("level_4_sort_order"),
                col("level_5_sort_order").alias("level_5_sort_order"),*["log_id", "created_date","has_data","is_active","dummy_flag","updated_date"]) \
                .withColumn("dashboard_type",lit("All"))

    dummy_df.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("4th Condition Passed")

    dummies_cols        = set(dummy_df.columns)

    view_cols           = set(result.drop("log_id","created_date").columns)

    missing_cols        = view_cols - dummies_cols

    print(missing_cols)

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("5th Condition Passed")

    for col_name in missing_cols:

        dummy_df        = dummy_df.withColumn(col_name, lit(None).cast(result.schema[col_name].dataType))

    dummy_df.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("6th Condition Passed")

    dummy_keys      = dummy_df.select("product_sk").distinct()

    result_filtered = result.join(dummy_keys, on="product_sk", how="left_anti")

    combined_df     = dummy_df.unionByName(result_filtered)

    combined_df.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("7th Condition Passed")

    view_df         = combined_df

    renamed_columns = {col: col.replace(" ", "_").lower() for col in view_df.columns}

    view_df         = view_df.select([col(c).alias(f"hier_{c}") for c in view_df.columns])

    dim_df          = spark.read.table(f"{uc_catalog_name}.silver_master_data.product").filter(col("is_active")==True)

    dim_df          =   dim_df.select([col(c).alias(f"dim_{c}") for c in dim_df.columns])

    join_df         = dim_df.join(view_df, col("`dim_product_sk`") == col("hier_product_sk"), "left") \
                    .select(
                    "dim_product_sk",
                    "dim_total_unilever_by_product_category_code",
                    "dim_total_unilever_by_product_category_description",
                    "dim_legacy_division_code",
                    "dim_legacy_division_description",
                    "dim_division_code",
                    "dim_division_description",
                    "dim_sub_division_2_code",
                    "dim_sub_division_2_description",
                    "dim_category_code",
                    "dim_category_description",
                    "dim_market_code",
                    "dim_market_description",
                    "dim_sector_code",
                    "dim_sector_description",
                    "dim_sub_sector_code",
                    "dim_sub_sector_description",
                    "dim_segment_code",
                    "dim_segment_description",
                    "dim_product_form_code",
                    "dim_product_form_description",
                    "dim_source",
                    "dim_is_active",
                    "dim_has_data",
                    "dim_dummy_flag",
                    "dim_surrogate_key",
                    "hier_level_5_code",
                    "hier_level_5_description",
                    "hier_level_4_code",
                    "hier_level_4_description",
                    "hier_level_3_code",
                    "hier_level_3_description",
                    "hier_level_2_code",
                    "hier_level_2_description",
                    "hier_level_1_code",
                    "hier_level_1_description",
                    "hier_level_0_code",
                    "hier_level_0_description",
                    "hier_dashboard_type",
                    "hier_level_1_sort_order",
                    "hier_level_4_sort_order",
                    "hier_level_2_sort_order",
                    "hier_level_3_sort_order",
                    "hier_level_5_sort_order",
                    "hier_level_0_sort_order")

    join_df.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("8th Condition Passed")

    columns_to_rename=[]

    type_prefixes = [
                    row["hier_dashboard_type"]
                    for row in join_df.select("hier_dashboard_type")
                    .filter(col("hier_dashboard_type").isNotNull())
                    .distinct()
                    .collect()
                    ]

    cols = [
    "hier_level_5_code",
    "hier_level_5_description",
    "hier_level_4_code",
    "hier_level_4_description",
    "hier_level_3_code",
    "hier_level_3_description",
    "hier_level_2_code",
    "hier_level_2_description",
    "hier_level_1_code",
    "hier_level_1_description",
    "hier_level_0_code",
    "hier_level_0_description",
    "hier_dashboard_type",
    "hier_level_1_sort_order",
    "hier_level_4_sort_order",
    "hier_level_2_sort_order",
    "hier_level_3_sort_order",
    "hier_level_5_sort_order",
    "hier_level_0_sort_order"
    ]

    columns_to_rename  = ["hier_dashboard_type"]

    columns_to_rename += [c for c in join_df.select(*cols).columns if c.startswith("hier_level_")]

    print(columns_to_rename,len(columns_to_rename))

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("9th Condition Passed")

    renamed_exprs = []

    for prefix in type_prefixes:
        for c in columns_to_rename:
            if c.startswith("hier_level_"):
                new_c = c.replace("hier_", "")
                renamed_exprs.append(f"`{c}` as {prefix}_{new_c}")
            elif c == "hier_dashboard_type":
                new_c = c.replace("hier", "")
                renamed_exprs.append(f"`{c}` as {prefix}{new_c}")

    base_columns = [f"`{c}`" for c in join_df.columns if c not in columns_to_rename]

    final_expr  = base_columns + renamed_exprs

    final_df    = join_df.selectExpr(*final_expr)

    final_df.display()

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("10th Condition Passed")

    full_path = absolute_path + "data_engineering/gold/master_data/product_extended"

    spark.sql(f"""DROP TABLE   IF EXISTS {uc_catalog_name}.gold_master_data.product_extended""")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_master_data.product_extended USING DELTA LOCATION '{full_path}'""")

# COMMAND ----------

if "product_hierarchies" in data_feed:

    print("11th Condition Passed")

    final_df.drop("hier_bu_sk").write.mode("overwrite").option("overwriteSchema", "true").save(full_path)

# COMMAND ----------

if "product_hierarchies" in data_feed:

  print("12th Condition Passed")

  spark.sql(f"""
  CREATE OR REPLACE VIEW {uc_catalog_name}.gold_master_data.vw_product_extended AS
  SELECT 
    dim_product_sk AS `Product SK`,
    dim_total_unilever_by_product_category_code AS `Total Unilever By Product Category Code`,
    dim_total_unilever_by_product_category_description AS `Total Unilever By Product Category Description`,
    dim_legacy_division_code AS `Legacy Division Code`,
    dim_legacy_division_description AS `Legacy Division Description`,
    dim_division_code AS `Division Code`,
    dim_division_description AS `Division Description`,
    dim_sub_division_2_code AS `Sub Division 2 Code`,
    dim_sub_division_2_description AS `Sub Division 2 Description`,
    dim_category_code AS `Category Code`,
    dim_category_description AS `Category Description`,
    dim_market_code AS `Market Code`,
    dim_market_description AS `Market Description`,
    dim_sector_code AS `Sector Code`,
    dim_sector_description AS `Sector Description`,
    dim_sub_sector_code AS `Sub Sector Code`,
    dim_sub_sector_description AS `Sub Sector Description`,
    dim_segment_code AS `Segment Code`,
    dim_segment_description AS `Segment Description`,
    dim_product_form_code AS `Product Form Code`,
    dim_product_form_description AS `Product Form Description`,
    dim_source as `Source`,
    dim_is_active AS `Is Active`,
    dim_has_data AS `Has Data`,
    dim_dummy_flag AS `Dummy Flag`,

    CASE
      WHEN dim_division_code = 'CF1159' THEN dim_market_code
      ELSE dim_category_code
    END AS `Category-Market Code`,

    CASE
      WHEN dim_division_code = 'CF1159' THEN dim_market_description
      ELSE dim_category_description
    END AS `Category-Market Description`,

  cast(CASE 
    WHEN All_level_2_code = 'CH1159' THEN All_level_5_sort_order 
    ELSE All_level_4_sort_order 
  END as int) AS `All Category Market Sort Order`,

    -- All
    All_level_0_code AS `All Level 0 Code`,
    All_level_0_description AS `All Level 0 Description`,
    CAST(All_level_0_sort_order AS INT) AS `All Level 0 Sort Order`,
    All_level_1_code AS `All Level 1 Code`,
    All_level_1_description AS `All Level 1 Description`,
    CAST(All_level_1_sort_order AS INT) AS `All Level 1 Sort Order`,
    All_level_2_code AS `All Level 2 Code`,
    All_level_2_description AS `All Level 2 Description`,
    CAST(All_level_2_sort_order AS INT) AS `All Level 2 Sort Order`,
    All_level_3_code AS `All Level 3 Code`,
    All_level_3_description AS `All Level 3 Description`,
    CAST(All_level_3_sort_order AS INT) AS `All Level 3 Sort Order`,
    All_level_4_code AS `All Level 4 Code`,
    All_level_4_description AS `All Level 4 Description`,
    CAST(All_level_4_sort_order AS INT) AS `All Level 4 Sort Order`,
    All_level_5_code AS `All Level 5 Code`,
    All_level_5_description AS `All Level 5 Description`,
    CAST(All_level_5_sort_order AS INT) AS `All Level 5 Sort Order`,
    All_dashboard_type AS `All Dashboard Type`,

    CASE
      WHEN All_level_2_code = 'CF1159' THEN All_level_5_code
      ELSE All_level_4_code
    END AS `All Category-Market Code`,
    CASE
      WHEN All_level_2_code = 'CF1159' THEN All_level_5_description
      ELSE All_level_4_description
    END AS `All Category-Market Description`,

    CASE
    WHEN dim_market_code IN ('CF1054', 'CF0128', 'CF1199', 'CF1205', 'CF3224', 'CF1217')
      THEN dim_market_description
    WHEN dim_sector_code IN ('CF0077', 'CF1043', 'CF1044')
      THEN dim_sector_description
    ELSE dim_category_description
      END AS `Category Cell`

  FROM {uc_catalog_name}.gold_master_data.product_extended
  """)

# COMMAND ----------

if "bu_hierarchies" in data_feed or "product_hierarchies" in data_feed:
    
    print("BU Hierarchy or Product Hierarchy Feed Detected")

    full_path = absolute_path + "data_engineering/gold/master_data/cell"
    df_bu     = spark.table(f"{uc_catalog_name}.gold_master_data.business_unit_extended")
    df_pc     = spark.table(f"{uc_catalog_name}.gold_master_data.product_extended")

    df_bu.createOrReplaceTempView("vw_business_unit_cell")
    df_pc.createOrReplaceTempView("vw_product_cell")
    
    df_product_cell = spark.sql("""
            SELECT
                dim_product_sk, 
                CASE
                    WHEN
                    dim_market_code = 'CF1054'
                    OR dim_market_code = 'CF0128'
                    OR dim_market_code = 'CF1199'
                    OR dim_market_code = 'CF1205'
                    OR dim_market_code = 'CF3224'
                    OR dim_market_code = 'CF1217'
                    THEN
                    CASE 
                        WHEN dim_market_description RLIKE '^DL[0-9]+-' 
                        THEN regexp_replace(dim_market_description, '^DL[0-9]+-', '') 
                        ELSE dim_market_description 
                    END

                    WHEN
                    dim_sector_code = 'CF0077'
                    OR dim_sector_code = 'CF1043'
                    OR dim_sector_code = 'CF1044'
                    THEN
                    CASE 
                        WHEN dim_sector_description RLIKE '^DL[0-9]+-' 
                        THEN regexp_replace(dim_sector_description, '^DL[0-9]+-', '') 
                        ELSE dim_sector_description 
                    END

                    ELSE 
                    CASE 
                        WHEN dim_category_description RLIKE '^DL[0-9]+-' 
                        THEN regexp_replace(dim_category_description, '^DL[0-9]+-', '') 
                        ELSE dim_category_description 
                    END 
                END AS `category_cell`,
                All_dashboard_type,
                dim_source AS `product_source`
            FROM vw_product_cell
            --WHERE dim_category_description NOT RLIKE '^DL[0-4]+-' 
        """)
    
    
    df_bu_cell = spark.sql("""
                WITH ranked AS (
                    SELECT
                        dim_bu_sk,
                        bubg_level_5_description,
                        bubg_level_4_description,
                        bubg_level_3_description,
                        bubg_level_2_description,
                        bubg_level_1_description,
                        bubg_dashboard_type,
                        dim_source AS bu_source,
                    CASE
                        WHEN bubg_level_5_description IS NOT NULL THEN 5

                        WHEN bubg_level_4_description IS NOT NULL
                            AND NOT bubg_level_4_description RLIKE '^DL[0-9]+-'
                            AND NOT bubg_level_4_description LIKE '%Others%'
                            THEN 4

                        WHEN bubg_level_3_description IS NOT NULL
                            AND NOT bubg_level_3_description RLIKE '^DL[0-9]+-'
                            AND NOT (
                                    lower(bubg_level_3_description) RLIKE '(north asia|india|north america|latin america|ptab|europe|greater asia|bg markets others)'
                            )
                            THEN 3

                        WHEN bubg_level_2_description IS NOT NULL
                            AND NOT bubg_level_2_description RLIKE '^DL[0-9]+-'
                            AND NOT lower(bubg_level_2_description) RLIKE '(bg markets)'
                            THEN 2

                        WHEN bubg_level_1_description IS NOT NULL
                            AND NOT bubg_level_1_description RLIKE '^DL[0-9]+-'
                            AND NOT lower(bubg_level_1_description) RLIKE '(bg led)'
                            THEN 1

                        ELSE 0
                        END AS lvl
                    FROM vw_business_unit_cell
                ),
                    priority_ranked AS (  
                    SELECT
                        *,
                        ROW_NUMBER() OVER (
                        PARTITION BY dim_bu_sk
                        ORDER BY lvl DESC
                        ) AS rn
                    FROM ranked
                    )

                    SELECT
                    dim_bu_sk,
                    CASE
                        WHEN lvl = 5 THEN bubg_level_5_description
                        WHEN lvl = 4 THEN bubg_level_4_description
                        WHEN lvl = 3 THEN bubg_level_3_description
                        WHEN lvl = 2 THEN bubg_level_2_description
                        WHEN lvl = 1 THEN bubg_level_1_description
                        ELSE bubg_level_5_description   
                    END AS bubg_level_5_description,
                    bubg_dashboard_type,
                    bu_source

                    FROM priority_ranked
                    WHERE rn = 1
                    
                """)

    display(df_bu_cell)


    df_cell = df_product_cell.crossJoin(df_bu_cell)

    df_result = (df_cell.withColumn("bubg_cell", concat(df_cell["bubg_level_5_description"], lit(" - "), df_cell["category_cell"])))

    df_result.drop("hier_bu_sk").write.mode("overwrite").option("overwriteSchema", "true").save(full_path)

    spark.sql(f"""DROP TABLE IF EXISTS {uc_catalog_name}.gold_master_data.cell""")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {uc_catalog_name}.gold_master_data.cell USING DELTA LOCATION '{full_path}'""")

    spark.sql(f"""
        CREATE OR REPLACE VIEW {uc_catalog_name}.gold_master_data.vw_cell AS
            SELECT 
                dim_product_sk as `Product SK`,
                dim_bu_sk as `BU SK`,
                dim_product_sk * 100000 + dim_bu_sk as `Cell SK`,
                bu_source as `BU Source`,
                product_source as `Product Source`,
                bubg_dashboard_type as `BU Dashboard Type`,
                All_dashboard_type as `All Dashboard Type`,
                bubg_cell as `BUBG Cell`
            FROM {uc_catalog_name}.gold_master_data.cell
       
        """)
