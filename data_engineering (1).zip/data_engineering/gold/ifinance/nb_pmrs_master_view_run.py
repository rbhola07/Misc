# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 11 Jan 2025        |    Gokul /Vinod       |    Notebook Created |
# MAGIC
# MAGIC ## Purpose
# MAGIC Notebook to create the views
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - view_name     : determine view from the datafeed
# MAGIC - gold_db_name  : name of the Gold Database name
# MAGIC - gold_table_name : name of the gold table name
# MAGIC
# MAGIC ### Output
# MAGIC Data will create the view from the gold layer tables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

debug_flag          = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="debug_flag")
data_feed           = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="data_feed")
uc_catalog_name     = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="uc_catalog_name")
object_owner_spn    = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="object_owner_spn")
external_location   = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="external_location")
username            = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="username")
log_id              = dbutils.jobs.taskValues.get(taskKey="Raw_to_Bronze_staging_ingestion", key="log_id")


dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("log_id", log_id)

dbutils.widgets.text("data_feed_geography","master_data_geography")
data_feed_geography  = dbutils.widgets.get("data_feed_geography")


dbutils.widgets.text("is_pcat","")
if dbutils.widgets.get("is_pcat") == 'true':
    data_feed        = "master_data_pcat_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path of the external location
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().split("/")[-1]

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    run_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().parentRunId().get())
    job_id = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    run_id = int(log_id)

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 4
detail_log_value = (log_value * 10) 

insert_job_log(log_value, job_id, run_id, username,"Ifinance view creation", datetime.now(),None,status_running_id, feed_type_id, feed_id, module_id, 0, "", "",uc_catalog_name)

insert_job_detail_log( int(detail_log_value + counter) , log_value, run_id, username, "Gold to view creation", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")

if debug_flag == "1":
    print('log_id       :',log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the view creation configurations data 
# MAGIC - view creation configuration

# COMMAND ----------

try:

    # ------------------Reading the Ingestion_Configuration_sheet-------------------#
    param                     = get_param_data(uc_catalog_name)
    process_feed_df           = fetch_config(param, data_feed)
    process_feed_df_georaphy  = fetch_config(param, data_feed_geography)


    gold_db_name                      = process_feed_df.select("delta_db_gold").first()[0]
    gold_table_name                   = process_feed_df.select("delta_table_gold").first()[0]
    geography_gold_db_name            = process_feed_df_georaphy.select("delta_db_gold").first()[0]
    geography_gold_table_name         = process_feed_df_georaphy.select("delta_table_gold").first()[0]
    view_name                         = process_feed_df.select("view_name").first()[0]

    if debug_flag == "1":

        print('uc_catalog_name            :', uc_catalog_name)
        print('gold_db_name               :', gold_db_name)
        print('gold_table_name            :', gold_table_name)
        print('view_name                  :', view_name)

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, "Fetching config file columns for the view creation failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md 
# MAGIC ####Delta table check

# COMMAND ----------

def check_table_exists(uc_catalog_name, schema_name, table_name):
    table_exists = spark.catalog.tableExists(f"{uc_catalog_name}.{schema_name}.{table_name}")
    if table_exists:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} exists.")
    else:
        print(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")
        raise Exception(f"table {uc_catalog_name}.{schema_name}.{table_name} does not exist.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### View creation for the respective datafeed

# COMMAND ----------

try:
    if data_feed == "master_data_brand" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        brand_sk AS `Brand SK`,
                        total_by_finance_code AS `Total by Finance Code`,
                        total_by_brand_description AS `Total by Brand Description`,
                        corporate_parent_finance_code AS `Corporate Parent Finance Code`,
                        corporate_parent_brand_description AS `Corporate Parent Brand Description`,
                        corporate_brand_code AS `Corporate Brand Code`,
                        corporate_brand_description AS `Corporate Brand Description`,
                        total_by_brand_code AS `Total by Brand Code`,
                        total_by_brand_subscribe AS `Total by Brand Subscribe`,
                        corporate_parent_brand_code AS `Corporate Parent Brand Code`,
                        corporate_brand_finance_subscribe AS `Corporate Brand Finance Subscribe`,
                        corporate_brand_finance_code AS `Corporate Brand Finance Code`,
                        corporate_brand_type AS `Corporate Brand Type`,
                        corporate_brand_subscribe AS `Corporate Brand Subscribe`,
                        corporate_brand_active_status AS `Corporate Brand Active Status`,
                        manufacturer_code AS `Manufacturer Code`,
                        manufacturer_marketing_code AS `Manufacturer Marketing Code`,
                        manufacturer_description AS `Manufacturer Description`,
                        cont_dis_op_code AS `Cont Dis Op Code`,
                        cont_dis_op_description AS `Cont Dis Op Description`,
                        brand_acquired_from AS `Brand Acquired From`,
                        dummy_flag AS `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_brand_position" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        brand_position_sk AS `Brand Position SK`,
                        brand_position_finance_code AS `Brand Position Finance Code`,
                        brand_position_description AS `Brand Position Description`,
                        brand_position_level_3_code AS `Brand Position Level 3 Code`,
                        brand_position_level_3_description AS `Brand Position Level 3 Description`,
                        brand_position_level_2_code AS `Brand Position Level 2 Code`,
                        brand_position_level_2_description AS `Brand Position Level 2 Description`,
                        brand_position_level_1_code AS `Brand Position Level 1 Code`,
                        brand_position_level_1_description AS `Brand Position Level 1 Description`,
                        brand_position_level_0_code AS `Brand Position Level 0 Code`,
                        brand_position_level_0_description AS `Brand Position Level 0 Description`,
                        brand_position_default_code AS `Brand Position Default Code`,
                        brand_position_subscribe AS `Brand Position Subscribe`,
                        dummy_flag AS `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
    
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_customer" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        customer_sk AS `Customer SK`,
                        total_customer_code AS `Total Customer Code`,
                        total_customer_description AS `Total Customer Decsription`,
                        customer_importance_code AS `Customer Importance Code`,
                        customer_importance_name AS `Customer Importance Name`,
                        global_customer_group_finance_code AS `Global Customer Group Finance Code`,
                        global_customer_group_name AS `Global Customer Group Name`,
                        global_customer_finance_code AS `Global Customer Finance Code`,
                        global_customer_name AS `Global Customer Name`,
                        customer_scope_code AS `Customer Scope Code`,
                        customer_scope_name AS `Customer Scope Name`,
                        dummy_flag AS `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.vw_business_unit_alternate_description AS
                    select
                        descendant_sk as `Product sk`,
                        attribute_code as `Attribute Code`,
                        alternate_description as `Alternate Description`
                        from
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True and dimension_name = 'BusinessUnit'""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.vw_product_alternate_description AS
                    select
                        descendant_sk as `Product sk`,
                        attribute_code as `Attribute Code`,
                        alternate_description as `Alternate Description`
                        from
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True and dimension_name = 'ProductCategory'""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.vw_brand_alternate_description AS
                    select
                        descendant_sk as `Brand sk`,
                        attribute_code as `Attribute Code`,
                        alternate_description as `Alternate Description`
                        from
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True and dimension_name = 'Brand'""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    Create or replace view {uc_catalog_name}.gold_master_data.vw_flat_bu as
                        select
                        bu_sk AS `BU SK`,
                        bu_code AS `BU Code`,
                        bu_description AS `BU Description`
                        from {uc_catalog_name}.gold_master_data.flat_bu""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                  Create or replace view {uc_catalog_name}.gold_master_data.vw_flat_pcat as
                    select
                        product_sk AS `Product SK`,
                        total_unilever_by_product_category_code AS `PCat Code`,
                        total_unilever_by_product_category_description AS `PCat Description`,
                        visible_flag AS `Visible Flag`
                        from {uc_catalog_name}.gold_master_data.flat_pcat""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_dimension_alternate_description" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.vw_flat_brand AS
                    select
                        brand_sk as `Brand sk`,
                        brand_code as `Brand Code`,
                        brand_description as `Brand Description`
                        from
                        {uc_catalog_name}.gold_master_data.flat_brand""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_customer_channel" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        customer_channel_sk AS `Customer Channel SK`,
                        total_channel_code AS `Total Channel Code`,
                        total_channel_name AS `Total Channel Name`,
                        macro_channel_code AS `Macro Channel Code`,
                        macro_channel_name AS `Macro Channel Name`,
                        format_channel_code AS `Format Channel Code`,
                        format_channel_name AS `Format Channel Name`,
                        sub_format_channel_code AS `Sub Format Channel Code`,
                        sub_format_channel_name AS `Sub Format Channel Name`,
                        total_channel_subscribe AS `Total Channel Subscribe`,
                        macro_channel_subscribe AS `Macro Channel Subscribe`,
                        format_channel_subscribe AS `Format Channel Subscribe`,
                        sub_format_channel_subscribe AS `Sub Format Channel Subscribe`,
                        dummy_flag AS `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}
                        WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_company" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        company_sk AS `Company SK`,
                        total_legal_entity_geography_code AS `Total Legal Entity Geography Code`,
                        total_legal_entity_geography_description AS `Total Legal Entity Geography Description`,
                        region_code AS `Region Code`,
                        region_description AS `Region Description`,
                        cluster_code AS `Cluster Code`,
                        cluster_description AS `Cluster Description`,
                        sub_region_code AS `Sub Region Code`,
                        sub_region_description AS `Sub Region Description`,
                        country_code AS `Country Code`,
                        country_description AS `Country Description`,
                        sub_country_code AS `Sub Country Code`,
                        sub_country_description AS `Sub Country Description`,
                        legal_entity_code AS `Legal Entity Code`,
                        legal_entity_description AS `Legal Entity Description`,
                        legal_entity_country_code AS `Legal Entity Country Code`,
                        legal_entity_country_description AS `Legal Entity Country Description`,
                        legal_entity_company_type_code AS `Legal Entity Company Type Code`,
                        legal_entity_company_type_description AS `Legal Entity Company Type Description`,
                        dummy_flag AS `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True
                """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_version" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        cast(version_sk as int) As `Version SK`,
                        cast(version_code as string) As `Version Code`,
                        version_description As `Version Description`,
                        version_summary As `Version Summary`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_measure" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        measure_sk AS `Measure SK`,
                        measure_code AS `Measure Code`,
                        measure_description AS `Measure Description`,
                        measure_type AS `Measure Type`,
                        ifinance_measure_code AS `iFinance Measure Code`,
                        ifinance_measure_description AS `iFinance Measure Description`,
                        COALESCE(dashboard_description_1, measure_description) AS `Dashboard Description 1`,
                        COALESCE(dashboard_description_2, measure_description) AS `Dashboard Description 2`,
                        COALESCE(dashboard_description_3, measure_description) AS `Dashboard Description 3`,
                        COALESCE(dashboard_description_4, measure_description) AS `Dashboard Description 4`,
                        COALESCE(dashboard_description_5, measure_description) AS `Dashboard Description 5`,
                        COALESCE(dashboard_description_6, measure_description) AS `Dashboard Description 6`,
                        COALESCE(dashboard_description_7, measure_description) AS `Dashboard Description 7`,
                        COALESCE(dashboard_description_8, measure_description) AS `Dashboard Description 8`,
                        dashboard_sort_order_1 AS `Dashboard Sort Order 1`,
                        dashboard_sort_order_2 AS `Dashboard Sort Order 2`,
                        dashboard_sort_order_3 AS `Dashboard Sort Order 3`,
                        dashboard_sort_order_4 AS `Dashboard Sort Order 4`,
                        dashboard_sort_order_5 AS `Dashboard Sort Order 5`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_flow" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        flow_sk As `Flow SK`,
                        flow_description As `Flow Description`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_forecast_level" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        cast(`forecast_level_sk` as int) AS `Forecast Level SK`,
                        `forecast_level_code` AS `Forecast Level Code`,
                        `forecast_level_description` AS `Forecast Level Description`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_map_forecast" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        load_month AS `Load Month`,
                        reporting_month AS `Reporting Month`,
                        forecast_version AS `Forecast Version`,
                        last_actuals_month AS `Last Actuals Month`,
                        forecast_level_sk AS `Forecast Level SK`,
                        first_forecast_month AS `First Forecast Month`,
                        CASE
                            WHEN LOWER(forecast_type_description) LIKE 'monthly_forecast' THEN 'Monthly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'quarterly_forecast' THEN 'Quarterly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'yearly_forecast' THEN 'Yearly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'gmva_quarterly_forecast' THEN 'GMVA Quarterly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'gmva_yearly_forecast' THEN 'GMVA Yearly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'twc_monthly_forecast' THEN 'TWC Monthly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'twc_quarterly_forecast' THEN 'TWC Quarterly Forecast'
                            WHEN LOWER(forecast_type_description) LIKE 'twc_yearly_forecast' THEN 'TWC Yearly Forecast'
                            ELSE forecast_type_description
                        END AS `Forecast Type Description`,
                        previous_forecast_version AS `Previous Forecast Version`,
                        gmva_fc_version AS `GMVA FC Version`,
                        gmva_last_actuals_month AS `GMVA Last Actuals Month`,
                        twc_fc_version AS `TWC FC Version`,
                        twc_last_actuals_month AS `TWC Last Actuals Month`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_product_category" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        product_sk As `Product SK`,
                        total_unilever_by_product_category_code As `Total Unilever by Product Category Code`,
                        total_unilever_by_product_category_description As `Total Unilever by Product Category Description`,
                        legacy_division_code As `Legacy Division Code`,
                        legacy_division_description As `Legacy Division Description`,
                        division_code As `Division Code`,
                        division_description As `Division Description`,
                        sub_division_2_code As `Sub Division 2 Code`,
                        sub_division_2_description As `Sub Division 2 Description`,
                        category_code As `Category Code`,
                        category_description As `Category Description`,
                        market_code As `Market Code`,
                        market_description As `Market Description`,
                        sector_code As `Sector Code`,
                        sector_description As `Sector Description`,
                        sub_sector_code As `Sub Sector Code`,
                        sub_sector_description As `Sub Sector Description`,
                        segment_code As `Segment Code`,
                        segment_description As `Segment Description`,
                        CASE WHEN division_code = 'CF1159' THEN market_code ELSE category_code END AS `Category-Market Code`,
                        CASE WHEN division_code = 'CF1159' THEN market_description ELSE category_description END AS `Category-Market Description`,
                        product_form_code As `Product Form Code`,
                        product_form_description As `Product Form Description`,
                        dummy_flag as `Dummy Flag`,
                        source As `Source`,
                        -- Cell changes
                        case
                        when `Market Code` = 'CF1054' or
                        `Market Code` = 'CF0128' or
                        `Market Code` = 'CF1199' or
                        `Market Code` = 'CF1205' or
                        `Market Code` = 'CF3224' or
                        `Market Code` = 'CF1217'
                        then `Market Description`
                        
                        when `Sector Code` = 'CF0077' or
                        `Sector Code` = 'CF1043' or
                        `Sector Code` = 'CF1044'
                        then `Sector Description`
                        
                        else
                        `Category Description`
                        
                        end
                        as `Category Cell`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_geography" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(geography_sk As int) As `Geography SK`,
                        world_description As `World Description`,
                        world_code As `World Code`,
                        region_description As `Region Description`,
                        region_code As `Region Code`,
                        unilever_pmu_description As `Unilever PMU Description`,
                        unilever_pmu_code As `Unilever PMU Code`,
                        country_cluster_description As `Country Cluster Description`,
                        country_cluster_code As `Country Cluster Code`,
                        country_group_description As `Country Group Description`,
                        country_group_code As `Country Group Code`,
                        country_sub_group_description As `Country Sub Group Description`,
                        country_sub_group_code As `Country Sub Group Code`,
                        market_type_description As `Market Type Description`,
                        market_type_code As `Market Type Code`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name}  WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_country_bu_map" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(g.geography_sk As int) As `Geography SK`,
                        f.country_code As `Country Code`,
                        f.country_description As `Country Description`,
                        CAST(b.dim_bu_sk As int) As `BU SK`,
                        f.bu_code As `BU Code`,
                        f.bu_description As `BU Description`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} f
                        inner join 
                            (select distinct geography_sk, 
                                            mu_iso_country_code 
                            from {uc_catalog_name}.{gold_db_name}.geography) g
                        on g.mu_iso_country_code = f.country_code
                        inner join 
                            (select distinct dim_bu_sk, 
                                            dim_bu_code, 
                                            dim_bu_description, 
                                            dim_mu_iso_country_description 
                            from {uc_catalog_name}.{gold_db_name}.business_unit_extended) b
                        on b.dim_bu_code = f.bu_code
                        """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# VIEW FOR MARKET PRODUCTS

try:
   if data_feed == "master_data_pcat_hierarchy" :
       
        cross_functional_mapping_description = "cross_functional_mapping_description"
        product_market = "product_market"
        view_name = "vw_product_market"
        mapping_view_name = "vw_cross_functional_mapping_description"
 
        hierarchy_list = ["total_unilever_by_product_category_code", "legacy_division_code", "division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]
 
        check_table_exists(uc_catalog_name, gold_db_name, cross_functional_mapping_description)
 
        ##################################################################################
        # ## ADDING CODE to sync descriptions from gcad to pcat
   
        mapping_df = spark.table(f"{uc_catalog_name}.{gold_db_name}.{cross_functional_mapping_description}")
        staging_df = spark.table(f"{uc_catalog_name}.{gold_db_name}.{gold_table_name}")
        temp_staging = staging_df
        level = 1
        for hierarchy in hierarchy_list:
                mapping_hierarchy = mapping_df.filter((col("gcad_level") == level) & (col("pcat_level") == level)).dropDuplicates()
                temp_staging = temp_staging.join(mapping_hierarchy, temp_staging[hierarchy] == mapping_hierarchy.gcad_pccode, "left")
                temp_staging = temp_staging.withColumn(hierarchy.replace("code","description"),when(col("gcad_description").isNotNull(),col('pcat_description')).otherwise(col(hierarchy.replace("code","description"))))
                temp_staging = temp_staging.drop("pcat_pccode", "pcat_description", "gcad_pccode", "gcad_description", "pcat_level", "gcad_level")
                level = level + 1
 
        temp_staging = temp_staging.filter(col('source').like("%Market%")).dropDuplicates()
 
        staging_df = temp_staging.withColumnRenamed("source", "Source")
 
        staging_df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"""{uc_catalog_name}.{gold_db_name}.{product_market}""")
 
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        product_sk As `Product SK`,
                        total_unilever_by_product_category_code As `Total Unilever by Product Category Code`,
                        total_unilever_by_product_category_description As `Total Unilever by Product Category Description`,
                        legacy_division_code As `Legacy Division Code`,
                        legacy_division_description As `Legacy Division Description`,
                        division_code As `Division Code`,
                        division_description As `Division Description`,
                        sub_division_2_code As `Sub Division 2 Code`,
                        sub_division_2_description As `Sub Division 2 Description`,
                        category_code As `Category Code`,
                        category_description As `Category Description`,
                        market_code As `Market Code`,
                        market_description As `Market Description`,
                        sector_code As `Sector Code`,
                        sector_description As `Sector Description`,
                        sub_sector_code As `Sub Sector Code`,
                        sub_sector_description As `Sub Sector Description`,
                        segment_code As `Segment Code`,
                        segment_description As `Segment Description`,
                        product_form_code As `Product Form Code`,
                        product_form_description As `Product Form Description`,
                        dummy_flag as `Dummy Flag`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{product_market}
                        """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
 
        spark.sql(f"""
            CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{mapping_view_name} AS
            SELECT
                gcad_pccode as `GCAD PCCode`,
                pcat_pccode as `PCAT PCCode`,
                gcad_description as `GCAD Description`,
                pcat_description as `PCAT Description`,
                gcad_level as `GCAD Level`,
                pcat_level as `PCAT Level`
            FROM
                {uc_catalog_name}.{gold_db_name}.{cross_functional_mapping_description}
                """)
        print(f"{uc_catalog_name}.{gold_db_name}.{mapping_view_name} view created successfully.")
 
 
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_map_cross_pcat" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        f.etlname as `ETL Name`,
                        f.pccode as `Product Category Code`,
                        f.description as `Description`,
                        f.lookup_description as `Lookup Description`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} f
                        """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed in ["master_data_business_sc", "master_data_business_unit_mu"]:
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        bu_sk AS `BU SK`,
                        bu_code AS `BU Code`,
                        bu_description AS `BU Description`,
                        mu_code AS `MU Code`,
                        mu_description AS `MU Description`,
                        mu_hier_level_5_code AS `MU Hier Level 5 Code`,
                        mu_hier_level_5_description AS `MU Hier Level 5 Description`,
                        mu_hier_level_4_code AS `MU Hier Level 4 Code`,
                        mu_hier_level_4_description AS `MU Hier Level 4 Description`,
                        mu_hier_level_3_code AS `MU Hier Level 3 Code`,
                        mu_hier_level_3_description AS `MU Hier Level 3 Description`,
                        mu_hier_level_2_code AS `MU Hier Level 2 Code`,
                        mu_hier_level_2_description AS `MU Hier Level 2 Description`,
                        mu_hier_level_1_code AS `MU Hier Level 1 Code`,
                        mu_hier_level_1_description AS `MU Hier Level 1 Description`,
                        mu_hier_level_0_code AS `MU Hier Level 0 Code`,
                        mu_hier_level_0_description AS `MU Hier Level 0 Description`,
                        mu_iso_country_code AS `MU ISO Country Code`,
                        mu_iso_country_description AS `MU ISO Country Description`,
                        sc_mu_code AS `SC MU Code`,
                        sc_mu_description AS `SC MU Description`,
                        sc_level_6_code AS `SC Level 6 Code`,
                        sc_level_6_description AS `SC Level 6 Description`,
                        sc_level_5_code AS `SC Level 5 Code`,
                        sc_level_5_description AS `SC Level 5 Description`,
                        sc_level_4_code AS `SC Level 4 Code`,
                        sc_level_4_description AS `SC Level 4 Description`,
                        sc_level_3_code AS `SC Level 3 Code`,
                        sc_level_3_description AS `SC Level 3 Description`,
                        sc_level_2_code AS `SC Level 2 Code`,
                        sc_level_2_description AS `SC Level 2 Description`,
                        sc_level_1_code AS `SC Level 1 Code`,
                        sc_level_1_description AS `SC Level 1 Description`,
                        sc_level_0_code AS `SC Level 0 Code`,
                        sc_level_0_description AS `SC Level 0 Description`,
                        world_description AS `World Description`,
                        world_code AS `World Code`,
                        region_description AS `Region Description`,
                        region_code AS `Region Code`,
                        unilever_pmu_description AS `Unilever PMU Description`,
                        unilever_pmu_code AS `Unilever PMU Code`,
                        country_cluster_description AS `Country Cluster Description`,
                        country_cluster_code AS `Country Cluster Code`,
                        country_group_description AS `Country Group Description`,
                        country_group_code AS `Country Group Code`,
                        country_sub_group_description AS `Country Sub Group Description`,
                        country_sub_group_code AS `Country Sub Group Code`,
                        market_type_description AS `Market Type Description`,
                        market_type_code AS `Market Type Code`,
                        CASE WHEN mu_hier_level_1_code ='MH006664' THEN mu_hier_level_3_code  ELSE mu_hier_level_2_code  END AS `Level 1 HC Code`,
                        CASE WHEN mu_hier_level_1_code='MH006664' THEN mu_hier_level_3_description ELSE mu_hier_level_2_description END AS `Level 1 HC Description`,
                        CASE WHEN mu_hier_level_1_code='MH006664' THEN mu_hier_level_4_code ELSE mu_hier_level_3_code END AS `Level 2 HC Code`,
                        CASE WHEN mu_hier_level_1_code='MH006664' THEN mu_hier_level_4_description ELSE mu_hier_level_3_description END AS `Level 2 HC Description`,
                        mu_hier_level_5_description AS `Level 3 HC Description`,
                        dummy_flag AS `Dummy Flag`,
                        bu_source AS `Source`
                    FROM (
                        SELECT
                            bu.*, bu.source AS bu_source,
                            gu.world_description,
                            gu.world_code,
                            gu.region_description,
                            gu.region_code,
                            gu.unilever_pmu_description,
                            gu.unilever_pmu_code,
                            gu.country_cluster_description,
                            gu.country_cluster_code,
                            gu.country_group_description,
                            gu.country_group_code,
                            gu.country_sub_group_description,
                            gu.country_sub_group_code,
                            gu.market_type_description,
                            gu.market_type_code
                        FROM
                            {uc_catalog_name}.{gold_db_name}.{gold_table_name} bu  
                        LEFT JOIN
                            {uc_catalog_name}.{geography_gold_db_name}.{geography_gold_table_name} gu 
                        ON bu.mu_iso_country_code = gu.mu_iso_country_code
                        WHERE bu.is_active = True
                    )
                """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e


# COMMAND ----------

try:
    if data_feed == "master_data_cont_disc_ops" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        cont_disc_ops_sk AS `Cont Discont Ops SK`,
                        cont_disc_ops_code AS `Cont Discont Ops Code`,
                        cont_disc_ops_description AS `Cont Discont Ops Description`,
                        level_0_description AS `Level 0 Description`,
                        level_1_description AS `Level 1 Description`,
                        source As `Source`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_calendar" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        CAST(c.month_sk AS INT) AS `Month SK`,
                        c.DATE AS `Date`,
                        CAST(c.month_code AS INT) AS `Month Code`,
                        c.month_short_description AS `Month Short Description`,
                        c.month_long_description AS `Month Long Description`,
                        SUBSTRING(c.month_long_description, 1, 3) AS `Month`,
                        c.quarter AS `Quarter`,
                        c.half_year AS `Half Year`,
                        CAST(c.year AS INT) AS `Year`,
                        CAST(c.current_month_flag AS BOOLEAN) AS `Current Month Flag`,
                        CAST(c.current_quarter_flag AS BOOLEAN) AS `Current Quarter Flag`,
                        CAST(c.current_year_flag AS BOOLEAN) AS `Current Year Flag`,
                        tpr.time_period_actual_1 AS `Time Period Actual 1`,
                        tpr.time_period_forecast_1 AS `Time Period Forecast 1`,
                        tpr.time_period_actual_2 AS `Time Period Actual 2`,
                        tpr.time_period_forecast_2 as `Time Period Forecast 2`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} c
                    INNER JOIN
                        {uc_catalog_name}.{gold_db_name}.time_period_reporting tpr
                    ON c.month_short_description = tpr.DATE
                        where c.year >= year(current_date()) - 5 and c.year < year(current_date()) + 2 and c.is_active =True and tpr.is_acitve = True""")
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    vw_measure_quadrant = "vw_measure_quadrant" 

    if data_feed == "master_data_measure":
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.vw_measure_quadrant AS
                    select 
                        measure_sk AS `Measure SK`,
                        measure_code AS `Measure Code`,
                        measure_description AS `Measure Description`,
                        COALESCE(dashboard_description_1, measure_description) AS `Dashboard Description 1`,
                        COALESCE(dashboard_description_2, measure_description) AS `Dashboard Description 2`,
                        COALESCE(dashboard_description_3, measure_description) AS `Dashboard Description 3`,
                        COALESCE(dashboard_description_4, measure_description) AS `Dashboard Description 4`,
                        COALESCE(dashboard_description_5, measure_description) AS `Dashboard Description 5`,
                        COALESCE(dashboard_description_6, measure_description) AS `Dashboard Description 6`,
                        COALESCE(dashboard_description_7, measure_description) AS `Dashboard Description 7`,
                        dashboard_sort_order_1 AS `Dashboard Sort Order 1`,
                        dashboard_sort_order_2 AS `Dashboard Sort Order 2`,
                        dashboard_sort_order_3 AS `Dashboard Sort Order 3`,
                        dashboard_sort_order_4 AS `Dashboard Sort Order 4`,
                        dashboard_sort_order_5 AS `Dashboard Sort Order 5`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.vw_measure_quadrant view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_cell_performance" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        cell_performance_sk AS `Cell Performance Sk`,
                        cell_performance_code AS `Cell Performance Code`,
                        cell_performance_description AS `Cell Performance Description`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
 
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

try:
    if data_feed == "master_data_am_list" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                    SELECT
                        key As `Key`,
                        business_unit As `Business Unit`,
                        market_type As `Market Type`,
                        ice_cream_type As `Ice Cream Type`,
                        country As `Country`,
                        category_hierarchy As `Category Hierarchy`,
                        category As `Category`,
                        business_group As `Business Group`,
                        measure_type As `Measure Type`,
                        mat_l12w As `MAT_L12W`,
                        period As `Period`,
                        logic_type As `Logic Type`,
                        year As `Year`,
                        CASE WHEN logic_type ='Alternate Metrics' THEN 1  ELSE 0  END AS `AM Flag`
                    FROM
                        {uc_catalog_name}.{gold_db_name}.{gold_table_name} WHERE is_active = True""")
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
 
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e


# COMMAND ----------

try:
    if data_feed == "master_data_bu_hierarchies" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                        SELECT
                              bu_sk AS `BU SK`,
                              bu_code AS `BU Code`,
                              bu_description AS `BU Description`,
                              mu_code AS `MU Code`,
                              mu_description AS `MU Description`,
                              mu_hier_level_5_code AS `MU Hier Level 5 Code`,
                              mu_hier_level_5_description AS `MU Hier Level 5 Description`,
                              mu_hier_level_4_code AS `MU Hier Level 4 Code`,
                              mu_hier_level_4_description AS `MU Hier Level 4 Description`,
                              mu_hier_level_3_code AS `MU Hier Level 3 Code`,
                              mu_hier_level_3_description AS `MU Hier Level 3 Description`,
                              mu_hier_level_2_code AS `MU Hier Level 2 Code`,
                              mu_hier_level_2_description AS `MU Hier Level 2 Description`,
                              mu_hier_level_1_code AS `MU Hier Level 1 Code`,
                              mu_hier_level_1_description AS `MU Hier Level 1 Description`,
                              mu_hier_level_0_code AS `MU Hier Level 0 Code`,
                              mu_hier_level_0_description AS `MU Hier Level 0 Description`,
                              g.mu_iso_country_code AS `MU ISO Country Code`,
                              mu_iso_country_description AS `MU ISO Country Description`,
                              sc_mu_code AS `SC MU Code`,
                              sc_mu_description AS `SC MU Description`,
                              sc_level_6_code AS `SC Level 6 Code`,
                              sc_level_6_description AS `SC Level 6 Description`,
                              sc_level_5_code AS `SC Level 5 Code`,
                              sc_level_5_description AS `SC Level 5 Description`,
                              sc_level_4_code AS `SC Level 4 Code`,
                              sc_level_4_description AS `SC Level 4 Description`,
                              sc_level_3_code AS `SC Level 3 Code`,
                              sc_level_3_description AS `SC Level 3 Description`,
                              sc_level_2_code AS `SC Level 2 Code`,
                              sc_level_2_description AS `SC Level 2 Description`,
                              sc_level_1_code AS `SC Level 1 Code`,
                              sc_level_1_description AS `SC Level 1 Description`,
                              sc_level_0_code AS `SC Level 0 Code`,
                              sc_level_0_description AS `SC Level 0 Description`,
                              world_description AS `World Description`,
                              world_code AS `World Code`,
                              region_description AS `Region Description`,
                              region_code AS `Region Code`,
                              unilever_pmu_description AS `Unilever PMU Description`,
                              unilever_pmu_code AS `Unilever PMU Code`,
                              country_cluster_description AS `Country Cluster Description`,
                              country_cluster_code AS `Country Cluster Code`,
                              country_group_description AS `Country Group Description`,
                              country_group_code AS `Country Group Code`,
                              country_sub_group_description AS `Country Sub Group Description`,
                              country_sub_group_code AS `Country Sub Group Code`,
                              market_type_description AS `Market Type Description`,
                              market_type_code AS `Market Type Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_3_code
                                ELSE mu_hier_level_2_code
                              END AS `Level 1 HC Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_3_description
                                ELSE mu_hier_level_2_description
                              END AS `Level 1 HC Description`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_4_code
                                ELSE mu_hier_level_3_code
                              END AS `Level 2 HC Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_4_description
                                ELSE mu_hier_level_3_description
                              END AS `Level 2 HC Description`,
                              mu_hier_level_5_description AS `Level 3 HC Description`,
                              dummy_flag AS `Dummy Flag`,
                              g.source AS `Source`,
                              CAST(g.level_0_sort_order AS INT) as `Level 0 Sort Order`,
                              CAST(g.level_1_sort_order AS INT) AS `Level 1 Sort Order`,
                              CAST(g.level_2_sort_order AS INT) AS `Level 2 Sort Order`,
                              CAST(g.level_3_sort_order AS INT) AS `Level 3 Sort Order`,
                              CAST(g.level_4_sort_order AS INT) AS `Level 4 Sort Order`,
                              CAST(g.level_5_sort_order AS INT) AS `Level 5 Sort Order`,
                              g.dashboard_type AS `Dashboard Type`
                            FROM
                              (
                                SELECT
                                  *
                                FROM
                                  {uc_catalog_name}.gold_master_data.business_unit bu
                                    INNER JOIN {uc_catalog_name}.gold_master_data.bu_hierarchies buh
                                      ON (
                                        (
                                          buh.level_5_code IS NOT NULL
                                          AND buh.level_4_code IS NOT NULL
                                          AND buh.level_3_code IS NOT NULL
                                          AND buh.level_2_code IS NOT NULL
                                          AND buh.level_1_code IS NOT NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (
                                          buh.level_5_code = bu.mu_hier_level_5_code
                                          AND buh.level_4_code = bu.mu_hier_level_4_code
                                          AND buh.level_3_code = bu.mu_hier_level_3_code
                                          AND buh.level_2_code = bu.mu_hier_level_2_code
                                          AND buh.level_1_code = bu.mu_hier_level_1_code
                                          AND buh.level_0_code = bu.mu_hier_level_0_code
                                        )
                                        OR (
                                          buh.level_5_code IS NULL
                                          AND buh.level_4_code IS NOT NULL
                                          AND buh.level_3_code IS NOT NULL
                                          AND buh.level_2_code IS NOT NULL
                                          AND buh.level_1_code IS NOT NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (
                                          buh.level_4_code = bu.mu_hier_level_4_code
                                          AND buh.level_3_code = bu.mu_hier_level_3_code
                                          AND buh.level_2_code = bu.mu_hier_level_2_code
                                          AND buh.level_1_code = bu.mu_hier_level_1_code
                                          AND buh.level_0_code = bu.mu_hier_level_0_code
                                        )
                                        OR (
                                          buh.level_5_code IS NULL
                                          AND buh.level_4_code IS NULL
                                          AND buh.level_3_code IS NOT NULL
                                          AND buh.level_2_code IS NOT NULL
                                          AND buh.level_1_code IS NOT NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (
                                          buh.level_3_code = bu.mu_hier_level_3_code
                                          AND buh.level_2_code = bu.mu_hier_level_2_code
                                          AND buh.level_1_code = bu.mu_hier_level_1_code
                                          AND buh.level_0_code = bu.mu_hier_level_0_code
                                        )
                                        OR (
                                          buh.level_5_code IS NULL
                                          AND buh.level_4_code IS NULL
                                          AND buh.level_3_code IS NULL
                                          AND buh.level_2_code IS NOT NULL
                                          AND buh.level_1_code IS NOT NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (
                                          buh.level_2_code = bu.mu_hier_level_2_code
                                          AND buh.level_1_code = bu.mu_hier_level_1_code
                                          AND buh.level_0_code = bu.mu_hier_level_0_code
                                        )
                                        OR (
                                          buh.level_5_code IS NULL
                                          AND buh.level_4_code IS NULL
                                          AND buh.level_3_code IS NULL
                                          AND buh.level_2_code IS NULL
                                          AND buh.level_1_code IS NOT NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (
                                          buh.level_1_code = bu.mu_hier_level_1_code
                                          AND buh.level_0_code = bu.mu_hier_level_0_code
                                        )
                                        OR (
                                          buh.level_5_code IS NULL
                                          AND buh.level_4_code IS NULL
                                          AND buh.level_3_code IS NULL
                                          AND buh.level_2_code IS NULL
                                          AND buh.level_1_code IS NULL
                                          AND buh.level_0_code IS NOT NULL
                                        )
                                        AND (buh.level_0_code = bu.mu_hier_level_0_code)
                                      )
                                WHERE
                                  bu.is_active = TRUE
                              ) g
                                LEFT JOIN {uc_catalog_name}.gold_master_data.geography gu
                                  ON g.mu_iso_country_code = gu.mu_iso_country_code
                            UNION
                            SELECT
                              bu_sk AS `BU SK`,
                              bu_code AS `BU Code`,
                              bu_description AS `BU Description`,
                              mu_code AS `MU Code`,
                              mu_description AS `MU Description`,
                              mu_hier_level_5_code AS `MU Hier Level 5 Code`,
                              mu_hier_level_5_description AS `MU Hier Level 5 Description`,
                              mu_hier_level_4_code AS `MU Hier Level 4 Code`,
                              mu_hier_level_4_description AS `MU Hier Level 4 Description`,
                              mu_hier_level_3_code AS `MU Hier Level 3 Code`,
                              mu_hier_level_3_description AS `MU Hier Level 3 Description`,
                              mu_hier_level_2_code AS `MU Hier Level 2 Code`,
                              mu_hier_level_2_description AS `MU Hier Level 2 Description`,
                              mu_hier_level_1_code AS `MU Hier Level 1 Code`,
                              mu_hier_level_1_description AS `MU Hier Level 1 Description`,
                              mu_hier_level_0_code AS `MU Hier Level 0 Code`,
                              mu_hier_level_0_description AS `MU Hier Level 0 Description`,
                              g.mu_iso_country_code AS `MU ISO Country Code`,
                              mu_iso_country_description AS `MU ISO Country Description`,
                              sc_mu_code AS `SC MU Code`,
                              sc_mu_description AS `SC MU Description`,
                              sc_level_6_code AS `SC Level 6 Code`,
                              sc_level_6_description AS `SC Level 6 Description`,
                              sc_level_5_code AS `SC Level 5 Code`,
                              sc_level_5_description AS `SC Level 5 Description`,
                              sc_level_4_code AS `SC Level 4 Code`,
                              sc_level_4_description AS `SC Level 4 Description`,
                              sc_level_3_code AS `SC Level 3 Code`,
                              sc_level_3_description AS `SC Level 3 Description`,
                              sc_level_2_code AS `SC Level 2 Code`,
                              sc_level_2_description AS `SC Level 2 Description`,
                              sc_level_1_code AS `SC Level 1 Code`,
                              sc_level_1_description AS `SC Level 1 Description`,
                              sc_level_0_code AS `SC Level 0 Code`,
                              sc_level_0_description AS `SC Level 0 Description`,
                              world_description AS `World Description`,
                              world_code AS `World Code`,
                              region_description AS `Region Description`,
                              region_code AS `Region Code`,
                              unilever_pmu_description AS `Unilever PMU Description`,
                              unilever_pmu_code AS `Unilever PMU Code`,
                              country_cluster_description AS `Country Cluster Description`,
                              country_cluster_code AS `Country Cluster Code`,
                              country_group_description AS `Country Group Description`,
                              country_group_code AS `Country Group Code`,
                              country_sub_group_description AS `Country Sub Group Description`,
                              country_sub_group_code AS `Country Sub Group Code`,
                              market_type_description AS `Market Type Description`,
                              market_type_code AS `Market Type Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_3_code
                                ELSE mu_hier_level_2_code
                              END AS `Level 1 HC Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_3_description
                                ELSE mu_hier_level_2_description
                              END AS `Level 1 HC Description`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_4_code
                                ELSE mu_hier_level_3_code
                              END AS `Level 2 HC Code`,
                              CASE
                                WHEN mu_hier_level_1_code = 'MH006664' THEN mu_hier_level_4_description
                                ELSE mu_hier_level_3_description
                              END AS `Level 2 HC Description`,
                              mu_hier_level_5_description AS `Level 3 HC Description`,
                              dummy_flag AS `Dummy Flag`,
                              g.source AS `Source`,
                              CAST(g.level_0_sort_order AS INT) as `Level 0 Sort Order`,
                              CAST(g.level_1_sort_order AS INT) AS `Level 1 Sort Order`,
                              CAST(g.level_2_sort_order AS INT) AS `Level 2 Sort Order`,
                              CAST(g.level_3_sort_order AS INT) AS `Level 3 Sort Order`,
                              CAST(g.level_4_sort_order AS INT) AS `Level 4 Sort Order`,
                              CAST(g.level_5_sort_order AS INT) AS `Level 5 Sort Order`,
                              g.dashboard_type AS `Dashboard Type`
                            FROM
                              (
                                SELECT
                                  bu.bu_sk,
                                  bu.bu_code,
                                  bu.bu_description,
                                  bu.mu_code,
                                  bu.mu_description,
                                  bu.mu_hier_level_5_code,
                                  bu.mu_hier_level_5_description,
                                  bu.mu_hier_level_4_code,
                                  bu.mu_hier_level_4_description,
                                  bu.mu_hier_level_3_code,
                                  bu.mu_hier_level_3_description,
                                  bu.mu_hier_level_2_code,
                                  bu.mu_hier_level_2_description,
                                  bu.mu_hier_level_1_code,
                                  bu.mu_hier_level_1_description,
                                  bu.mu_hier_level_0_code,
                                  bu.mu_hier_level_0_description,
                                  bu.mu_iso_country_code,
                                  bu.mu_iso_country_description,
                                  bu.sc_mu_code,
                                  bu.sc_mu_description,
                                  bu.sc_level_6_code,
                                  bu.sc_level_6_description,
                                  bu.sc_level_5_code,
                                  bu.sc_level_5_description,
                                  bu.sc_level_4_code,
                                  bu.sc_level_4_description,
                                  bu.sc_level_3_code,
                                  bu.sc_level_3_description,
                                  bu.sc_level_2_code,
                                  bu.sc_level_2_description,
                                  bu.sc_level_1_code,
                                  bu.sc_level_1_description,
                                  bu.sc_level_0_code,
                                  bu.sc_level_0_description,
                                  bu.sc_mu_iso_country_code,
                                  bu.sc_mu_iso_country_description,
                                  bu.source,
                                  bu.dummy_flag,
                                  bu.is_active,
                                  MIN(hier.level_0_sort_order) AS level_0_sort_order,
                                  MIN(hier.level_1_sort_order) AS level_1_sort_order,
                                  MIN(hier.level_2_sort_order) AS level_2_sort_order,
                                  MIN(hier.level_3_sort_order) AS level_3_sort_order,
                                  MIN(hier.level_4_sort_order) AS level_4_sort_order,
                                  MIN(hier.level_5_sort_order) AS level_5_sort_order,
                                  hier.dashboard_type
                                FROM
                                  {uc_catalog_name}.silver_master_data.dim_descendant des
                                    JOIN {uc_catalog_name}.gold_master_data.bu_hierarchies hier
                                      ON des.child_code = hier.level_0_code
                                      OR des.child_code = hier.level_1_code
                                      OR des.child_code = hier.level_2_code
                                      OR des.child_code = hier.level_3_code
                                      OR des.child_code = hier.level_4_code
                                      OR des.child_code = hier.level_5_code
                                    JOIN {uc_catalog_name}.gold_master_data.business_unit bu
                                      ON bu.bu_sk = des.descendant_sk
                                WHERE
                                  des.dimension = 'mu'
                                  AND bu.is_active = TRUE
                                GROUP BY
                                  bu.bu_sk,
                                  bu.bu_code,
                                  bu.bu_description,
                                  bu.mu_code,
                                  bu.mu_description,
                                  bu.mu_hier_level_5_code,
                                  bu.mu_hier_level_5_description,
                                  bu.mu_hier_level_4_code,
                                  bu.mu_hier_level_4_description,
                                  bu.mu_hier_level_3_code,
                                  bu.mu_hier_level_3_description,
                                  bu.mu_hier_level_2_code,
                                  bu.mu_hier_level_2_description,
                                  bu.mu_hier_level_1_code,
                                  bu.mu_hier_level_1_description,
                                  bu.mu_hier_level_0_code,
                                  bu.mu_hier_level_0_description,
                                  bu.mu_iso_country_code,
                                  bu.mu_iso_country_description,
                                  bu.sc_mu_code,
                                  bu.sc_mu_description,
                                  bu.sc_level_6_code,
                                  bu.sc_level_6_description,
                                  bu.sc_level_5_code,
                                  bu.sc_level_5_description,
                                  bu.sc_level_4_code,
                                  bu.sc_level_4_description,
                                  bu.sc_level_3_code,
                                  bu.sc_level_3_description,
                                  bu.sc_level_2_code,
                                  bu.sc_level_2_description,
                                  bu.sc_level_1_code,
                                  bu.sc_level_1_description,
                                  bu.sc_level_0_code,
                                  bu.sc_level_0_description,
                                  bu.sc_mu_iso_country_code,
                                  bu.sc_mu_iso_country_description,
                                  bu.source,
                                  bu.dummy_flag,
                                  hier.dashboard_type,
                                  bu.is_active
                              ) g
                                LEFT JOIN {uc_catalog_name}.gold_master_data.geography gu
                                 ON g.mu_iso_country_code = gu.mu_iso_country_code """)
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")
 
except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e


# COMMAND ----------

try:
    if data_feed == "master_data_pc_hierarchies" :
        check_table_exists(uc_catalog_name, gold_db_name, gold_table_name)
        spark.sql(f"""
                    CREATE OR REPLACE VIEW {uc_catalog_name}.{gold_db_name}.{view_name} AS
                SELECT
                        product_sk As `Product SK`,
                        total_unilever_by_product_category_code As `Total Unilever by Product Category Code`,
                        total_unilever_by_product_category_description As `Total Unilever by Product Category Description`,
                        legacy_division_code As `Legacy Division Code`,
                        legacy_division_description As `Legacy Division Description`,
                        division_code As `Division Code`,
                        division_description As `Division Description`,
                        sub_division_2_code As `Sub Division 2 Code`,
                        sub_division_2_description As `Sub Division 2 Description`,
                        category_code As `Category Code`,
                        category_description As `Category Description`,
                        market_code As `Market Code`,
                        market_description As `Market Description`,
                        sector_code As `Sector Code`,
                        sector_description As `Sector Description`,
                        sub_sector_code As `Sub Sector Code`,
                        sub_sector_description As `Sub Sector Description`,
                        segment_code As `Segment Code`,
                        segment_description As `Segment Description`,
                        CASE
                            WHEN division_code = 'CF1159' THEN market_code
                            ELSE category_code
                        END AS `Category-Market Code`,
                        CASE
                            WHEN division_code = 'CF1159' THEN market_description
                            ELSE category_description
                        END AS `Category-Market Description`,
                        product_form_code As `Product Form Code`,
                        product_form_description As `Product Form Description`,
                        dummy_flag as `Dummy Flag`,
                        source as `Source`,
                        CAST(g.level_0_sort_order AS INT) as `Level 0 Sort Order`,
                        CAST(g.level_1_sort_order AS INT) AS `Level 1 Sort Order`,
                        CAST(g.level_2_sort_order AS INT) AS `Level 2 Sort Order`,
                        CAST(g.level_3_sort_order AS INT) AS `Level 3 Sort Order`,
                        CAST(g.level_4_sort_order AS INT) AS `Level 4 Sort Order`,
                        CAST(g.level_5_sort_order AS INT) AS `Level 5 Sort Order`,
                        g.dashboard_type AS `Dashboard Type`
                        FROM
                        (
                        SELECT
                        *
                        FROM
                        {uc_catalog_name}.gold_master_data.product pc
                        INNER JOIN {uc_catalog_name}.gold_master_data.pc_hierarchies pch
                        ON (
                        (
                        pch.level_5_code IS NOT NULL
                        AND pch.level_4_code IS NOT NULL
                        AND pch.level_3_code IS NOT NULL
                        AND pch.level_2_code IS NOT NULL
                        AND pch.level_1_code IS NOT NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (
                        pch.level_5_code = pc.market_code
                        AND pch.level_4_code = pc.category_code
                        AND pch.level_3_code = pc.sub_division_2_code
                        AND pch.level_2_code = pc.division_code
                        AND pch.level_1_code = pc.legacy_division_code
                        AND pch.level_0_code = pc.total_unilever_by_product_category_code
                        )
                        OR (
                        pch.level_5_code IS NULL
                        AND pch.level_4_code IS NOT NULL
                        AND pch.level_3_code IS NOT NULL
                        AND pch.level_2_code IS NOT NULL
                        AND pch.level_1_code IS NOT NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (
                        pch.level_4_code = pc.category_code
                        AND pch.level_3_code = pc.sub_division_2_code
                        AND pch.level_2_code = pc.division_code
                        AND pch.level_1_code = pc.legacy_division_code
                        AND pch.level_0_code = pc.total_unilever_by_product_category_code
                        )
                        OR (
                        pch.level_5_code IS NULL
                        AND pch.level_4_code IS NULL
                        AND pch.level_3_code IS NOT NULL
                        AND pch.level_2_code IS NOT NULL
                        AND pch.level_1_code IS NOT NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (
                        pch.level_3_code = pc.sub_division_2_code
                        AND pch.level_2_code = pc.division_code
                        AND pch.level_1_code = pc.legacy_division_code
                        AND pch.level_0_code = pc.total_unilever_by_product_category_code
                        )
                        OR (
                        pch.level_5_code IS NULL
                        AND pch.level_4_code IS NULL
                        AND pch.level_3_code IS NULL
                        AND pch.level_2_code IS NOT NULL
                        AND pch.level_1_code IS NOT NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (
                        pch.level_2_code = pc.division_code
                        AND pch.level_1_code = pc.legacy_division_code
                        AND pch.level_0_code = pc.total_unilever_by_product_category_code
                        )
                        OR (
                        pch.level_5_code IS NULL
                        AND pch.level_4_code IS NULL
                        AND pch.level_3_code IS NULL
                        AND pch.level_2_code IS NULL
                        AND pch.level_1_code IS NOT NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (
                        pch.level_1_code = pc.legacy_division_code
                        AND pch.level_0_code = pc.total_unilever_by_product_category_code
                        )
                        OR (
                        pch.level_5_code IS NULL
                        AND pch.level_4_code IS NULL
                        AND pch.level_3_code IS NULL
                        AND pch.level_2_code IS NULL
                        AND pch.level_1_code IS NULL
                        AND pch.level_0_code IS NOT NULL
                        )
                        AND (pch.level_0_code = pc.total_unilever_by_product_category_code)
                       )
                       WHERE pc.is_active = TRUE
                        ) g
                    UNION
                    SELECT
                    product_sk As `Product SK`,
                    total_unilever_by_product_category_code As `Total Unilever by Product Category Code`,
                    total_unilever_by_product_category_description As `Total Unilever by Product Category Description`,
                    legacy_division_code As `Legacy Division Code`,
                    legacy_division_description As `Legacy Division Description`,
                    division_code As `Division Code`,
                    division_description As `Division Description`,
                    sub_division_2_code As `Sub Division 2 Code`,
                    sub_division_2_description As `Sub Division 2 Description`,
                    category_code As `Category Code`,
                    category_description As `Category Description`,
                    market_code As `Market Code`,
                    market_description As `Market Description`,
                    sector_code As `Sector Code`,
                    sector_description As `Sector Description`,
                    sub_sector_code As `Sub Sector Code`,
                    sub_sector_description As `Sub Sector Description`,
                    segment_code As `Segment Code`,
                    segment_description As `Segment Description`,
                    CASE
                        WHEN division_code = 'CF1159' THEN market_code
                        ELSE category_code
                    END AS `Category-Market Code`,
                    CASE
                        WHEN division_code = 'CF1159' THEN market_description
                        ELSE category_description
                    END AS `Category-Market Description`,
                    product_form_code As `Product Form Code`,
                    product_form_description As `Product Form Description`,
                    dummy_flag as `Dummy Flag`,
                    g.source as `Source`,
                    CAST(g.level_0_sort_order AS INT) as `Level 0 Sort Order`,
                    CAST(g.level_1_sort_order AS INT) AS `Level 1 Sort Order`,
                    CAST(g.level_2_sort_order AS INT) AS `Level 2 Sort Order`,
                    CAST(g.level_3_sort_order AS INT) AS `Level 3 Sort Order`,
                    CAST(g.level_4_sort_order AS INT) AS `Level 4 Sort Order`,
                    CAST(g.level_5_sort_order AS INT) AS `Level 5 Sort Order`,
                    g.dashboard_type AS `Dashboard Type`
                    FROM
                    (
                    SELECT
                            pc.product_sk,
                            pc.total_unilever_by_product_category_code,
                            pc.total_unilever_by_product_category_description,
                            pc.legacy_division_code,
                            pc.legacy_division_description,
                            pc.division_code,
                            pc.division_description,
                            pc.sub_division_2_code,
                            pc.sub_division_2_description,
                            pc.category_code,
                            pc.category_description,
                            pc.market_code,
                            pc.market_description,
                            pc.sector_code,
                            pc.sector_description,
                            pc.sub_sector_code,
                            pc.sub_sector_description,
                            pc.segment_code,
                            pc.segment_description,
                            pc.product_form_code,
                            pc.product_form_description,
                            pc.source,
                            pc.dummy_flag,
                            pc.is_active,
                            MIN(hier.level_0_sort_order) AS level_0_sort_order,
                            MIN(hier.level_1_sort_order) AS level_1_sort_order,
                            MIN(hier.level_2_sort_order) AS level_2_sort_order,
                            MIN(hier.level_3_sort_order) AS level_3_sort_order,
                            MIN(hier.level_4_sort_order) AS level_4_sort_order,
                            MIN(hier.level_5_sort_order) AS level_5_sort_order,
                            hier.dashboard_type
                            FROM
                            {uc_catalog_name}.silver_master_data.dim_descendant des
                                JOIN {uc_catalog_name}.gold_master_data.pc_hierarchies hier
                                ON des.child_code = hier.level_0_code
                                OR des.child_code = hier.level_1_code
                                OR des.child_code = hier.level_2_code
                                OR des.child_code = hier.level_3_code
                                OR des.child_code = hier.level_4_code
                                OR des.child_code = hier.level_5_code
                                JOIN {uc_catalog_name}.gold_master_data.product pc
                                ON pc.product_sk = des.descendant_sk
                            WHERE
                            des.dimension = 'pcat'
                            AND pc.is_active = TRUE
                            GROUP BY
                            pc.product_sk,
                            pc.total_unilever_by_product_category_code,
                            pc.total_unilever_by_product_category_description,
                            pc.legacy_division_code,
                            pc.legacy_division_description,
                            pc.division_code,
                            pc.division_description,
                            pc.sub_division_2_code,
                            pc.sub_division_2_description,
                            pc.category_code,
                            pc.category_description,
                            pc.market_code,
                            pc.market_description,
                            pc.sector_code,
                            pc.sector_description,
                            pc.sub_sector_code,
                            pc.sub_sector_description,
                            pc.segment_code,
                            pc.segment_description,
                            pc.product_form_code,
                            pc.product_form_description,
                            pc.source,
                            pc.dummy_flag,
                            hier.dashboard_type,
                            pc.is_active
                            ) g
                        """)
        
        print(f"{uc_catalog_name}.{gold_db_name}.{view_name} view created successfully.")

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter = counter + 1
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id,uc_catalog_name)
    update_job_log(log_value,status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter) , log_value, run_id, username, f"Facing issues while creating {view_name} view, please check the logs for more details", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code,uc_catalog_name, error)
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ####View creation completed Audit Entry

# COMMAND ----------

# Audit Tables Success Entries
counter = counter + 1
update_job(job_id,run_id, module_id, feed_type_id, feed_id, status_success_id,uc_catalog_name)
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Master view creation completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
