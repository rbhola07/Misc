# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 24 Feb 2024        |   Prasanth/Vinod         |    Notebook Created  |
# MAGIC |25 Feb 2025       |    Gokul Prasanth          |     enhancement      |
# MAGIC
# MAGIC ## Purpose
# MAGIC Purpose of this notebook is used to create hierarchical column for child code
# MAGIC
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - debug_flag    : Determines whether to display the outputs
# MAGIC - pipeline_name : Name of the master pipeline that called this notebook
# MAGIC - notebook_name : transaction notebook to be triggered
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and silver delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC History maintainence and Active flag

# COMMAND ----------

# MAGIC %md
# MAGIC ####Import Dependancy Notebooks and library

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

external_location       = dbutils.widgets.get("external_location")
uc_catalog_name         = dbutils.widgets.get("uc_catalog_name")
object_owner_spn        = dbutils.widgets.get("object_owner_spn")
username                = dbutils.widgets.get("username")
data_feed               = dbutils.widgets.get("data_feed")
debug_flag              = dbutils.widgets.get("debug_flag")
run_id                  = dbutils.widgets.get("run_id")
job_id                  = dbutils.widgets.get("job_id")

dbutils.widgets.text("data_feed_descendant","master_data_descendant")
data_feed_descendant    = dbutils.widgets.get("data_feed_descendant")

#Converting to integers
run_id = int(run_id)
job_id = int(job_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Notebook config metadata parameters 

# COMMAND ----------

try:
    # Get the absolute path
    absolute_path = return_absolute_path(external_location)

    # Get the current notebook name
    current_nb_name = "nb_pmrs_master_silver_Ingestion"

    # Get feed ID, module ID, and feed type ID
    feed_id, module_id, feed_type_id = get_audit_feed_info(data_feed, uc_catalog_name, current_nb_name)

    # Get status IDs
    status_failure_id, status_success_id, status_running_id = get_status_ids(uc_catalog_name)

    # Get run ID and job ID
    log_id = run_id

    # Debugging information
    if debug_flag == "1":
        print(f"run_id : {run_id}, job_id : {job_id}, log_id : {log_id}\n")
        print(f"absolute_path        : {absolute_path}")
        print(f"data_feed            : {data_feed}")
        print(f"external_location    : {external_location}")
        print(f"notebook_name        : {current_nb_name}")
        print(f"object_owner_spn     : {object_owner_spn}")
        print(f"uc_catalog_name      : {uc_catalog_name}")
        print(f"username             : {username}")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# Insert a job record into the job table
counter = 1
log_value = run_id + 2
detail_log_value = log_value * 10

# Insert job detail log
insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Silver to gold ingestion for Descendant", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, "", uc_catalog_name, "")
 
# Debugging output
if debug_flag == "1":
    print('log_id:', log_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Read Config Metadata Params

# COMMAND ----------

catalog_name                    = uc_catalog_name
param                           = get_param_data(uc_catalog_name)
process_feed_descendant_df      = fetch_config(param, data_feed_descendant)   
descendant_db_silver            = process_feed_descendant_df.select("delta_db_silver").first()[0]
descendant_table_silver         = process_feed_descendant_df.select("delta_table_silver").first()[0]
descendant_path_silver          = absolute_path+process_feed_descendant_df.select("delta_path_silver").first()[0]
descendant_db_gold              = process_feed_descendant_df.select("delta_db_gold").first()[0]
descendant_table_gold           = process_feed_descendant_df.select("delta_table_gold").first()[0]
descendant_path_gold            = absolute_path+process_feed_descendant_df.select("delta_path_gold").first()[0]

if debug_flag==1:
    print(descendant_path_gold)
    print(descendant_table_gold)
    print(descendant_db_gold)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Descendant child logic development

# COMMAND ----------

from datetime import datetime

try:
    if 'business_unit' in data_feed:
        df = spark.read.table(f"{catalog_name}.silver_master_data.business_unit").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance, Market%'")
        bu_variable = 'mu' if data_feed == 'master_data_business_unit_mu' else 'sc'
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter(f"dimension = '{bu_variable}'")

    elif 'product' in data_feed:
        df = spark.read.table(f"{catalog_name}.silver_master_data.product").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance%'")
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter("dimension = 'pcat'")

    elif data_feed == "master_data_brand":
        df = spark.read.table(f"{catalog_name}.silver_master_data.brand").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance%'")
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter("dimension = 'brand'")

    elif 'brand_position' in data_feed:
        df = spark.read.table(f"{catalog_name}.silver_master_data.brand_position").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance%'")
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter("dimension = 'brand_position'")

    elif data_feed == "master_data_customer":
        df = spark.read.table(f"{catalog_name}.silver_master_data.customer").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance%'")
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter("dimension = 'customer'")
    
    elif data_feed == "master_data_company":
        df = spark.read.table(f"{catalog_name}.silver_master_data.company").filter("dummy_flag IS FALSE AND is_active IS TRUE AND source LIKE '%Finance%'")
        descendant_df = spark.read.table(f"{catalog_name}.silver_master_data.dim_descendant").filter("dimension = 'company'")

    else:
        df, descendant_df = None, None

    if debug_flag == "1":
        descendant_df.display()
        df.display()

except Exception as e:
    error = str(e).replace("'", "")
    error_code = type(e).__name__
    counter += 1  # Assuming counter is defined elsewhere
    update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
    update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
    insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
    raise e

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType, ArrayType

def aggregate_hierarchy(df, filter_col, hierarchy_cols):
    """
    Accurate optimized aggregation of hierarchical data with same output as original function, preserving order.
    """

    # Group by filter_col and aggregate hierarchical data
    aggregated_df = df.groupBy(filter_col).agg(
        F.concat_ws(",", F.collect_set(F.concat_ws(",", *[F.col(col) for col in hierarchy_cols]))).alias("combined_hierarchical_column")
    )

    # Remove duplicates while preserving order
    def remove_duplicates_preserve_order(s):
        if s is None:
            return None
        items = s.split(",")
        seen = set()
        result = []
        for item in items:
            if item not in seen:
                seen.add(item)
                result.append(item)
        return ",".join(result)

    remove_duplicates_udf = F.udf(remove_duplicates_preserve_order, StringType())

    final_df = aggregated_df.withColumn(
        "combined_hierarchical_column", remove_duplicates_udf(F.col("combined_hierarchical_column"))
    ).withColumn("child_code", F.col(filter_col)).select("child_code", "combined_hierarchical_column")

    return final_df

# COMMAND ----------

if data_feed == 'master_data_business_unit_mu':
    try:
        dimension = 'mu'

        levels = [
            ("mu_hier_level_0_code", ["mu_hier_level_0_code", "mu_hier_level_1_code", "mu_hier_level_2_code", "mu_hier_level_3_code", "mu_hier_level_4_code","mu_hier_level_5_code", "mu_code", "bu_code"]),
            ("mu_hier_level_1_code", ["mu_hier_level_1_code", "mu_hier_level_2_code", "mu_hier_level_3_code", "mu_hier_level_4_code", "mu_hier_level_5_code","mu_code", "bu_code"]),
            ("mu_hier_level_2_code", ["mu_hier_level_2_code", "mu_hier_level_3_code", "mu_hier_level_4_code","mu_hier_level_5_code", "mu_code", "bu_code"]),
            ("mu_hier_level_3_code", ["mu_hier_level_3_code", "mu_hier_level_4_code", "mu_hier_level_5_code","mu_code", "bu_code"]),
            ("mu_hier_level_4_code", ["mu_hier_level_4_code","mu_hier_level_5_code", "mu_code", "bu_code"]),
            ("mu_hier_level_5_code", ["mu_hier_level_5_code", "mu_code", "bu_code"]),
            ("mu_code", ["mu_code", "bu_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 7, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        print("Displaying final result:")
        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1  # Assuming counter is defined elsewhere
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "aggregate_hierarchy failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_business_unit_sc':
    try:
        dimension = 'sc'

        levels = [
            ("sc_level_0_code", ["sc_level_0_code", "sc_level_1_code", "sc_level_2_code", "sc_level_3_code", "sc_level_4_code", "sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_1_code", ["sc_level_1_code", "sc_level_2_code", "sc_level_3_code", "sc_level_4_code", "sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_2_code", ["sc_level_2_code", "sc_level_3_code", "sc_level_4_code", "sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_3_code", ["sc_level_3_code", "sc_level_4_code", "sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_4_code", ["sc_level_4_code", "sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_5_code", ["sc_level_5_code", "sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_level_6_code", ["sc_level_6_code", "sc_mu_code", "bu_code"]),
            ("sc_mu_code", ["sc_mu_code", "bu_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 8, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        print("Displaying final result:")
        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1  # Assuming counter is defined elsewhere
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_product_category':
    try:
        dimension = 'pcat'

        levels = [
            ("total_unilever_by_product_category_code", ["total_unilever_by_product_category_code", "legacy_division_code", "division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("legacy_division_code", ["legacy_division_code", "division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("division_code", ["division_code", "sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("sub_division_2_code", ["sub_division_2_code", "category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("category_code", ["category_code", "market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("market_code", ["market_code", "sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("sector_code", ["sector_code", "sub_sector_code", "segment_code", "product_form_code"]),
            ("sub_sector_code", ["sub_sector_code", "segment_code", "product_form_code"]),
            ("segment_code", ["segment_code", "product_form_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 9, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        print("Displaying final result:")
        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1  # Assuming counter is defined elsewhere
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_company':
    try:
        dimension = 'company'
 
        levels = [
      ("total_legal_entity_geography_code", ["total_legal_entity_geography_code", "region_code", "cluster_code", "sub_region_code", "country_code","sub_country_code", "legal_entity_code"]),
      ("region_code",      ["region_code", "cluster_code", "sub_region_code", "country_code", "sub_country_code","legal_entity_code"]),
      ("cluster_code",     ["cluster_code", "sub_region_code", "country_code","sub_country_code", "legal_entity_code"]),
      ("sub_region_code",  ["sub_region_code", "country_code", "sub_country_code","legal_entity_code"]),
      ("country_code",     ["country_code","sub_country_code", "legal_entity_code"]),
      ("sub_country_code", ["sub_country_code", "legal_entity_code"]),
        ]
 
        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()
 
        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)
 
        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))
 
        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 6, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )
 
        print("Displaying final result:")
        last_df.display()
 
    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1  # Assuming counter is defined elsewhere
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "aggregate_hierarchy failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_brand':
    try:
        dimension = 'brand'

        levels = [
            ("total_by_finance_code", ["total_by_finance_code", "corporate_parent_finance_code", "corporate_brand_code"]),
            ("corporate_parent_finance_code", ["corporate_parent_finance_code", "corporate_brand_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 2, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_brand_position':
    try:
        dimension = 'brand_position'

        levels = [
            ("brand_position_level_0_code", ["brand_position_level_0_code", "brand_position_level_1_code", "brand_position_level_2_code", "brand_position_level_3_code", "brand_position_default_code"]),
            ("brand_position_level_1_code", ["brand_position_level_1_code", "brand_position_level_2_code", "brand_position_level_3_code", "brand_position_default_code"]),
            ("brand_position_level_2_code", ["brand_position_level_2_code", "brand_position_level_3_code", "brand_position_default_code"]),
            ("brand_position_level_3_code", ["brand_position_level_3_code", "brand_position_default_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 4, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

if data_feed == 'master_data_customer':
    try:
        dimension = 'customer'

        levels = [
            ("total_customer_code", ["total_customer_code", "customer_importance_code", "global_customer_group_finance_code", "global_customer_finance_code"]),
            ("customer_importance_code", ["customer_importance_code", "global_customer_group_finance_code", "global_customer_finance_code"]),
            ("global_customer_group_finance_code", ["global_customer_group_finance_code", "global_customer_finance_code"])
        ]

        # Process all levels and union them
        all_dfs = []
        for col, hierarchy in levels:
            level_df = aggregate_hierarchy(df, col, hierarchy)
            all_dfs.append(level_df)
            print(f"Displaying results for {col}:")
            level_df.display()

        write_df = all_dfs[0]
        for next_df in all_dfs[1:]:
            write_df = write_df.unionByName(next_df)

        last_df = descendant_df.alias("a").join(
            write_df.alias("b"),
            F.col('a.child_code') == F.col('b.child_code'),
            how="left"
        ).select(F.col("a.*"), F.col("b.combined_hierarchical_column"))

        last_df = last_df.withColumn(
            "combined_hierarchical_column",
            F.when(F.col("level_num") == 3, F.col("child_code")).otherwise(F.col("combined_hierarchical_column"))
        )

        last_df.display()

    except Exception as e:
        error = str(e).replace("'", "")
        error_code = type(e).__name__
        counter += 1
        update_job(job_id, run_id, module_id, feed_type_id, feed_id, status_failure_id, uc_catalog_name)
        update_job_log(log_value, status_failure_id, job_id, run_id, feed_type_id, feed_id, module_id, uc_catalog_name)
        insert_job_detail_log(int(detail_log_value + counter), log_value, run_id, username, "Descendant Gold Failure", datetime.now(), status_running_id, feed_type_id, feed_id, module_id, 0, error_code, uc_catalog_name, error)
        raise e

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write into Gold Staging Delta path
# MAGIC This function responsible 
# MAGIC - Ingestion type
# MAGIC - Table creation for specific DB
# MAGIC - concurent delta write
# MAGIC - Table schema check and raise

# COMMAND ----------

descentant_table_delta_write(last_df, descendant_path_gold, descendant_db_gold, descendant_table_gold,partition_columns=["dimension"], catalog_name=catalog_name,object_owner_spn=object_owner_spn, retry_count=0,overwriteSchema_flag="false", delta_overwrite_mode="full")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Ingestion completed Audit Entry

# COMMAND ----------

counter = counter + 1
update_job_log(log_value,status_success_id, job_id, run_id, feed_type_id, feed_id, module_id,uc_catalog_name)
insert_job_detail_log(int(detail_log_value + counter) , log_value,  run_id, username, "Gold ingestion descendant completed successfully", datetime.now(), status_success_id, feed_type_id, feed_id, module_id, 0, "",uc_catalog_name, "")
