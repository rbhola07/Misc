# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks Fact Actuals Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |   25 Nov 2024     |    Vinod          |    Notebook Created |
# MAGIC
# MAGIC
# MAGIC ## Purpose
# MAGIC This Notebook is used to load Fact Autuals data
# MAGIC
# MAGIC ### Output
# MAGIC Data will be stored in the location based on the run in delta format and staging delta path
# MAGIC
# MAGIC ### Scheduling
# MAGIC ADF based on storage events trigger
# MAGIC
# MAGIC ### Transformations
# MAGIC Add Sources
# MAGIC Add Selective Columns, Rename Columns for Ingestion and Add Audit Columns

# COMMAND ----------

# MAGIC %md
# MAGIC #### Import Dependancy Notebooks and library

# COMMAND ----------

from pyspark.sql.functions import sum, col, lower, regexp_replace, trim
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType, TimestampType, FloatType, DecimalType, LongType
from pyspark.sql.functions import *
from pyspark.sql.functions import sum, col, lower, regexp_replace, trim, expr, first, when
from pyspark.sql.functions import expr, col

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intialize widgets Parameters

# COMMAND ----------

# Remove all widgets
dbutils.widgets.removeAll()

# Create widgets for various parameters
dbutils.widgets.text("data_feed", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("log_id","")
dbutils.widgets.text("month_sk","")
dbutils.widgets.text("dimension_code","")
dbutils.widgets.text("delta_table_gold","")
dbutils.widgets.text("delta_table_staging","")

# Get the values from the widgets
data_feed             = dbutils.widgets.get("data_feed")
uc_catalog_name       = dbutils.widgets.get("uc_catalog_name")
log_id                = dbutils.widgets.get("log_id")
month_sk              = dbutils.widgets.get("month_sk")
dimension_code        = dbutils.widgets.get("dimension_code")
delta_table_gold      = dbutils.widgets.get("delta_table_gold")
delta_table_staging   = dbutils.widgets.get("delta_table_staging")


# Set the task values for the job
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
dbutils.jobs.taskValues.set("log_id", log_id)
dbutils.jobs.taskValues.set("month_sk", month_sk)
dbutils.jobs.taskValues.set("dimension_code", dimension_code)
dbutils.jobs.taskValues.set("delta_table_gold", delta_table_gold)
dbutils.jobs.taskValues.set("delta_table_staging", delta_table_staging)

print("data_feed            :",data_feed)
print("uc_catalog_name      :",uc_catalog_name)
print("log_id               :",log_id)
print("month_sk             :",month_sk)
print("dimension_code       :",dimension_code)
print("delta_table_gold     :",delta_table_gold)
print("delta_table_staging  :",delta_table_staging)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze layer data recon

# COMMAND ----------

try:
    print(f"Dimension Code: {dimension_code}")

    if data_feed== 'finance_fact_bex_actuals':
        df_fact_bronze = (spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")
                            .filter((col("flow").like("%Month%")) & (col("log_id") == log_id)))
    else:
        df_fact_bronze = (spark.table(f"{uc_catalog_name}.bronze_finance.{delta_table_staging}")
                            .filter((col("log_id") == log_id)))

    df_des_bu = (spark.table(f"{uc_catalog_name}.silver_master_data.dim_descendant")
                    .filter(col("dimension") == dimension_code))

    df_des_pcat = (spark.table(f"{uc_catalog_name}.silver_master_data.dim_descendant")
                        .filter(col("dimension") == "pcat"))


    # Join Bronze data with BU and PCAT hierarchy mappings
    df_joined      = df_fact_bronze.join(df_des_bu, df_fact_bronze.business_unit == df_des_bu.child_code, "inner")\
                                   .join(df_des_pcat, df_fact_bronze.product_category == df_des_pcat.child_code, "inner")\
                                   .select(df_des_bu['level_num'].alias('bu_level'),
                                            df_des_pcat['level_num'].alias('pcat_level'),
                                            df_des_pcat['descendant_sk'].alias('pcat_sk'),
                                            df_des_bu['descendant_sk'].alias('bu_sk'),
                                            *df_fact_bronze.columns)\
                                   .drop("log_id", "created_date")

    # Define columns to exclude from aggregation
    exclude_columns  = ['company', 'bu_level', 'pcat_level', 'pcat_sk', 'bu_sk', 'business_unit', 'product_category', 'flow','version','brand']
    columns_to_sum   = [col for col in df_joined.columns if col not in exclude_columns]

    # Aggregate data by 'bu_level' and 'pcat_level'
    grouped_df      = (df_joined.groupBy('bu_level', 'pcat_level', 'product_category', 'business_unit') 
                                .agg(*[sum(col).alias(col) for col in columns_to_sum]) \
                                .orderBy("bu_level","pcat_level"))
    
    # Get the columns to unpivot
    columns_to_unpivot = [col for col in grouped_df.columns if col not in ["bu_level", "pcat_level", "business_unit", "product_category"]]
    num_columns        = len(columns_to_unpivot)

    # Unpivot using stack()
    unpivoted_df      = grouped_df.select( "bu_level", "pcat_level", "business_unit", "product_category",
                        expr(f"stack({num_columns}, " + ", ".join(
                            [f"'{col}', cast({col} as STRING)" for col in columns_to_unpivot]) + ") as (measure_description, value)"))
    unpivoted_df     = unpivoted_df.withColumn("value", unpivoted_df["value"].cast(DecimalType(36, 16)))
    unpivoted_df.display()
    

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

try:
    measure_df = spark.table(f"{uc_catalog_name}.gold_master_data.measure")

    measure_df = measure_df \
                .withColumn("measure_description", lower(col("measure_description"))) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "%", "percent")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "٪", "percent")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "[- ]", "_")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "_+", "_")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "–", " ")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "[^a-zA-Z0-9_]", "")) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), r"^_|_$", "")) \
                .withColumn("measure_description", trim(col("measure_description"))) \
                .withColumn("measure_description", regexp_replace(col("measure_description"), "pm", "p_m"))

    measure_df = measure_df.withColumn( "measure_description",
                    when(col("measure_description") == "promotional_to_percent", "promotional_percent_t_o")
                    .when(col("measure_description") == "pbo_perc_to", "pbopercent_to")
                    .when(col("measure_description") == "tts_perc", "tts_percent")
                    .when(col("measure_description") == "ad_related_costs", "a_d_related_costs")
                    .when(col("measure_description") == "overheads_perc_turnover_cy", "overheads_percent_turnover_cy")
                    .when(col("measure_description") == "brand_and_marketing_investment_perc", "brand_and_marketing_investment_percent")
                    .when(col("measure_description") == "adv_to_percent", "adv_percent_t_o")
                    .when(col("measure_description") == "business_waste_fixed_assets_woff_r2", "business_waste_fixed_assets_w_off_r2")
                    .when(col("measure_description") == "adjusted_cy_to", "adjusted_cy_t_o")
                    .when(col("measure_description") == "adjusted_usg", "adjusted_usgpercent")
                    .when(col("measure_description") == "adjusted_uvg", "adjusted_uvgpercent")
                    .when(col("measure_description") == "customer_sales_equip_ment", "customer_sales_equipment")
                    .when(col("measure_description") == "marketing_develop_ment", "marketing_development")
                    .when(col("measure_description") == "product_develop_ment", "product_development")
                    .when(col("measure_description") == "bw_material_w_off_rm_p_m_semi_fg", "bw_material_w_off_rm_pm_semi_fg")
                    .when(col("measure_description") == "p_m_bip_adjustment_p_m_costs", "p_m_bip_adjustment_pm_costs")
                    .otherwise(col("measure_description"))  # Keep other values unchanged
                    )

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold layer data recon

# COMMAND ----------

try:
    df_fact  = spark.table(f"{uc_catalog_name}.gold_finance.{delta_table_gold}").filter(col("month_sk") == month_sk)
    df_bu    = spark.table(f"{uc_catalog_name}.gold_master_data.business_unit") \
                    .filter(col("is_active") == True)

    df_pcat  = spark.table(f"{uc_catalog_name}.gold_master_data.product") \
                    .filter(col("is_active") == True)

    # Join Gold data with BU and PCAT
    df_joined = (df_fact.join(df_bu, df_fact.bu_sk == df_bu.bu_sk, "inner")
                        .filter(df_bu.bu_sk != -1)
                        .join(df_pcat, df_fact.product_sk == df_pcat.product_sk, "inner")
                        .filter(df_pcat.product_sk != -1))

    # Join Unpivoted Bronze with Measure Mapping
    df_joined = df_joined.join(measure_df, measure_df.measure_sk == df_joined.measure_sk, "inner")\
                         .filter((col('measure_type') == 'PnL Direct Measures') & 
                         (~col('measure_description').isin('uvg_as_reported', 'underlying_operating_margin')))

    df_joined.display()

    # Define hierarchy mappings
    pcat_levels = [
        "total_unilever_by_product_category_code", "legacy_division_code", "division_code", "sub_division_2_code", "category_code",
        "market_code", "sector_code", "sub_sector_code", "segment_code","product_form_code"]

    if  dimension_code == 'mu':
        bu_levels = ["mu_hier_level_0_code","mu_hier_level_1_code","mu_hier_level_2_code","mu_hier_level_3_code","mu_hier_level_4_code",
        "mu_hier_level_5_code","mu_code","bu_code"]

    else:
        bu_levels = ["sc_level_0_code","sc_level_1_code","sc_level_2_code","sc_level_3_code","sc_level_4_code","sc_level_5_code","sc_level_6_code","sc_mu_code","sc_bu_finance_code"]    

    # Extract (bu_level, pcat_level) pairs
    pairs_list = unpivoted_df.select("bu_level", "pcat_level").distinct().collect()
    pairs_list = [(row["bu_level"], row["pcat_level"]) for row in pairs_list]
    print(pairs_list)

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")

# COMMAND ----------

try:
    mismatch_found = False 

    # Iterate over each (bu_level, pcat_level) pair
    for bu_level, pcat_level in pairs_list:

        selected_bu_column   = bu_levels[bu_level]  
        selected_pcat_column = pcat_levels[pcat_level]  
        print(f"\nProcessing (bu_level={bu_level}, pcat_level={pcat_level}) → {selected_bu_column}, {selected_pcat_column}")

        # Aggregate Bronze
        df_bronze_agg  = unpivoted_df.filter((col("bu_level") == bu_level) & (col("pcat_level") == pcat_level)) \
                                    .groupBy("business_unit", "product_category", "measure_description") \
                                    .agg((sum("value")).alias("bronze_total"))

        # Aggregate Gold
        df_gold_agg = df_joined.groupBy("measure_description", selected_bu_column, selected_pcat_column)\
                                .agg((sum("value")).alias("gold_total"))

        df_comparison = df_bronze_agg.join( df_gold_agg,
                                (df_bronze_agg["business_unit"]         == df_gold_agg[selected_bu_column]) &
                                (df_bronze_agg["product_category"]      == df_gold_agg[selected_pcat_column]) &
                                (df_bronze_agg["measure_description"]   == df_gold_agg["measure_description"]),"inner" )\
                                    .select(  df_bronze_agg["business_unit"], df_bronze_agg["product_category"],
                                                df_bronze_agg["measure_description"],df_bronze_agg["bronze_total"],
                                                df_gold_agg["gold_total"])\
                                        .fillna(0, subset=["bronze_total", "gold_total"]) \
                                        .withColumn("difference", col("bronze_total") - col("gold_total")) \
                                        .withColumn("difference", format_number(col("difference"),5))                       

        # Print Mismatches
        mismatches  = df_comparison.filter(col("difference") != 0)
        matches     = df_comparison.filter(col("difference") == 0)
        
        matches = matches.withColumn("log_id",lit(log_id))
        
        if mismatches.count() > 0:
            print(f"Mismatch found for (bu_level={bu_level}, pcat_level={pcat_level}):")
            mismatches.display()
            mismatch_found = True  # Set flag if mismatch is found
        else:
            print(f"No mismatch for (bu_level={bu_level}, pcat_level={pcat_level}).")

    # Raise exception if any mismatch was found
    if mismatch_found:
        raise Exception("Mismatch found in one or more (bu_level, pcat_level) pairs.")

except Exception as e:
    error = str(e).replace("'", "")
    raise Exception(f"Error occurred: {error}")
