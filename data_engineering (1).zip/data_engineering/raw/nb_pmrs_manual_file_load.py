# Databricks notebook source
# MAGIC %md
# MAGIC # **Raw Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC | 5/3/2024  | Ashwini Rajput          |  Manual FIle Load to ADLS ingestion  |
# MAGIC
# MAGIC ## Purpose
# MAGIC  Manual FIle Load to ADLS ingestion 
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - external_location : Name of the adls external location
# MAGIC - uc_view_name : Name of the uc catalog view from where the source is read
# MAGIC
# MAGIC ### Output
# MAGIC  Manual FIle Load to ADLS ingestion 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql import functions as F, Row, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType,TimestampType,FloatType
from pyspark.sql.functions import col, lit, current_timestamp, desc, row_number
from pyspark.sql.functions import size, replace, to_date, month, year, last, coalesce
from delta.tables import *
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intialize Widget Parameters

# COMMAND ----------

dbutils.widgets.removeAll()

# Create widgets for various parameters
dbutils.widgets.text("data_feed", "")
dbutils.widgets.text("debug_flag", "")
dbutils.widgets.text("external_location", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("object_owner_spn", "")
dbutils.widgets.text("FilePath","")
dbutils.widgets.text("FileName","")
dbutils.widgets.text("uc_view_name","")
dbutils.widgets.text("user_name","")
dbutils.widgets.text("processing_file_path","")


data_feed       = dbutils.widgets.get("data_feed")
external_location   = dbutils.widgets.get("external_location")
debug_flag     = dbutils.widgets.get("debug_flag")
object_owner_spn     = dbutils.widgets.get("object_owner_spn")
username     = dbutils.widgets.get("user_name")
uc_catalog_name     = dbutils.widgets.get("uc_catalog_name")
processing_file_path     = dbutils.widgets.get("processing_file_path")  



# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

# Extract year,month,day,hour,minute for current date
fname = processing_file_path.split("/")[-1]
year = str(datetime.today().year)
yearmonth = year + str(datetime.today().month)
yearmonthday = yearmonth + str(datetime.today().day)
hourminute = str(datetime.today().hour) + str(datetime.today().minute)
dest_path=""

# COMMAND ----------

# Generate destination path for manual file load and replace the one set by the webapp.

if data_feed in ['market_fact_business_winning','market_fact_channel_data']:
        absolute_path = return_absolute_path(external_location)
        if fname.endswith(".xlsx"):
            source_path = f"data_engineering/bronze/raw/market/fact/excel/"
            dest_path = f"data_engineering/bronze/raw/market/fact/excel/{data_feed}/{year}/{yearmonth}/{yearmonthday}/{hourminute}"
        else:
            source_path = f"data_engineering/bronze/raw/market/fact/csv/"
            dest_path = f"data_engineering/bronze/raw/market/fact/csv/{data_feed}/{year}/{yearmonth}/{yearmonthday}/{hourminute}"

        final_dest_path = f"""{absolute_path}{dest_path}"""  
        source_path = f"""{absolute_path}{source_path}"""
        dbutils.fs.cp(f'{processing_file_path}',f'{final_dest_path}/{fname}',True)

        delete_path = processing_file_path.split("excel")[0] + "excel" + processing_file_path.split("excel")[1] + "excel/"

        dbutils.fs.rm(f"{delete_path}",True)
        

# COMMAND ----------

# Set parameters for next task
dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("user_name", username)
dbutils.jobs.taskValues.set("processing_file_path", dest_path + "/" + fname)
dbutils.jobs.taskValues.set("FilePath", dest_path)
dbutils.jobs.taskValues.set("FileName", fname)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
