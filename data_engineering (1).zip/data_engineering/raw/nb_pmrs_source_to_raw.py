# Databricks notebook source
# MAGIC %md
# MAGIC # **Raw Ingestion Notebook**
# MAGIC
# MAGIC ## History
# MAGIC | Date               |    Developed By          |    Reason                     |
# MAGIC | ------------------ | ------------------------ |------------------------------ |
# MAGIC |    3/12/2024    |  Aditya Goenka             |  UC view to ADLS raw ingestion  |
# MAGIC
# MAGIC ## Purpose
# MAGIC UC view to ADLS raw ingestion
# MAGIC
# MAGIC ### Parameters
# MAGIC - data_feed     : Name of the dataset that needs to be ingested
# MAGIC - external_location : Name of the adls external location
# MAGIC - uc_view_name : Name of the uc catalog view from where the source is read
# MAGIC
# MAGIC ### Output
# MAGIC UC view to ADLS raw ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import Dependancy Notebooks and library

# COMMAND ----------

import os
import re
import time
import json
import requests
import traceback
from datetime import datetime, date, timedelta
from functools import reduce
from pytz import timezone
import pandas as pd
import pyspark
from pyspark.sql import functions as F, Row, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import _parse_datatype_string, IntegerType, StringType,TimestampType,FloatType
from pyspark.sql.functions import col, lit, current_timestamp, desc, row_number
from pyspark.sql.functions import size, replace, to_date, month, year, last, coalesce
from delta.tables import *
from delta.tables import DeltaTable

# COMMAND ----------

# MAGIC %md
# MAGIC ####Running the common dependency function notebooks

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_config"

# COMMAND ----------

# MAGIC %run "/Workspace/data_engineering/utils/nb_pmrs_utils_audit_log_func"

# COMMAND ----------

dbutils.widgets.removeAll()

# Create widgets for various parameters
dbutils.widgets.text("data_feed", "")
dbutils.widgets.text("debug_flag", "")
dbutils.widgets.text("external_location", "")
dbutils.widgets.text("uc_catalog_name", "")
dbutils.widgets.text("object_owner_spn", "")
dbutils.widgets.text("FilePath","")
dbutils.widgets.text("FileName","")
dbutils.widgets.text("uc_view_name","")
dbutils.widgets.text("username","")
dbutils.widgets.text("is_pcat","")


data_feed       = dbutils.widgets.get("data_feed")
external_location   = dbutils.widgets.get("external_location")
uc_view_name     = dbutils.widgets.get("uc_view_name")
debug_flag     = dbutils.widgets.get("debug_flag")
object_owner_spn     = dbutils.widgets.get("object_owner_spn")
username     = dbutils.widgets.get("username")
uc_catalog_name     = dbutils.widgets.get("uc_catalog_name")

if dbutils.widgets.get("is_pcat") == 'true':
    uc_view_name     = "sl_bdl_enriched_prod.gmi.vw_globalproducthierarchy"
    data_feed        = "master_data_pcat_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding Ingestion initializing Entry To AuditLog

# COMMAND ----------

# MAGIC %md
# MAGIC ###Main Orchestration

# COMMAND ----------

#  ----------------------<< Data Actions and Transformation part >>--------------------#
try:
    absolute_path = return_absolute_path(external_location)
    # Get list of files from the source directory
    df_read = spark.sql(f"""select * from {uc_view_name}""")
    df_read = df_read.dropDuplicates()

    if data_feed == "master_data_pcat_hierarchy":
        df_read = df_read.filter((col("ProductFormCode") != "Not applicable at this grain level") &
                                 (col("ProductFormCode") != "UNK") &
                                 (col("ProductFormCode") != "UNK1")
                                 )
except Exception as e:
    error = str(e).replace("'", "")
    raise e


# COMMAND ----------

# MAGIC %md
# MAGIC ###Write into Raw ADLS path

# COMMAND ----------

year = str(datetime.today().year)
yearmonth = year + str(datetime.today().month)
yearmonthday = yearmonth + str(datetime.today().day)
hourminute = str(datetime.today().hour) + str(datetime.today().minute)

# COMMAND ----------

try:
    if "master" in data_feed:
            source_path = f"data_engineering/bronze/raw/master_data/csv/{year}/"
            print("in master")
    else:
            source_path = f"data_engineering/bronze/raw/market/fact/csv/{data_feed}/{year}/{yearmonth}/{yearmonthday}/{hourminute}/"

    source_path1 = source_path
    source_path = f"""{absolute_path}{source_path}"""    
    dbutils.fs.mkdirs(source_path)
    df_read.coalesce(1).write.mode("overwrite").format("csv").option("header", "true").save(source_path)

    destination_path = source_path

    files = dbutils.fs.ls(source_path)
    csv_file = [x.path for x in files if x.path.endswith(".csv")][0]
    dbutils.fs.mv(csv_file, destination_path + f"""{data_feed}_{yearmonthday}_{hourminute}.csv""")
    remove_files= [x.path for x in files if not x.path.endswith(".csv")]
    for file in remove_files:
        if f'/archive/' not in file:   
                dbutils.fs.rm(file,recurse=True)
    
except Exception as e:
    error = str(e).replace("'", "")
    raise e


# COMMAND ----------

if "master" in data_feed:
    source_path = source_path + f"""{data_feed}_{yearmonthday}_{hourminute}.csv"""
    file_path,file_name = '',''
else:
    file_path = source_path1.removesuffix('/')
    file_name = f"""{data_feed}_{yearmonthday}_{hourminute}.csv"""
    source_path = source_path + f"""{data_feed}_{yearmonthday}_{hourminute}.csv"""

# COMMAND ----------

dbutils.jobs.taskValues.set("data_feed", data_feed)
dbutils.jobs.taskValues.set("debug_flag", debug_flag)
dbutils.jobs.taskValues.set("external_location", external_location)
dbutils.jobs.taskValues.set("object_owner_spn", object_owner_spn)
dbutils.jobs.taskValues.set("username", username)
dbutils.jobs.taskValues.set("processing_file_path", source_path)
dbutils.jobs.taskValues.set("FilePath", file_path)
dbutils.jobs.taskValues.set("FileName", file_name)
dbutils.jobs.taskValues.set("uc_catalog_name", uc_catalog_name)
