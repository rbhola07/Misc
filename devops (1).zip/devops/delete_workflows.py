import os
import sys
import json
import requests

def fetch_existing_jobs(databricks_instance, token):
    headers = {
        'Authorization': f'Bearer {token}',
    }
    # Ensure URL is being constructed correctly
    databricks_instance = databricks_instance.strip("'")
    url = f'{databricks_instance}/api/2.0/jobs/list'
    print(f"Making request to: {url}")

    response = requests.get(url, headers=headers)
    # Raise an error for bad responses
    response.raise_for_status()  
    return response.json()

def delete_job(databricks_instance, token, job_name):
    existing_jobs = fetch_existing_jobs(databricks_instance, token)
    
    # Find the existing job by name
    existing_job = next((j for j in existing_jobs['jobs'] if j['settings']['name'] == job_name), None)

    if existing_job:
        job_id = existing_job['job_id']
        print(f"Job '{job_name}' found with ID: {job_id}, preparing to delete the job.")
        
        # Send the request to delete the job
        databricks_instance = databricks_instance.strip("'")
        response = requests.post(
            f'{databricks_instance}/api/2.0/jobs/delete',
            json={'job_id': job_id},
            headers={'Authorization': f'Bearer {token}'}
        )

        print(f"Response Status Code: {response.status_code}")
        print(f"Response Text: {response.text}")

        if response.status_code == 200:
            print(f"Successfully deleted job: {job_name}")
        else:
            print(f"Error deleting job '{job_name}': {response.status_code} - {response.text}")
    else:
        print(f"Job '{job_name}' not found, no action taken.")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python delete_workflows.py <databricks_instance> <token> <job_name>")
        sys.exit(1)

    databricks_instance = sys.argv[1]
    token = sys.argv[2]
    job_name = sys.argv[3]  # Accept job name as argument
    
    delete_job(databricks_instance, token, job_name)
